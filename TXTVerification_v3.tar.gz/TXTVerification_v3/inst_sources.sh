sudo apt-get install python
sudo apt-get install pip
sudo pip install --upgrade pip
sudo pip install oct2py
sudo pip install scipy
sudo pip install numpy

