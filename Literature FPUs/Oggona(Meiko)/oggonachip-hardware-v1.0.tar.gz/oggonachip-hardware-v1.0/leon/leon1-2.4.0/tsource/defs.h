extern volatile int dexcn;

