setenv CVSROOT lazuara@rax3.informatik.uni-stuttgart.de:/usr/local/cvs/oggonachip
setenv CVS_RSH ssh
setenv PATH $PATH\:/home/lazuara/bin


