setenv XSTOOLS_BIN_DIR /home/lazuara/cvs/myoggonachip/xsvsoft/
setenv CVS_RSH ssh
setenv LM_LICENSE_FILE 1700@ras20:1709@ras20
setenv CVSROOT lazuara@rax3.informatik.uni-stuttgart.de:/usr/local/cvs/oggonachip

setenv XILINX /cad/xilinx2000/4.1i_linux/drivec/xilinx
setenv DRIVEC /cad/xilinx2000/4.1i_linux/drivec
setenv PATH $PATH\:/home/lazuara/rtems/bin:/var/lic/synplify/bin:/cad/synplify/702/linux/synplify_70/bin:/usr/local/bin:/cad/xilinx2000/4.1i_linux/bin:/home/lazuara/cvs/oggonachip/hardware/dsumon-1.0/linux
