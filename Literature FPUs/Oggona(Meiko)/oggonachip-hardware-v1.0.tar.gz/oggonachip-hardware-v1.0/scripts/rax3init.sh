setenv CVSROOT /usr/local/cvs/oggonachip
setenv CVS_RSH ssh


