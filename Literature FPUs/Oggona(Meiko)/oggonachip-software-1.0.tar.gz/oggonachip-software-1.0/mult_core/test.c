#include <stdio.h>
#include "mult_core.h"

#define MUL(s, a, b)	(int)(((long long)(a) * (b)) >> (s))

#define FRACBITS 30

int main () {
  int x,y,z;
  x = 1 << 10;
  y = 1 << FRACBITS;

  // printf("x is %d\n",x);
  //printf("y is 1 << %d = %d\n", FRACBITS, y);
  z = MUL(FRACBITS,x,y);
  printf("%d\n",z);
  //printf("z = (x * y) >> %d  = %d\n", FRACBITS, z);
  return 0;
}
