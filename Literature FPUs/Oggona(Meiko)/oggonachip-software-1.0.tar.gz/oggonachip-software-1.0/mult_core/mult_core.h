#ifndef __ASSEMBLER__

struct mult_core_regs {
  /* 
   * s : size of FRACBITS to be shifted
   * start up = 30
   */
  volatile unsigned int s; /* 0x00 */

  /*
   * a : first argument
   */
  volatile unsigned int a;  /* 0x04 */

  /*
   * b : second argument
   */
  volatile unsigned int b;  /* 0x08 */ 

  /*
   * r : result
   */
  volatile unsigned int r;  /* 0x0C */

  /*
   * rs : result with shift
   */
  volatile unsigned int rs;  /* 0x10 */

};

#define	MULT_CORE_START    0x80000400 
#define	MULT_CORE_END      0x80000414

#define MULT_CORE_SIZE     0x14

#define MULT_CORE_S  0x00
#define MULT_CORE_A   0x04
#define MULT_CORE_B   0x08
#define MULT_CORE_R   0x0C
#define MULT_CORE_RS   0x10

#endif
