/* 
   MULT core module to be included by ../tsim-io/io.c .

   @author Pattara Kiatisevi
   $Id: mult_core.c,v 1.1 2002/05/10 16:26:50 pattara Exp $
*/

#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <linux/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/soundcard.h>

#include "mult_core.h"

struct mult_core_regs *mult_core;

static void mult_core_init() 
{

  printf("io: mult_core: MULT-core initialized at 0x%x\n", MULT_CORE_START);
  printf("io: mult_core: time = %ld\n",(long)simif.simtime());
   
  mult_core = (struct mult_core_regs *) malloc (MULT_CORE_SIZE);
  mult_core->s = 30;
  mult_core->a = 0;
  mult_core->b = 0;
  mult_core->r = 0;
  mult_core->rs = 0;

};

static void mult_core_exit() {
  printf("io: mult_core: MULT-core exit\n");
};

/* I/O read/write. Called on I/O or undecoded access. Should return 0 on
   success, 1 on memory error (MEXC will be generated). Data should be
   retuned in *data, number of BUSRDY waitstates should be returned in *ws.
   Size is encoded as: 0=byte, 1=half-word, 2=word, 3=doubel-word  */

static int mult_core_read(address, data, ws) 
unsigned int address, *data, *ws; 
{ 
    *ws = 1;

    DEBUG("io: mult_core: MULT core accesssed at 0x%08X\n", address); 
    if ((address >= MULT_CORE_START) && (address < MULT_CORE_END)) {
      /* make it relative instead of absolute */
      address -= MULT_CORE_START;
      /* alignment */
      address &= ~3;
      switch (address)	{
      case MULT_CORE_S :  
	*data = mult_core->s;
	break;
     case MULT_CORE_A :  
	*data = mult_core->a;
	break; 
     case MULT_CORE_B :  
	*data = mult_core->b;
	break;
     case MULT_CORE_R :  
	*data = mult_core->r;
	break;
     case MULT_CORE_RS :  
	*data = mult_core->rs;
	break;
      default:
	DEBUG("io: This should not happen! Error!\n");
	break;
      }
      
      return(0);
    } else
      return(1);
}

/* update the r and rs register */
void calc() {
  mult_core->r = (long long)(mult_core->a) * (mult_core->b);
  mult_core->rs = (int) (( (long long)(mult_core->a) * (mult_core->b) ) >> (mult_core->s));
}

static int mult_core_write(address, data, ws, size) 
unsigned int address, *data, *ws, size; 
{ 
  *ws = 0;

  DEBUG("io: mult_core: io_write at 0x%08X\n", address);

  if ((address >= MULT_CORE_START) && (address < MULT_CORE_END)) {
    address -= MULT_CORE_START;
    switch(size) {
    case 2:
      /* only word access is allowed */
      /* alignment */
      address &= ~3;
      switch (address)	{
      case MULT_CORE_S :  
	mult_core->s = *data;
	DEBUG("io: mult_core: s set to %d!\n",mult_core->s);
	break;
      case MULT_CORE_A :  
	mult_core->a = *data;
	DEBUG("io: mult_core: a set to %d!\n",mult_core->a);
	calc();
	break;
     case MULT_CORE_B :  
	mult_core->b = *data;
	DEBUG("io: mult_core: b set to %d!\n",mult_core->b);
	calc();
	break;
      default:
	fprintf(stderr, "io: mult_core: This should not happen! Error!\n");
	return(1);
      }
      break;
    default:
      fprintf(stderr, "io: mult_core: Error, access with size = %d, only word access is allowed!\n",size);
      return(1);
    }
    return(0);
  } else
    return(1);
}

