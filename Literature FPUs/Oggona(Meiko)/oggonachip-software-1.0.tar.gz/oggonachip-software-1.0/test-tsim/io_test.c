#include <stdio.h>
#define FLASH_START 0x20000000
#define FLASH_SIZE  0x100000
#define FLASH_END   0x20100000

/* The very simple module to test the io.c
 *  example module that came with TSIM
 *  professional version
 *
 *  ott@linux.thai.net -- Jan 22, 2002
 *
 */


main() {
  unsigned int data;
  volatile unsigned int *flash = (unsigned int*) FLASH_START;
  data = 0xFF;
  printf("Writing %X to FLASH_START..\n", data);
  *flash = data;
  data = 0x00;
  printf("Read back from FLASH_START..\n");
  data = *(flash);
  printf("Data is %X\n", data);
}
 
