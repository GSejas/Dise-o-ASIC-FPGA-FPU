#ifndef __ASSEMBLER__

struct minimdct_core_regs {
  /* 
   * Control register
   * bit 0: Mini-MDCT-core, 1 = on, 2 = off
   */
  volatile unsigned int controlreg; /* 0x00 */

  /*
   * Size of input and output vector arrays 
   * after write to this arraysize register, check until status=1
   */
  volatile unsigned int arraysize;  /* 0x04 */

  /*
   * Start address of memory space that contains trig array data
   */
  volatile unsigned int trigaddr;  /* 0x08 */

  /*
   * Start address of input vector to be read 
   */
  volatile unsigned int startreadaddr;  /* 0x0C */ 

  /*
   * Start address of output vector to be written
   */
  volatile unsigned int startwriteaddr;  /* 0x10 */

  /*
   * Status register, after write to controlreg and arraysize, 
   * value 1 here means the operation is successful
   */
  volatile unsigned int status;  /* 0x14 */

  /* 
   * Current processing element
   */
  volatile unsigned int actmemaddr; /* 0x18 */
};



#define	MINIMDCT_CORE_START    0x80000300 
#define	MINIMDCT_CORE_END      0x8000031C

#define MINIMDCT_CORE_SIZE     0x1C

#define MINIMDCT_CORE_CONTROLREG  0x00
#define MINIMDCT_CORE_ARRAYSIZE   0x04
#define MINIMDCT_CORE_TRIGADDR   0x08
#define MINIMDCT_CORE_STARTREADADDR   0x0C
#define MINIMDCT_CORE_STARTWRITEADDR   0x10
#define MINIMDCT_CORE_STATUS   0x14
#define MINIMDCT_CORE_ACT_MEM_ADDR 0x18


#endif
