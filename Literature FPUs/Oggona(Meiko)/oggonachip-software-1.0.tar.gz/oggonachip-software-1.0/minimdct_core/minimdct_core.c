/* 
   Mini-MDCT core module to be included by ../tsim-io/io.c .

   @author Pattara Kiatisevi
   $Id: minimdct_core.c,v 1.4 2002/06/30 18:41:19 pattara Exp $
*/

#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <linux/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/soundcard.h>

#include "minimdct_core.h"
#include "mdct.h"
#include "mdct.c"

struct minimdct_core_regs *minimdct_core;

static void minimdct_core_init() 
{

  printf("io: minimdct_core: Mini-MDCT-core initialized at 0x%x\n", MINIMDCT_CORE_START);
  printf("io: minimdct_core: time = %ld\n",(long)simif.simtime());
   
  minimdct_core = (struct minimdct_core_regs *) malloc (MINIMDCT_CORE_SIZE);
  minimdct_core->controlreg = 0;
  minimdct_core->arraysize  = 0;
  minimdct_core->trigaddr  = 0;
  minimdct_core->startreadaddr  = 0;
  minimdct_core->startwriteaddr  = 0;
  minimdct_core->status  = 0;
  minimdct_core->actmemaddr  = 0;

};

static void minimdct_core_exit() {
  printf("io: minimdct_core: MDCT-core exit\n");
};

/* I/O read/write. Called on I/O or undecoded access. Should return 0 on
   success, 1 on memory error (MEXC will be generated). Data should be
   retuned in *data, number of BUSRDY waitstates should be returned in *ws.
   Size is encoded as: 0=byte, 1=half-word, 2=word, 3=doubel-word  */

static int minimdct_core_read(address, data, ws) 
unsigned int address, *data, *ws; 
{ 
    *ws = 4;

    DEBUG("io: minimdct_core: Mini-MDCT core accesssed at 0x%08X\n", address); 
    if ((address >= MINIMDCT_CORE_START) && (address < MINIMDCT_CORE_END)) {
      /* make it relative instead of absolute */
      address -= MINIMDCT_CORE_START;
      /* alignment */
      address &= ~3;
      switch (address)	{
      case MINIMDCT_CORE_CONTROLREG :  
	DEBUG("io: minimdct_core: Control register is accessed!\n");
	*data = minimdct_core->controlreg;
	break;
     case MINIMDCT_CORE_ARRAYSIZE :  
	DEBUG("io: minimdct_core: Arraysize register is accessed!\n");
	*data = minimdct_core->arraysize;
	break; 
     case MINIMDCT_CORE_TRIGADDR :  
	DEBUG("io: minimdct_core: Trigaddr register is accessed!\n");
	*data = minimdct_core->trigaddr;
	break; 
     case MINIMDCT_CORE_STARTREADADDR :  
	DEBUG("io: minimdct_core: Start address register is accessed!\n");
	*data = minimdct_core->startreadaddr;
	break;
      case MINIMDCT_CORE_STARTWRITEADDR :  
	DEBUG("io: minimdct_core: Start write address register is accessed!\n");
	*data = minimdct_core->startwriteaddr;
	break;
      case MINIMDCT_CORE_STATUS :  
	DEBUG("io: minimdct_core: Status register is accessed!\n");
	*data = minimdct_core->status;
	break;
     case MINIMDCT_CORE_ACT_MEM_ADDR :  
	DEBUG("io: minimdct_core: Act mem address register is accessed!\n");
	*data = minimdct_core->actmemaddr;
	break;
      default:
	DEBUG("io: This should not happen! Error!\n");
	break;
      }
      
      return(0);
    } else
      return(1);
}

static int minimdct_core_write(address, data, ws, size) 
unsigned int address, *data, *ws, size; 
{ 
  /* save for local use */
  int tmpdata = 0;

  *ws = 4;

  DEBUG("io: minimdct_core: io_write at 0x%08X\n", address);

  if ((address >= MINIMDCT_CORE_START) && (address < MINIMDCT_CORE_END)) {
    address -= MINIMDCT_CORE_START;
    switch(size) {
    case 2:
      /* only word access is allowed */
      /* alignment */
      address &= ~3;
      switch (address)	{
      case MINIMDCT_CORE_CONTROLREG :  
	DEBUG("io: minimdct_core: Control register is accessed!\n");
	tmpdata = *data;
	minimdct_core->controlreg = *data;
	/* only the last 5 bits are used */
	//tmpdata &= 0x1F;
	/* first bit, MDCTcore 1=on, 0 = off */
	if ( (tmpdata & 0x1) != 0 ) {
	  DEBUG("io: minimdct_core: Mini-MDCTcore is turned on..\n");
	  

	  /* Start the calculation process */
	  {
	    DATA_TYPE *in, *out;
	    mdct_lookup* lookup;
	    int n;

	    DEBUG("io: minimdct_core: Start the MDCT calculation ... \n");
	    minimdct_core->status = 0; 

	    /* Check the array size (2nd bit) */
	    if ( minimdct_core->arraysize == 0 ) n = 256; else n = 2048;

	    DEBUG("io: n = %d\n",n);

	    in =  malloc (n * sizeof(DATA_TYPE));
	    out = malloc (n * sizeof(DATA_TYPE));
	    lookup = malloc (sizeof(mdct_lookup));
	    lookup->bitrev = malloc(sizeof(int) * n/4 );
	    lookup->trig = malloc(sizeof(DATA_TYPE) * n*5/4 );

	    if ( in == 0 || out == 0 || lookup->trig ==0 ) {
              fprintf(stderr, "io: minimdct_core: malloc for MDCT calculation error\n");
              return(-1);
            }	    

	    /* call mdct_init, but bitrev and trig will be rewritten anyway */
	    mdct_init(lookup,n);

	    /* clear the value of trig and bitrev to be realistic */
	    {
	      int i;
	      for (i = 0 ; i < n*5/4 ; i++ ) {
		*(lookup->trig + i) = 0;
	      }
	      for (i = 0 ; i < n/4 ; i++ ) {
		*(lookup->bitrev + i) = 0;
	      }
	    }

	    /* load the value from DMA */
	    DEBUG("io: minimdct_core: Starting DMA read of variables...\n");

            /* last argument of dma_read is no. of words */
            if ( ioif.dma_read(  minimdct_core->trigaddr, (unsigned int *) lookup->trig, n*5/4 ) != 0 ) {
	          fprintf(stderr, "io: minimdct_core: DMA read bus error\n");
	          return(1);
            }	  
            /* last argument of dma_read is no. of words */
            if ( ioif.dma_read(  minimdct_core->startreadaddr, (unsigned int *) in, n ) != 0 ) {
                    fprintf(stderr, "io: minimdct_core: DMA read bus error\n");
                    return(1);
            }	    

	    DEBUG("io: Calling minimdct_backward()..\n");
	    /* now call the real calculation function */
	    minimdct_backward(lookup, in, out);

	    DEBUG("io: ok");
	    /* write back the result */
           if ( ioif.dma_write(minimdct_core->startwriteaddr, (unsigned int *) out, n ) != 0 ) {
                    fprintf(stderr, "io: minimdct_core: DMA write bus error\n");
                    return(1);
            }	    

	    /* set status register to indicate that work is finisehd */
	    minimdct_core->status = 1; 
	    /* this actmemaddr is not really useful with TSIM */
	    minimdct_core->actmemaddr = minimdct_core->startwriteaddr + n*sizeof(DATA_TYPE);
	    /* reset control register */
	    minimdct_core->controlreg = minimdct_core->controlreg & ~1;
	  }
	} else {
	  DEBUG("io: minimdct_core: MDCTcore is turned off..\n");
	  return(0);
	}
	break;
      case MINIMDCT_CORE_ARRAYSIZE :  
	DEBUG("io: minimdct_core: Array size register is accessed!\n");
	minimdct_core->arraysize = *data;
	DEBUG("io: minimdct_core: Arraysize set to %d\n", minimdct_core->arraysize);
	DEBUG("io: minimdct_core: Done...\n");
	break;
      case MINIMDCT_CORE_TRIGADDR :  
	DEBUG("io: minimdct_core: trig address register is accessed!\n");
	minimdct_core->trigaddr = *data;
	DEBUG("io: minimdct_core: trig addr set to 0x%08X\n", minimdct_core->trigaddr);
	break;
      case MINIMDCT_CORE_STARTREADADDR :  
	DEBUG("io: minimdct_core: Start read address register is accessed!\n");
	minimdct_core->startreadaddr = *data;
	DEBUG("io: minimdct_core: Startaddr set to 0x%08X\n", minimdct_core->startreadaddr);
	break;

      case MINIMDCT_CORE_STARTWRITEADDR :  
	DEBUG("io: minimdct_core: Start write address register is accessed!\n");
	minimdct_core->startwriteaddr = *data;
	DEBUG("io: minimdct_core: Start write address register set to 0x%08X\n", minimdct_core->startwriteaddr);
	break;
      case MINIMDCT_CORE_STATUS :  
	DEBUG("io: minimdct_core: Status register is accessed!\n");
	minimdct_core->status = *data;
	DEBUG("io: minimdct_core: Status register set to %d\n", minimdct_core->status);
	break;
      case MINIMDCT_CORE_ACT_MEM_ADDR :  
	DEBUG("io: minimdct_core: Act_mem_addr is accessed!\n");
	fprintf(stderr, "io: minimdct_core: Error, actmemaddr register is read-only\n");
	return(1);
      default:
	fprintf(stderr, "io: minimdct_core: This should not happen! Error!\n");
      }
      break;
    default:
      fprintf(stderr, "io: minimdct_core: Error, access with size = %d, only word access is allowed!\n",size);
      return(1);
    }
    return(0);
  } else
    return(1);
}

