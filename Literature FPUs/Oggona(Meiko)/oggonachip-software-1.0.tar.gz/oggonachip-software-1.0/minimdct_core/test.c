/* A simple program to test the Mini-MDCT Core module
 *
 * @author Pattara Kiatisevi ott@linux.thai.net
 * 13.03.2002
 *
 * $Id: test.c,v 1.3 2002/06/12 17:38:44 pattara Exp $
 *
 */

#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include "minimdct_core.h"
#include "mdct.h"

#define ARRAYSIZE 2048 

volatile struct minimdct_core_regs *regs = (struct minimdct_core_regs *) MINIMDCT_CORE_START;

int main() {
  DATA_TYPE *in;
  DATA_TYPE *out;
  unsigned int i;
  mdct_lookup lookup;

  printf("MDCT Core test program started ..\n");
  printf("TRIGBITS = %d\n", TRIGBITS);

  printf("Allocate memory ...\n");
  in = malloc (ARRAYSIZE * sizeof(DATA_TYPE));
  out = malloc (ARRAYSIZE * sizeof(DATA_TYPE));

  printf("Calling mdct_init(%d)..\n", ARRAYSIZE);
  mdct_init(&lookup, ARRAYSIZE);
  
  printf("Initializing values of input array...\n");
  for (i = 0 ; i < ARRAYSIZE ; i++) {
    //    *(in + i) = 0.01 * i * 32768;
    *(in + i ) = i;
    printf("%3d: %4d\t",i, *(in + i) );
  if ( i % 5 == 4 ) printf("\n");
  }

  printf("Write value 0x%08X to trig address register ...\n", (unsigned int) lookup.trig);
  regs->trigaddr = (unsigned int) lookup.trig;

  printf("Write value 0x%08X to start read address register ...\n", (unsigned int) in);
  regs->startreadaddr = (unsigned int) in;

  printf("Write value 0x%08X to start write address register ...\n", (unsigned int) out);
  regs->startwriteaddr = (unsigned int) out;

  printf("Write value %d to array size register ...\n", ARRAYSIZE);
  if ( ARRAYSIZE == 256) {
    regs->arraysize = 0;
  } else {
    regs->arraysize = 1;
  }

  printf("Start the MDCT core .. \n");
  regs->controlreg = 0x1;

  /* wait until result is there */
  printf("Wait until calculation is finished...\n");
  printf("act_mem_addr is 0x%08X\n", regs->actmemaddr);
  while ( regs->status != 1 ) {
    printf("act_mem_addr is 0x%08X\n", regs->actmemaddr);
  }
  printf("Finished ... output values:\n");
 
  for (i = 0 ; i < ARRAYSIZE ; i++) {
    printf("%3d: %4d\t",i , *( (int*) out + i) ); 
    if ( i % 5 == 4 ) printf("\n");
  }

  return(0);
}
