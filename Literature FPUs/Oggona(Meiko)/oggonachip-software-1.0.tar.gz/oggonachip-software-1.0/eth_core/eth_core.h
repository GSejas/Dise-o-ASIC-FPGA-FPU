#ifndef __ASSEMBLER__

struct eth_core_regs {
  /* 
   * Control register
   * bit 0: Tx-mode, 0 = off, 1 = on (start transmit data)
   * bit 1: Rx-mode, 0 = off, 1 = on 
   */
  volatile unsigned int controlreg; /* 0x00 */

  /*
   * Packet data size
   */
  volatile unsigned int packetsize; /* 0x04 */

  /*
   * Start address of data to be read for Tx 
   */
  volatile unsigned int startreadaddr;  /* 0x08 */ 

  /*
   * Start address of data to be written for Rx
   */
  volatile unsigned int startwriteaddr;  /* 0x0C */

  /* 
   * Current processing element
   */
  volatile unsigned int actmemaddr; /* 0x10 */
};

#define	ETH_CORE_START    0x80000400 
#define	ETH_CORE_END      0x80000414

#define ETH_CORE_SIZE     0x14

#define ETH_CORE_CONTROLREG  0x00
#define ETH_CORE_PACKETSIZE   0x04
#define ETH_CORE_STARTREADADDR   0x08
#define ETH_CORE_STARTWRITEADDR   0x0C
#define ETH_CORE_ACT_MEM_ADDR 0x10

#endif
