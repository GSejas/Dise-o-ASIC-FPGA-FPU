/* A simple program to test the Audio ETH Core module
 *
 * @author Pattara Kiatisevi ott@linux.thai.net
 * 13.03.2002
 *
 * $Id: test.c,v 1.2 2002/06/30 19:13:18 pattara Exp $
 *
 */

#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include "eth_core.h"

extern void *catch_interrupt(void func(), int irq);
int *leon = (int *) 0x80000000;

// source mac address: 00 11 22 33 44 55
// target IP address: 81 45  b7 fe
char packet[] = {
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x08, 0x06, 0x00, 0x01,
  0x08, 0x00, 0x06, 0x04, 0x00, 0x01, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x81, 0x45, 0xb7, 0x16,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x81, 0x45, 0xb7, 0xfe, 0x6a, 0xa3, 0xc8, 0xb4, 0x80, 0x18,
  0x30, 0x19, 0x20, 0x2a, 0x39, 0x00, 0x00, 0x01, 0x01, 0x08, 0x0a, 0x01, 0x70, 0x00, 0x00, 0x00
};

void enable_irq (int irq) 
{
	leon[0x9c/4] = (1 << irq);	// clear any pending irq
	leon[0x90/4] |= (1 << irq);	// unmaks irq
};

void irqhandler(int irq)
{
	printf("Interrupt Handler for vector %d is called\n", irq);
};

volatile struct eth_core_regs *regs = (struct eth_core_regs *) ETH_CORE_START;

#define ETHIRQNUMBER 14

int main() {

  enable_irq(14);
  catch_interrupt(irqhandler, 14);

  regs->packetsize = sizeof(packet);
  regs->startreadaddr = (unsigned int) packet;
  regs->controlreg = 0x1;
  return(0);
}
