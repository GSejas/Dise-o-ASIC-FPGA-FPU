/* 
   ETH core module to be included by ../tsim-io/io.c .

   @author Pattara Kiatisevi
   $Id: eth_core.c,v 1.2 2002/06/30 19:13:18 pattara Exp $
*/

#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <linux/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/soundcard.h>

#include <netinet/in.h>

#include "eth_core.h"

#define ETHIRQNUMBER 14
#define TXIRQLEVEL 0 
#define RXIRQLEVEL 1

struct eth_core_regs *eth_core;

static void eth_core_init() 
{

  printf("io: eth_core: ETH-core initialized at 0x%x\n", ETH_CORE_START);
  printf("io: eth_core: time = %ld\n",(long)simif.simtime());
   
  eth_core = (struct eth_core_regs *) malloc (ETH_CORE_SIZE);
  eth_core->controlreg = 0;
  eth_core->packetsize = 0;
  eth_core->startreadaddr  = 0;
  eth_core->startwriteaddr  = 0;
  eth_core->actmemaddr  = 0;

};

static void eth_core_exit() {
  printf("io: eth_core: ETH-core exit\n");
};

/* I/O read/write. Called on I/O or undecoded access. Should return 0 on
   success, 1 on memory error (MEXC will be generated). Data should be
   retuned in *data, number of BUSRDY waitstates should be returned in *ws.
   Size is encoded as: 0=byte, 1=half-word, 2=word, 3=doubel-word  */

static int eth_core_read(address, data, ws) 
unsigned int address, *data, *ws; 
{ 
    *ws = 4;

    DEBUG("io: eth_core: ETH core accesssed at 0x%08X\n", address); 
    if ((address >= ETH_CORE_START) && (address < ETH_CORE_END)) {
      /* make it relative instead of absolute */
      address -= ETH_CORE_START;
      /* alignment */
      address &= ~3;
      switch (address)	{
      case ETH_CORE_CONTROLREG :  
	DEBUG("io: eth_core: Control register is accessed!\n");
	*data = eth_core->controlreg;
	break;
     case ETH_CORE_PACKETSIZE :  
	DEBUG("io: eth_core: Packetsize register is accessed!\n");
	*data = eth_core->packetsize;
	break; 
     case ETH_CORE_STARTREADADDR :  
	DEBUG("io: eth_core: Start read address register is accessed!\n");
	*data = eth_core->startreadaddr;
	break;
      case ETH_CORE_STARTWRITEADDR :  
	DEBUG("io: eth_core: Start write address register is accessed!\n");
	*data = eth_core->startwriteaddr;
	break;
     case ETH_CORE_ACT_MEM_ADDR :  
	DEBUG("io: eth_core: Act mem address register is accessed!\n");
	*data = eth_core->actmemaddr;
	break;
      default:
	DEBUG("io: This should not happen! Error!\n");
	break;
      }
      return(0);
    } else
      return(1);
}

static int transmit() {
  char* buffer;

  DEBUG("io: eth_core: ETH-core is starting to transmit data..\n");

  /* Alloc memory of the data size to be transmitted */
  buffer = malloc(eth_core->packetsize);
  
  /* load the value from DMA */
  DEBUG("io: eth_core: Starting DMA read of data...\n");

  /* last argument of dma_read is no. of words */
  if ( ioif.dma_read(  eth_core->startreadaddr, (unsigned int *) buffer, eth_core->packetsize/4 + 1) != 0 ) {
    fprintf(stderr, "io: eth_core: DMA read bus error\n");
    return(1);
  }	

  if ( eth_core->packetsize < 64 ) {
    printf("io: eth_core: padding to 64 bytes..\n");
    // FIXME 
  }

  printf("io: eth_core: doing endian conversion...\n");
  {
    unsigned int i;
    for( i = 0 ; i < eth_core->packetsize/4 ; i++ ) {
      *((unsigned int*) buffer + i) = htonl(*((unsigned int*) buffer + i));
    }
  }

  printf("io: eth_core: transmit data of size %d bytes to network\n",eth_core->packetsize);

  {
    unsigned int i;
    for ( i = 0 ; i < eth_core->packetsize ; i++ ) {
      printf("%02X ",buffer[i] & 0xFF);
      if ( (i+1) / 16 * 16 == (i+1) *16 /16 ) printf("\n");
    }
  }
  printf("\n");
  free(buffer);
  return(0);
}

static int eth_core_write(address, data, ws, size) 
unsigned int address, *data, *ws, size; 
{ 
  /* save for local use */
  int tmpdata = 0;

  *ws = 4;

  DEBUG("io: eth_core: io_write at 0x%08X\n", address);

  if ((address >= ETH_CORE_START) && (address < ETH_CORE_END)) {
    address -= ETH_CORE_START;
    switch(size) {
    case 2:
      /* only word access is allowed */
      /* alignment */
      address &= ~3;
      switch (address)	{
      case ETH_CORE_CONTROLREG :  
	DEBUG("io: eth_core: Control register is accessed!\n");
	tmpdata = *data;
	eth_core->controlreg = *data;

	/* first bit, tx: 1=on, 0 = off */
	if ( (tmpdata & 0x1) != 0 ) {
	  transmit();
	  /* reset control register */
	  eth_core->controlreg = eth_core->controlreg & ~1;
	  DEBUG("io: eth_core: send interrupt to LEON...\n");
	  ioif.set_irq(ETHIRQNUMBER,TXIRQLEVEL);
	  DEBUG("io: eth_core: irq sent..\n");	  
	} else {
	  DEBUG("io: eth_core: eth_core Tx function is turned off by software..\n");
	}

	/* second bit, rx: 1=on, 0 = off */
	if ( (tmpdata & 0x2) != 0 ) {
	  /* 0 = disable the Rx part of core */
	  /* 1 = if there is a packet coming:
	     1.dma the data to eth_core->startwriteaddr
	     2.write data size to eth_core->packetsize
	     3.send interrupt 
	     ioif.set_irq(ETHIRQNUMBER,RXIRQLEVEL);
	  */
	} else {
	  DEBUG("io: eth_core: eth_core Rx function is turned off by software..\n");
	}
	break;
      case ETH_CORE_PACKETSIZE :  
	DEBUG("io: eth_core: Packet size register is accessed!\n");
	eth_core->packetsize = *data;
	DEBUG("io: eth_core: Packetsize set to %d\n", eth_core->packetsize);
	DEBUG("io: eth_core: Done...\n");
	break;
      case ETH_CORE_STARTREADADDR :  
	DEBUG("io: eth_core: Start read address register is accessed!\n");
	eth_core->startreadaddr = *data;
	DEBUG("io: eth_core: Start read address register set to 0x%08X\n", eth_core->startreadaddr);
	break;
      case ETH_CORE_STARTWRITEADDR :  
	DEBUG("io: eth_core: Start write address register is accessed!\n");
	eth_core->startwriteaddr = *data;
	DEBUG("io: eth_core: Start write address register set to 0x%08X\n", eth_core->startwriteaddr);
	break;
      case ETH_CORE_ACT_MEM_ADDR :  
	DEBUG("io: eth_core: Act_mem_addr is accessed!\n");
	fprintf(stderr, "io: eth_core: Error, actmemaddr register is read-only\n");
	return(1);
      default:
	fprintf(stderr, "io: eth_core: This should not happen! Error!\n");
      }
      break;
    default:
      fprintf(stderr, "io: eth_core: Error, access with size = %d, only word access is allowed!\n",size);
      return(1);
    }
    return(0);
  } else
    return(1);
}

