#include <linux/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/soundcard.h>
#include <stdio.h>

#define BUF_SIZE 4096
#define DEVICE_NAME "/dev/dsp"

#include "../musicdata/musicdata1.c"

int audio_fd;
int open_mode = O_WRONLY;

int main (int argc, char* argv[]) {

  /* Open sound device */
  if ( (audio_fd = open(DEVICE_NAME, open_mode, 0) ) == -1 ) {
    /* open of a device failed */
    perror(DEVICE_NAME);
    exit(1);
  }
  
  /* Set up the parameters */
  { 
    int format = AFMT_S16_LE;
    int channels = 1;
    int speed  = 22050;
    if ( ioctl(audio_fd, SNDCTL_DSP_SETFMT, &format) == -1 ) {
      perror("SNDCTL_DSP_SETFMT");
      exit(1);
    } 
    if ( ioctl(audio_fd, SNDCTL_DSP_CHANNELS, &channels) == -1 ) {
      perror("SNDCTL_DSP_CHANNELS");
      exit(1);
    }
    if ( ioctl(audio_fd, SNDCTL_DSP_SPEED, &speed) == -1 ) {
      perror("SNDCTL_DSP_SPEED");
      exit(1);
    }
  }

  /* Read the sound file content and play it */

  {
    int inputsize = sizeof(musicdata);
    unsigned char * audio_buffer = (unsigned char*) musicdata;
    write(audio_fd, audio_buffer, inputsize);
  }

  /* Close */
  close(audio_fd);
  return(0);
}
