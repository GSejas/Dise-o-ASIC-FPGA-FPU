#include <linux/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/soundcard.h>
#include <stdio.h>

#define BUF_SIZE 4096
#define DEVICE_NAME "/dev/dsp"

int audio_fd;
int open_mode = O_WRONLY;
char* inputfilename;

int main (int argc, char* argv[]) {

  /* Check argument */
  if ( argc != 2 ) {
	  printf("Usage: %s <sound-file>\n",  argv[0]);
	  return(0);
  } else {
	  inputfilename = argv[1];
  }
  /* Open sound device */
  if ( (audio_fd = open(DEVICE_NAME, open_mode, 0) ) == -1 ) {
    /* open of a device failed */
    perror(DEVICE_NAME);
    exit(1);
  }
  
  /* Set up the parameters */
  { 
    int format = AFMT_S16_LE;
    int channels = 1;
    int speed  = 22050;
    if ( ioctl(audio_fd, SNDCTL_DSP_SETFMT, &format) == -1 ) {
      perror("SNDCTL_DSP_SETFMT");
      exit(1);
    } 
    if ( ioctl(audio_fd, SNDCTL_DSP_CHANNELS, &channels) == -1 ) {
      perror("SNDCTL_DSP_CHANNELS");
      exit(1);
    }
    if ( ioctl(audio_fd, SNDCTL_DSP_SPEED, &speed) == -1 ) {
      perror("SNDCTL_DSP_SPEED");
      exit(1);
    }
  }

  /* Read the sound file content and play it */

  {
    int readlen, writelen;
    unsigned char audio_buffer[BUF_SIZE];
    FILE* inputfile;

    inputfile = fopen(inputfilename, "rb");
    while (! feof(inputfile) ) {
      readlen = fread(audio_buffer, 1, BUF_SIZE, inputfile);
      /* printf("Reading data of length %d bytes from %s\n", readlen, inputfilename); */
      if ( ( writelen = write(audio_fd, audio_buffer, readlen) ) == -1 ) {
	perror("audio write");
	exit(1);
      }
      if ( writelen != readlen ) {
	fprintf(stderr,"Error: cannot write all what I read\n");
	exit(1);
      }
    }
    fclose(inputfile);
  }
  /* Close */

  close(audio_fd);
  return(0);
}
