#include <stdlib.h>
#define BLOCKSIZE 8192

int first;


main() {

  char *dynamic;
  int i,j,sum = 0;

  printf("address of first variable is 0x%08X\n", &first);
  
  while ( j < 251 ) {

    dynamic = (char *) malloc(BLOCKSIZE);
    j++;
    printf("Entering loop %d:\n",j);
    if ( dynamic == 0 ) {
      printf("malloc error .. \n" );
      return(1);
    } else {
      printf("Allocated now %d bytes, address got 0x%08X\n", BLOCKSIZE, (unsigned int) dynamic);
      sum += BLOCKSIZE;
      printf("Testing the allocated chunk of memory...\n");
      for (i = 0 ; i < BLOCKSIZE ; i++) {
	*(dynamic + i) = 65; // set the memory to a value
      }
      for (i = 0 ; i < BLOCKSIZE ; i++) {
	if ( *(dynamic + i) != 65 ) { 
	  printf("ERROR at memory address 0x%08X\n",(unsigned int) (dynamic + i));
	}
      }
      for (i = BLOCKSIZE ; i < 0 ; i--) {
	*(dynamic + i) = 0; // set the memory to a value
      }
      for (i = BLOCKSIZE ; i < 0 ; i--) {
	if ( *(dynamic + i) != 0 ) { 
	  printf("ERROR at memory address 0x%08X\n",(unsigned int) (dynamic + i));
	}
      }
    }
  }
}
