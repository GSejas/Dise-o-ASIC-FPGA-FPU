#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>


int main(void)
{
  int value;
  while((value=getchar())!=EOF)
    {
      if (value=='S') 
	{
	  value=getchar();
	  if(value!='2') 
	    {
	      while(value!='\n')
		{
		  value=getchar();
		}
	    }
	  else
	    {
	      putchar('S');
	      putchar('2');
	    }
	}
      else putchar(value);
    }
  return 0;
}
