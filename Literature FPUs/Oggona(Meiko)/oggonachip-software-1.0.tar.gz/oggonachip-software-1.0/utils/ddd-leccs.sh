#!/bin/sh
ddd --debugger sparc-rtems-gdb --attach-window $*
