
/* test program to demonstrate use of interrupts */
/* Jiri Gaisler, Gaisler Research, 2001          */

extern void *catch_interrupt(void func(), int irq);
int *leon = (int *) 0x80000000;

enable_irq (int irq) 
{

	leon[0x9c/4] = (1 << irq);	// clear any pending irq
	leon[0x90/4] |= (1 << irq);	// unmaks irq
}

disable_irq (int irq) { leon[0x90/4] &= ~(1 << irq); }	// mask irq

force_irq (int irq) { leon[0x98/4] = (1 << irq); }	// force irq

/* NOTE: NEVER put printf() or other stdio routines in interrupt handlers,
   they are not re-entrant. This (bad) example is just a demo */

void irqhandler(int irq)
{
	printf("Interrupt Handler for vector %d is called\n", irq);
}


#include "../audio_core/audio_core.h"

/* if for PC sound card then we need little endian, if write to file then big */
#include "../musicdata/musicdata1-3.c"

volatile struct audio_core_regs *audioregs = (struct audio_core_regs *) AUDIO_CORE_START;

main()
{
	catch_interrupt(irqhandler, 10);
	catch_interrupt(irqhandler, 11);
	catch_interrupt(irqhandler, 12);
	catch_interrupt(irqhandler, 13);
	catch_interrupt(irqhandler, 14);
	catch_interrupt(irqhandler, 15);
	enable_irq(10);
	enable_irq(11);
	enable_irq(12);
	enable_irq(13);
	enable_irq(14);
	enable_irq(15);
	force_irq(10);
	force_irq(11);
	force_irq(12);
	force_irq(13);
	force_irq(14);
	force_irq(15);

	/* Test the audio core */
	printf("Write start and stop address...\n");
	audioregs->startaddr = (unsigned int) musicdata;
	audioregs->stopaddrr = (unsigned int) (musicdata+sizeof(musicdata));   

	printf("Write 0x5 to control register ...\n");
	audioregs->controlreg = 0x5;
	printf("Read back from control register: 0x%08X\n", audioregs->controlreg);
	printf("Sleeping shortly...\n");
	{ 
	  int i;
	  for( i = 0 ; i < 1000000 ; i++);
	}
	printf("Read back from control register: 0x%08X\n", audioregs->controlreg);
	printf("Content at address 0x80000094 is 0x%08X\n", *(unsigned int *) 0x80000094 );
	printf("Content at address 0x80000098 is 0x%08X\n", *(unsigned int *) 0x80000098 );
	
}



