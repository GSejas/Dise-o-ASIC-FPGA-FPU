/* 
 * Program to convert data from host format to network format 
 *  - host format is usually little indian for ix86
 *  - network format is big endian
 * It reads data from stdin and writes to stdout.
 *
 * ott@linux.thai.net
 */

#include <stdio.h>
#include <netinet/in.h>

int main(void) {
  unsigned int bytes, sizeperelement;
  unsigned short int element, converted;
  unsigned short int elementlow, elementhigh;

  sizeperelement = sizeof(element);
  bytes = fread(&element,1,sizeperelement,stdin);

  while ( bytes != 0 ) {
    /* I wonder why this htonl() doesn't work? */
        converted = htons(element);

    /* fprintf(stderr,"before: element is 0x%08X\n",element); */
    /* Take the lower byte */
	/*
	  elementlow = (unsigned short int) element;    
	  element = element >> 16;
	  elementhigh = (unsigned short int) element;    
	  converted = elementlow;
	  converted = converted << 16 ; 
	  converted = converted + elementhigh;
	*/
    /* fprintf(stderr, "after: element is 0x%08X\n",converted); */

    fwrite(&converted,1,bytes,stdout);
    bytes = fread(&element,1,sizeperelement,stdin);

  }                           

}
