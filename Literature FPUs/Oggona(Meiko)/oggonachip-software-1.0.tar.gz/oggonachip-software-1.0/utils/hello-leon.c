main () {
	printf("Hello World -- LEON Version!!\n");
}
