/*
 * Thread Mutex Program
 * 
 * -test of POSIX's pthread_mutex() function 
 *
 * ott@linux.thai.net
 *
 * $Id: testmutex.c,v 1.2 2002/04/30 14:43:47 pattara Exp $
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/time.h>

#ifdef RTEMS
#include <rtems.h>
/* configuration information */

#define CONFIGURE_INIT

#include <unistd.h>
#include <errno.h>
#include <sched.h>

#include <bsp.h> /* for device driver prototypes */

void* POSIX_Init(void *argument);

/* configuration information */

#define CONFIGURE_APPLICATION_NEEDS_CONSOLE_DRIVER
#define CONFIGURE_APPLICATION_NEEDS_CLOCK_DRIVER

#define CONFIGURE_MAXIMUM_POSIX_THREADS 5
#define CONFIGURE_MAXIMUM_POSIX_MUTEXES 5
#define CONFIGURE_MAXIMUM_POSIX_CONDITION_VARIABLES 5

#define CONFIGURE_POSIX_INIT_THREAD_TABLE

#include <console.h>
#include <confdefs.h>

#endif /* RTEMS */


pthread_mutex_t m;

void getMutex(void* arg) {
  int result;
  char name = *(char *) arg;

  printf("task %c: Trying to lock mutex m..\n", name);
  result =  pthread_mutex_lock(&m);
  printf("task %c: Got mutex a with return code %d\n", name, result);
  sleep(3);
  printf("task %c: Mutex released...\n", name);
  pthread_mutex_unlock(&m);


}


#ifdef LINUX
int main(){
#else
  void* POSIX_Init(void *argument) {
#endif
  pthread_t taskA, taskB;

  printf("Initialize mutexes...\n");
  pthread_mutex_init(&m, NULL);
  
  {
    int task_ret;
    char arg1, arg2;

    arg1 = 'A';
    task_ret = pthread_create(&taskA, NULL, (void *) getMutex, &arg1);
    if (task_ret) {
      perror("pthread_create: taskA");
      exit(EXIT_FAILURE);
    }
    arg2 = 'B';
    task_ret = pthread_create(&taskB, NULL, (void *) getMutex, &arg2);
    if (task_ret) {
      perror("pthread_create: taskB");
      exit(EXIT_FAILURE);
    }
  }
  {
    int result;
    printf("task main: Trying to lock mutex m..\n");
    result =  pthread_mutex_lock(&m);
    printf("task main: Got mutex a with return code %d\n", result);
    sleep(3);
    pthread_mutex_unlock(&m);
    printf("task main: Mutex released...\n");
  }
  pthread_join(taskA,NULL);
  pthread_join(taskB,NULL);
  fprintf(stderr,"Done.\n");

#ifdef LINUX
  return 0;
#else
  exit(EXIT_SUCCESS);
#endif
}

