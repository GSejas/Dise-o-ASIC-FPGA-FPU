/* A program to generate sine-wave sound according to the specified frequency
 *
 * @author Pattara Kiatisevi ott@linux.thai.net
 * 30.01.2002
 *
 * $Id: gensound.c,v 1.2 2002/01/31 17:59:12 pattara Exp $
 *
 */

/***************************************************************/
/* Modify parameters here */
/***************************************************************/

#define SAMPLING_RATE 20000

/* CHANNELS can be 1 or 2 */
#define CHANNELS 1

/* BIT_PER_SAMPLE can be 8, 16 or 32, default = 8 */
#define BIT_PER_SAMPLE 16

/* OUTPUT can be BINARY or TEXT (default) */
#define OUTPUT "TEXT"

/* TESTLENGTH in seconds */
#define TEST_LENGTH 3

/* TESTFREQ in Hertz */
#define TEST_FREQ 1000
/***************************************************************/

#include <math.h>
#include <stdio.h>

#define PI 3.1415926

void gensound(char* soundbuf, int soundbuf_size, int freq, int length) {

  char output8;
  short output16;
  int output32;


  /* 1 period of sampling frequency */
  double onelooptime = 1.0/SAMPLING_RATE;

  /* convert from f to w */
  double w = (double) (2 * PI * freq);

  { 
    int count = 0;
    double run = 0.0;
    int soundbuf_size_unit = soundbuf_size*8/BIT_PER_SAMPLE;

    while ( (run < (double) length) && ( count < soundbuf_size_unit) ) {
      int i;
      double temp_output;
      temp_output = sin(w * (double) run);
      /* make it in range */
      switch (BIT_PER_SAMPLE) {
      case 16 : 
	output16 = (short) (temp_output*32767);
	for (i = 0 ; i < CHANNELS ; i++ ) {
	  *( (short *) soundbuf + count) = output16;
	  count++;
	}
	break;
      case 32:
	output32 = (int) (temp_output*2147483627);
	for (i = 0 ; i < CHANNELS ; i++ ) {
	  *( (int *) soundbuf + count) = output32;
	  count++;
	}
	break;
      default: /* default is 8 bit */
	output8 = (char) (temp_output * 127);
	for (i = 0 ; i < CHANNELS ; i++ ) {
	  *(soundbuf + count) = output8;
	  count++;
	}
	break;
      }
      run = run + onelooptime;
    }
  }
  
}

int main() {
  char* soundbuf;

  int soundbuf_size, test_length, test_freq;

  /* Change sound parameter here */
  test_length = TEST_LENGTH;
  test_freq = TEST_FREQ;

  soundbuf_size = SAMPLING_RATE * BIT_PER_SAMPLE/8 * test_length * CHANNELS;

  soundbuf = (char*) malloc (soundbuf_size);

  if (soundbuf == 0 ) {
    printf("malloc error\n");
    return(-1);
  }

  fprintf(stderr, "Generating the %d Hz sound of length %d seconds, %d channels ... \n", test_freq, test_length, CHANNELS);
  fprintf(stderr, "Total data size: %d bytes \n", soundbuf_size);

  /* generate the sound into the soundbuf */
  gensound(soundbuf, soundbuf_size, test_freq, test_length);

  fprintf(stderr, "Done...\n");

  /* spit out output */
  {
    int i;
    if ( strcmp(OUTPUT,"BINARY") == 0 ) {
      /* binary output */
      for ( i = 0; i < soundbuf_size ; i++) {
	printf("%c", *(soundbuf + i));
      }
    } else {
    /* text output */
      for ( i = 0; i < soundbuf_size*8/BIT_PER_SAMPLE ; i++) {
	switch ( BIT_PER_SAMPLE) {
	case 16:
	  printf("%d:\t%d\n", i,  *( (short*) soundbuf + i));
	  break;
	case 32:
	  printf("%d:\t%d\n", i,  *( (int *) soundbuf + i));
	  break;
	default:
	  printf("%d:\t%d\n", i,  *( (char *) soundbuf + i));
	  break;
	}
      }
    }
  }
}
