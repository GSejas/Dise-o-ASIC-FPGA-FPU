#ifdef RTEMS

/* RTEMS stuff */
#include <rtems.h>
/* configuration information */

#define CONFIGURE_INIT

#include <bsp.h> /* for device driver prototypes */

rtems_task Init( rtems_task_argument argument); /* forward declaration needed */

/* configuration information */

#define CONFIGURE_APPLICATION_NEEDS_CONSOLE_DRIVER
#define CONFIGURE_APPLICATION_NEEDS_CLOCK_DRIVER

#define CONFIGURE_MAXIMUM_TASKS             1

#define CONFIGURE_RTEMS_INIT_TASKS_TABLE
#define CONFIGURE_EXTRA_TASK_STACKS         (3 * RTEMS_MINIMUM_STACK_SIZE)

#include <confdefs.h>

#endif
/* End of RTEMS area */

#include <math.h>
#include <stdio.h>

#ifdef RTEMS
rtems_task Init ( rtems_task_argument ignored) {
#else
int main(){
#endif
	float a = 25;
	float b = 2;
	long result;

	printf("Starting program ... \n");
	result = (long) pow( a, 1.f/b);
	printf(" pow ( %f, 1.f/%f ) = %f, if cast to long = %ld\n",a,b,pow(a,1.f/b), result);
	result = (long) floor(pow(a,1.f/b));
	printf(" (long) floor(pow ( %f, 1.f/%f )) = %ld\n",a,b,result);

#ifdef RTEMS
	exit(0);
#else
	return 0;
#endif
	
}
	
