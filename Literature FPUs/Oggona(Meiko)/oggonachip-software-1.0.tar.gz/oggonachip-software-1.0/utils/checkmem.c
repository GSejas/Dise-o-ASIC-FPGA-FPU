#include <stdlib.h>

int first;

main() {

  int second = 0;
  char *dynamic;

  printf("address of first variable is 0x%08X\n", &first);
  printf("address of second variable (now inside main() )is 0x%08X\n", &second);
  
  while (1) {

    dynamic = (char *) malloc(10000);
    if ( dynamic == 0 ) {
      printf("malloc error .. \n" );
      return(1);
    } else {
      printf("Allocated now %d bytes\n", second);
      second += 10000;
    }
  }
}
