#define BLOCKSIZE 4096

short int musicdata[] = {
  0x1234, 0x5678, 0x90AB, 0xCDEF, 0x1234, 0x5678, 0x90AB, 0xCDEF
};  

int readAudioData(char* buffer,unsigned int size) {
  static pos = 0;
  unsigned int tobecopied;

  /* Size of total music in bytes */
  static unsigned int musicsize = sizeof(musicdata);

  if ( pos + size < musicsize ) {
    tobecopied = size;
  } else {
    tobecopied = musicsize - pos;
  }

  memcpy(buffer, ((char*) musicdata )+ pos, tobecopied);

  pos += tobecopied;

  return tobecopied;
}

void dumpBuffer(char* buffer, unsigned int size) {
  int i;

  for (i = 0 ; i < size ; i++) {
    if ( i/16*16 == i*16/16 ) printf("\n");
    printf("%02X ",(unsigned char) *(buffer + i));
  }
  printf("\n");

}

int main() {
  char* buffer;
  unsigned bytes;
  
  buffer= (char *) malloc (BLOCKSIZE);

  bytes = readAudioData(buffer, 8);
  dumpBuffer(buffer,8);

  if ( *(buffer) == 0x34 ) {
    printf("The machine is little endian.\n");
  } else {
    printf("The machine is big endian.\n");
  }
  exit(0);
}
