#!/bin/sh 
# The script to generate the EXO file to be run on the XSV-800 board

if [ $# -ne 1 ]; then
	echo "Usage: $0 <binary-file>"
	exit 0
fi

export PATH=$PATH:".:../utils/"

FILENAME=$1
RAMSIZE=2048
RAMCS=1  # No.of RAM banks, it's really 2 but we have to set to 1
RAMRWS=0
RAMWWS=0
FREQ=25
BAUD=38400
ROMWS=2
ROMSIZE=1024

set -x
mkprom  -nocomp -v -o $FILENAME.rom -ramsize $RAMSIZE -ramcs $RAMCS -rmw -ramrws $RAMRWS \
	-ramwws $RAMWWS -freq $FREQ -baud $BAUD -romws $ROMWS -romsize $ROMSIZE $1

#	sparc-rtems-objdump -s $FILENAME.rom > $FILENAME.dat; \
#	sparc-rtems-objdump -d $FILENAME.rom > $FILENAME.s

#mrom_corr $FILENAME.rom $FILENAME.newrom

sparc-rtems-objcopy --adjust-vma=0x100000 -O srec $FILENAME.rom $FILENAME.exo

clean_srec < $FILENAME.exo > $FILENAME-soft.exo

set +x
if [ $? -eq 0 ]; then
    echo "Clean up" ...
#    rm -f $FILENAME.rom $FILENAME.newrom 
    echo "Done..."
fi

