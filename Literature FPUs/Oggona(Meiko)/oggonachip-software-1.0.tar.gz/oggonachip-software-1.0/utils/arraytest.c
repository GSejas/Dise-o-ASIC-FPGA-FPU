main() {
  //unsigned int dmabuf[3];
  unsigned short dmabuf[3];

  /*
  dmabuf[0]=0x12345678;
  dmabuf[1]=0x31415926;
  dmabuf[2]=0x14285714;
  */

  dmabuf[0]=0x1234;
  dmabuf[1]=0x3141;
  dmabuf[2]=0x1428;

  printf("dmabuf is 0x%08X\n", dmabuf);

  printf("&(dmabuf[1]) is 0x%08X\n", &(dmabuf[1]));
  printf("dmabuf + 1 0x%08X\n", dmabuf + 1);
  printf("dmabuf[1] is 0x%08X\n", dmabuf[1]);
  printf("*(dmabuf + 1) is 0x%08X\n", *(dmabuf + 1));

  printf("&(dmabuf[2]) is 0x%08X\n", &(dmabuf[2]));
  printf("dmabuf + 2 0x%08X\n", dmabuf + 2);
  printf("dmabuf[2] is 0x%08X\n", dmabuf[2]);
  printf("*(dmabuf + 2) is 0x%08X\n", *(dmabuf + 2));

}
