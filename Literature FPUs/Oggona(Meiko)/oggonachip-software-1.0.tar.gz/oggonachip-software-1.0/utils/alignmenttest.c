#include <stdio.h>

int main () {
  char string[11] = "0123456789";
  int i;

  for ( i = 0 ; i  < sizeof(string) -1 ; i++ ) {
    printf("%d:\t%c\n",i, *(string + i));
  };
  
  return 0;
}
