main() {
  FILE* audio_out;
  const char *audio_out_filename = "audio_out.raw";
  audio_out = fopen(audio_out_filename, "w");

  if ( fwrite(dmabuf, size, 1, audio_out) != 1) {
    printf("Error writing the %s\n",audio_out_filename);
    return(1);
  }
}
