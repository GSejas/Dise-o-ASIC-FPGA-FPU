#include <stdio.h>
#include <malloc.h>

int main () {
  char chksum[30];
  unsigned char * page;
  int i;

  page = malloc(30);
  
  for (i = 0 ; i < 30 ; i++) {
    *(page + i) = - i;
    printf("page[%d]: (signed) %d or (unsigned) %d\n",i, *(signed char *)(page+i),*(page+i));
  }

  memcpy(chksum, page + 22,4);

  for (i = 0; i < 4 ; i++){
    printf("%d:\tchksum: %d\n", i, *(chksum + i));
  }
  
  i=memcmp(chksum,page + 22,4);
  printf("Resule from memcmp(chksum,page+22,4): %d\n",i);
}
