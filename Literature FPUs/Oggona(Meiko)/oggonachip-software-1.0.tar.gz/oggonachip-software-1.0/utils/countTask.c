
void countTask() {
  long starttime, currenttime, sleeptime;
  int i=0;

  /* Get the start time */
  { 
    struct timeval gettime;
    gettimeofday(&gettime,NULL);
    starttime = gettime.tv_sec*1000000 + gettime.tv_usec;
  }
  
  while ( 1 ) {
    {
      struct timeval gettime;
      gettimeofday(&gettime,NULL);
      currenttime = gettime.tv_sec*1000000 + gettime.tv_usec;
    };
    sleeptime = 1000000 - ( currenttime - starttime - i * 1000000);
    printf("Elapsed time (second): %2d\n", i++ );
    {
      struct timespec tmp;
      if ( sleeptime >= 1000000 ) {
	sleeptime -= 1000000;
	tmp.tv_sec = 1;
      } else {
	tmp.tv_sec = 0;
      }
      tmp.tv_nsec = sleeptime * 1000;
      printf("issuing nanosleep of %ld\n",tmp.tv_nsec);
      if ( nanosleep(&tmp,NULL) != 0 ) { 
	perror("nanosleep");
	exit(1);
      }
    }
  }
}
