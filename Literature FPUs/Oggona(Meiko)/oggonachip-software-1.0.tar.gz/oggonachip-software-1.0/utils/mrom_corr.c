#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>



int main(int argc, char* argv[])
{
  FILE *src;
  FILE *dest;
  char *inputfile, *outputfile;

  int value;

  if ( argc != 3 ) {
	  printf("Usage: mrom_corr <input-file> <output-file>\n");
	  return(0);
  } else {
	  inputfile = argv[1];
	  outputfile = argv[2];
  }
  src=fopen(inputfile,"rb");
  dest=fopen(outputfile,"wb");

  while(feof(src)==0)
    {
      value=getc(src);
      if (feof(src)==0)
	{
	  if (value==0x00) 
	    {
	      putc(value,dest);
	      value=getc(src);
	      if (feof(src)==0)
		{
		  if(value==0x01) 
		    {
		      putc(value,dest);
		      value=getc(src);
		      if(value==0xC0)
			{
			  putc(0xC0,dest);
			  putc(0x22,dest); //waitstaits rom
			  putc(0x00,dest);
			  putc(0x00,dest);
			  putc(0x10,dest);
			  putc(0x70,dest);
			  for (value=0;value<5;value++) getc(src);
			}
		      else putc(value,dest);
		    }
		  else putc(value,dest);
		}
	    }      
	  else putc(value,dest);
	}
    }
  fclose(src);
  fclose(dest);
      
  return 0;
}
