/*  sound.h
 *
 *  Sound Device Driver for RTEMS on LEON/XSV-800 board
 *
 *  @author Pattara Kiatisevi
 *
 *  $Id: sound.h,v 1.3 2002/06/10 16:17:07 pattara Exp $
 */

#ifndef _SOUND_DRIVER_h
#define _SOUND_DRIVER_h

#ifdef __cplusplus
extern "C" {
#endif

#define SOUND_DRIVER_TABLE_ENTRY \
  { sound_initialize, sound_open, sound_close, \
    sound_read, sound_write, sound_control }

  /* ioctl stuff */
#define SNDCTL_DSP_SETFMT 0
#define SNDCTL_DSP_CHANNELS 1
#define SNDCTL_DSP_SPEED 2


rtems_device_driver sound_initialize(
  rtems_device_major_number,
  rtems_device_minor_number,
  void *
);

rtems_device_driver sound_open(
  rtems_device_major_number,
  rtems_device_minor_number,
  void *
);

rtems_device_driver sound_close(
  rtems_device_major_number,
  rtems_device_minor_number,
  void *
);

rtems_device_driver sound_read(
  rtems_device_major_number,
  rtems_device_minor_number,
  void *
);

rtems_device_driver sound_write(
  rtems_device_major_number,
  rtems_device_minor_number,
  void *
);

rtems_device_driver sound_control(
  rtems_device_major_number,
  rtems_device_minor_number,
  void *
);

#ifdef __cplusplus
}
#endif

#endif
/* end of include file */
