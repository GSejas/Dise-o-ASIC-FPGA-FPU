/*
 * A simple rtems program to test sound device driver
 * 
 * ott@linux.thai.net
 */

#include <rtems.h>
/* configuration information */

#define CONFIGURE_INIT

#include <bsp.h> /* for device driver prototypes */

rtems_task Init( rtems_task_argument argument);	/* forward declaration needed */

/* configuration information */

#define CONFIGURE_APPLICATION_NEEDS_CONSOLE_DRIVER
#define CONFIGURE_APPLICATION_NEEDS_CLOCK_DRIVER

#define CONFIGURE_MAXIMUM_TASKS             4

#define CONFIGURE_RTEMS_INIT_TASKS_TABLE

#define CONFIGURE_EXTRA_TASK_STACKS         (3 * RTEMS_MINIMUM_STACK_SIZE)

#define CONFIGURE_HAS_OWN_DEVICE_DRIVER_TABLE

#define CONFIGURE_MAXIMUM_DRIVERS 3

#define CONFIGURE_LIBIO_MAXIMUM_FILE_DESCRIPTORS 5

#include <console.h>
#include "sound.h"

rtems_driver_address_table Device_drivers[] = {
        CONSOLE_DRIVER_TABLE_ENTRY,
	CLOCK_DRIVER_TABLE_ENTRY,
        SOUND_DRIVER_TABLE_ENTRY,
        { NULL, NULL, NULL, NULL, NULL, NULL }
};

#include <confdefs.h>

#include <stdio.h>
#include <fcntl.h>

#define BUF_SIZE 4096
#define DEVICE_NAME "/dev/dsp"

int audio_fd;

/* if for PC sound card then we need little endian, if write to file then big */
#include "../musicdata/musicdata1-3.c"

rtems_task Init(
  rtems_task_argument ignored
)
{

  printf("Try to open %s...\n",DEVICE_NAME);
  /* Open sound device */
  if ( (audio_fd = open(DEVICE_NAME, O_WRONLY, 0) ) == -1 ) {
    /* open of a device failed */
    perror(DEVICE_NAME);
    exit(1);
  }
  
  printf("Open sound device successfull\n");

  /* Set up the parameters */
  { 
    /*
      int format = AFMT_S16_LE;
      int channels = 1;
    */
    int speed  = 22050; /* depends on the input file */
    /*
      if ( ioctl(audio_fd, SNDCTL_DSP_SETFMT, &format) == -1 ) {
      perror("SNDCTL_DSP_SETFMT");
      exit(1);
      } 
      if ( ioctl(audio_fd, SNDCTL_DSP_CHANNELS, &channels) == -1 ) {
      perror("SNDCTL_DSP_CHANNELS");
      exit(1);
    }
    */
    if ( ioctl(audio_fd, SNDCTL_DSP_SPEED, &speed) == -1 ) {
      perror("SNDCTL_DSP_SPEED");
      exit(1);
    }
    
  }

  /* Read the sound file content and play it */

  {
    int inputsize = sizeof(musicdata);
    unsigned char * audio_buffer = (unsigned char*) musicdata;
    write(audio_fd, audio_buffer, inputsize);
  }

  printf("Zugabe!!\n");

  {
    int inputsize = sizeof(musicdata);
    unsigned char * audio_buffer = (unsigned char*) musicdata;
    write(audio_fd, audio_buffer, inputsize);
  }

  /* Close */
  if ( close(audio_fd) < 0 ) {
   perror("close");
   exit(1);
  }

  printf("Close sound device successfull\n");

  exit(0);

}
