/* sound.c
 *
 * Sound Device Driver for RTEMS on LEON/XSV-800 board
 *
 * @author Pattara Kiatisevi
 * $Id: sound.c,v 1.15 2002/06/24 15:42:16 pattara Exp $
 */

#include <bsp.h>
#include <rtems/libio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <time.h>

#include <fcntl.h>

#include "sound.h"
#include "../audio_core/audio_core.h"

#define IRQNUMBER 13

#ifndef DEBUG

#ifdef DEBUG_RTEMS_DEVICE_DRIVER
#define DEBUG(x, y...) { fprintf (stderr, x, ## y); }
#else
#define DEBUG(x, y...) 
#endif

#endif

volatile struct audio_core_regs *audioregs = (struct audio_core_regs *) AUDIO_CORE_START;
static char alreadyopened = 0;

/* semaphore to protect overall system */
rtems_id sound_sem;
/* semaphore for write() function */
rtems_id sound_write_sem;

void enable_irq (int irq) 
{
  *(unsigned long *) (0x80000090) |= ( 1 << irq );
}

void clear_irq (int irq) 
{
  *(unsigned long *) (0x80000094) &= ~ ( 1 << irq );
}

void force_irq (int irq) { 
  *(unsigned long *) (0x80000098) = ( 1 << irq ); 
}

/* isr for interrupts from audio core */
rtems_isr handleSoundIrq (rtems_vector_number vector);

/* ISR */
rtems_isr handleSoundIrq
(
 rtems_vector_number vector
)
{
  DEBUG("controlreg is 0x%08X\n",audioregs->controlreg);
  audioregs->controlreg &= ~0x8; /* 1000 */
  DEBUG("Clear the irq bit ...\n");
  DEBUG("controlreg is 0x%08X\n",audioregs->controlreg);
  DEBUG("External interrupt received with vector 0x%x\n", vector);
  /* sound play is finished, wake the task in write() up */
  rtems_semaphore_release(sound_write_sem);
  // This irq pending doesn't seem to work
  //  DEBUG("Clear IRQ pending register...\n");
  //clear_irq(IRQNUMBER);
}
 
/*
 *  Sound Device Driver Entry Points
 *
 */
 
rtems_device_driver sound_initialize(
  rtems_device_major_number  major,
  rtems_device_minor_number  minor,
  void                      *arg
)
{
  rtems_status_code status;

  /*
   *  Register Device Names
   */

  status = rtems_io_register_name( "/dev/dsp", major, 0 );
  if (status != RTEMS_SUCCESSFUL)  rtems_fatal_error_occurred(status);

  /* Create semaphores */
  status = rtems_semaphore_create(rtems_build_name('D','S','P',' '),
				  1,
				  RTEMS_BINARY_SEMAPHORE|
				  RTEMS_INHERIT_PRIORITY|
				  RTEMS_PRIORITY,
				  RTEMS_NO_PRIORITY,
				  &sound_sem);
  if (status != RTEMS_SUCCESSFUL) rtems_fatal_error_occurred(status);  
  status = rtems_semaphore_create(rtems_build_name('D','S','P',' '),
				  0,
				  RTEMS_COUNTING_SEMAPHORE,
				  RTEMS_NO_PRIORITY,
				  &sound_write_sem);
   if (status != RTEMS_SUCCESSFUL) rtems_fatal_error_occurred(status);      

  /*
   *  Initialize Hardware
   */

  /* Set default sampling frequency: audioregs->scalerupr
   *   0 = 44.1 kHz
   *   1 = 22.05 kHz
   *   2 = 11.025 kHz
   */
  audioregs->scalerupr = 0;

  return RTEMS_SUCCESSFUL;
}


rtems_device_driver sound_open(
  rtems_device_major_number major,
  rtems_device_minor_number minor,
  void                    * arg
)
{
  /* rtems_libio_open_close_args_t *args = arg; */
  rtems_status_code sc;

  /* before enter the code */
  sc=rtems_semaphore_obtain(sound_sem,RTEMS_WAIT,RTEMS_NO_TIMEOUT);
  if (sc!=RTEMS_SUCCESSFUL) return sc;  

  if ( alreadyopened == 1 ) {
    /* We always assume O_NONBLOCK for now */
    /* and do not forget to release semaphore */
    rtems_semaphore_release(sound_sem); 
    return RTEMS_RESOURCE_IN_USE;
  } else {
    alreadyopened = 1;

    /* install the isr */
    {
      rtems_status_code sc;
      rtems_isr_entry old_handle;
     
      DEBUG("sound_open: enable interrupt and installing interrupt hander...\n");
      /* first unmask the irq */
      enable_irq(IRQNUMBER);
      /* install interrupt handler at irq value + 0x10 */
      sc = rtems_interrupt_catch (handleSoundIrq, IRQNUMBER + 0x10, &old_handle);
      if ( sc != 0 ) {
	printf("sound_open: Error installing the interrupt handler (%d)...\n",sc);
	exit(1);
      }
    }

    /* force_irq(IRQNUMBER); */
  
    printf("/dev/dsp opened...\n");
    /* and do not forget to release semaphore */
    rtems_semaphore_release(sound_sem); 
    return RTEMS_SUCCESSFUL;
  }
}
 
rtems_device_driver sound_close(
  rtems_device_major_number major,
  rtems_device_minor_number minor,
  void                    * arg
)
{
  printf("/dev/dsp closed...\n");
  alreadyopened = 0;
  return RTEMS_SUCCESSFUL;
}

/*
typedef struct {
    rtems_libio_t          *iop;
    off_t                   offset;
    unsigned8              *buffer;
    unsigned32              count;
    unsigned32              flags;
    unsigned32              bytes_moved;
} rtems_libio_rw_args_t;
*/

rtems_device_driver sound_read(
  rtems_device_major_number major,
  rtems_device_minor_number minor,
  void                    * arg
)
{
  return RTEMS_SUCCESSFUL;
}

int writeToHardware(unsigned int startaddr, unsigned int stopaddr) {
  int sc;
      
  DEBUG("writeToHardware: write start and stop address...\n");
  /* set the start address to be DMAed */
  audioregs->startaddr = startaddr;
  audioregs->stopaddrr = stopaddr;
  
  /* loop clear the rest interrupts */
  DEBUG("writeToHardware: clear all previous releases..\n");
  do {
    sc=rtems_semaphore_obtain(sound_write_sem,RTEMS_NO_WAIT,RTEMS_NO_TIMEOUT);
  } while ( sc != RTEMS_UNSATISFIED );

  /* core is free */

  DEBUG("writeToHardware: start the audio core...\n");
  audioregs->controlreg = 0x9; /* 1001 */

  return RTEMS_SUCCESSFUL;
}
 
rtems_device_driver sound_write(
  rtems_device_major_number major,
  rtems_device_minor_number minor,
  void                    * arg
)
{
  /* FIXME: No appropriate handling for concurrency issue yet */
  rtems_libio_rw_args_t* args = arg;
  rtems_status_code sc;

  DEBUG("Request to write %d bytes of data to /dev/dsp...\n",args->count);

  /* before enter the code */
  sc=rtems_semaphore_obtain(sound_sem,RTEMS_WAIT,RTEMS_NO_TIMEOUT);
  if (sc!=RTEMS_SUCCESSFUL) return sc;   
  
  DEBUG("sound_write: call to writeToHardware() ..\n");
  writeToHardware((unsigned int) args->buffer,(unsigned int) (args->buffer + args->count));
 
  /* wait until the interrupt service routine wake me up */
  DEBUG("sound_write: waiting for interrupt from hardware when music was played\n");

  sc=rtems_semaphore_obtain(sound_write_sem,RTEMS_WAIT,RTEMS_NO_TIMEOUT);
  if (sc!=RTEMS_SUCCESSFUL) return sc;    

  /* and do not forget to release semaphore */
  rtems_semaphore_release(sound_write_sem); 

  rtems_semaphore_release(sound_sem);  
  
  DEBUG("Done...\n");

  return RTEMS_SUCCESSFUL;
}

/* from libio.h 
typedef struct {
    rtems_libio_t          *iop;
    unsigned32              command;
    void                   *buffer;
    unsigned32              ioctl_return;
} rtems_libio_ioctl_args_t;
*/
 
rtems_device_driver sound_control(
  rtems_device_major_number major,
  rtems_device_minor_number minor,
  void                    * arg
)
{
  rtems_libio_ioctl_args_t* args = arg;

  /* Only setting of sampling frequency is implemented */
  if ( args->command == 2 ) {
    int speed = * (int*) (args->buffer);
    switch ( speed) {
    case 11025 :
      audioregs->scalerupr = 2;
      break;
    case 22050 :
      audioregs->scalerupr = 1;
      break;
    default :
      /* Default to 44100 Hz */
      audioregs->scalerupr = 0;
      speed = 44100;
    }
    fprintf(stderr, "Set sampling frequency of audio output device to %d ... \n",speed);
  }

  return RTEMS_SUCCESSFUL;
}

