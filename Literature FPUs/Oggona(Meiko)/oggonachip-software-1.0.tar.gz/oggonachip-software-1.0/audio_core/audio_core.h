#ifndef __ASSEMBLER__

struct audio_core_regs {
  volatile unsigned int controlreg; /* 0x00 */
  volatile unsigned int startaddr;  /* 0x04 */ 
  volatile unsigned int stopaddrr;  /* 0x08 */
  volatile unsigned int scalerupr;  /* 0x0C */
  volatile unsigned int displcontr; /* 0x10 */	
  volatile unsigned int buttonreg;  /* 0x14 */
  volatile unsigned int act_mem_adr;/* 0x18 */
};

#define	AUDIO_CORE_START    0x80000200 
#define	AUDIO_CORE_END      0x8000021C

#define AUDIO_CORE_SIZE     0x1C

#define AUDIO_CORE_CONTROLREG  0x00
#define AUDIO_CORE_STARTADDR   0x04
#define AUDIO_CORE_STOPADDRR   0x08
#define AUDIO_CORE_SCALERUPR   0x0C
#define AUDIO_CORE_DISPLCONTR  0x10
#define AUDIO_CORE_BUTTONREG   0x14
#define AUDIO_CORE_ACT_MEM_ADR 0x18

#endif
