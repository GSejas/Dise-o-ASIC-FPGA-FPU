/* 
   Audio core module to be included by ../tsim-io/io.c .

   @author Pattara Kiatisevi
   $Id: audio_core.c,v 1.15 2002/06/10 16:15:59 pattara Exp $
*/

#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/soundcard.h>


#include "audio_core.h"

#define DEVICE_NAME "/dev/dsp"
#define AUDIO_OUT_FILENAME "audioout.raw"
#define SAMPLING 44010
#define CHANNELS 2

#define IRQNUMBER 13
#define IRQLEVEL 1

struct audio_core_regs *audio_core;

int audio_fd;
FILE* audio_out;

void playsound(int* dmabuf, int size) {

  /* Read the sound file content and play it */
  {
    int writelen;
    if ( ( writelen = write(audio_fd, (unsigned char*) dmabuf, size ) ) == -1 ) {
      perror("io: AUDIO_CORE: audio write");
      exit(1);
    }
    if ( writelen !=size ) {
      fprintf(stderr,"io: AUDIO_CORE: Error: read %d bytes but can write only %d bytes\n", size, writelen);
      exit(1);
    }
  } 

}

/*
#include <kde/artsc/artsc.h>
int playsound_arts(int* dmabuf, int size)
{
  arts_stream_t stream;
  char buffer[8192];
  int bytes;
  int errorcode;

  errorcode = arts_init();
  if (errorcode < 0)
    {
      fprintf(stderr, "arts_init error: %s\n", arts_error_text(errorcode));
      return 1;
    }

  stream = arts_play_stream(44100, 16, 2, "artsctest");


  errorcode = arts_write(stream, (char *) dmabuf, size*sizeof(dmabuf[0]) );
  if(errorcode < 0) {
    fprintf(stderr, "arts_write error: %s\n", arts_error_text(errorcode));
    return 1;
  }

  arts_close_stream(stream);
  arts_free();

  return 0;
}                                       

*/


int writetofile(int* dmabuf, int size) {

  DEBUG("io: AUDIO_CORE: Writing data of size %d bytes to file %s\n", size, AUDIO_OUT_FILENAME);
  if ( fwrite(dmabuf, size, 1, audio_out) != 1 ) {
    fprintf(stderr, "io: AUDIO_CORE: Error writing the %s\n", AUDIO_OUT_FILENAME);
    return(1);
  }
  return(0);
}

static void audio_core_init() 
{

  printf("io: AUDIO_CORE: Audio-core initialized at 0x%x\n", AUDIO_CORE_START);
  printf("io: AUDIO_CORE: time = %ld\n",(long)simif.simtime());
   
  audio_core = (struct audio_core_regs *) malloc (AUDIO_CORE_SIZE);
  audio_core->controlreg = 0;
  audio_core->startaddr  = 0;
  audio_core->stopaddrr  = 0;
  audio_core->scalerupr  = 0;
  audio_core->displcontr = 0;
  audio_core->buttonreg  = 0;
  audio_core->act_mem_adr= 0;


  /* Open sound device, check first if we can open. NOT BEAUTIFUL, FIXME */
  if ( (audio_fd = open(DEVICE_NAME, O_WRONLY | O_NONBLOCK)) != -1 ) {
    close(audio_fd);
    audio_fd = open(DEVICE_NAME, O_WRONLY );
  }

  if ( audio_fd == -1 ) {
    /* open of a device failed */
    fprintf(stderr, "io: AUDIO_CORE: Open %s failed, output to file %s instead...\n",DEVICE_NAME, AUDIO_OUT_FILENAME);
    
    if ( (audio_out = fopen(AUDIO_OUT_FILENAME, "wb")) == NULL ) {
      fprintf(stderr,"io: AUDIO_CORE: Cannot open output sound file, exiting...\n");
      exit(1);
    }
  } else {
    
    fprintf(stderr, "io: AUDIO_CORE: Open of %s successful..\n", DEVICE_NAME);
    /* Set up the parameters */
    {
      int speed  = SAMPLING;
      int channels = CHANNELS;
      int format = AFMT_S16_LE;

      if ( ioctl(audio_fd, SNDCTL_DSP_SETFMT, &format) == -1 ) {
	perror("SNDCTL_DSP_SETFMT");
	exit(1);
      }
      if ( ioctl(audio_fd, SNDCTL_DSP_CHANNELS, &channels) == -1 ) {
	perror("SNDCTL_DSP_CHANNELS");
	exit(1);
      }
      if ( ioctl(audio_fd, SNDCTL_DSP_SPEED, &speed) == -1 ) {
	perror("SNDCTL_DSP_SPEED");
	exit(1);
      }
    }
  }
};

static void audio_core_exit() {

  printf("Audio-core exit\n");
  /* Close */
  if ( audio_fd != -1) { 
    close(audio_fd);
  } else {
    fclose(audio_out);
  }
  return;
};

/* I/O read/write. Called on I/O or undecoded access. Should return 0 on
   success, 1 on memory error (MEXC will be generated). Data should be
   retuned in *data, number of BUSRDY waitstates should be returned in *ws.
   Size is encoded as: 0=byte, 1=half-word, 2=word, 3=doubel-word  */

static int audio_core_read(address, data, ws) 
unsigned int address, *data, *ws; 
{ 
    *ws = 4;

    DEBUG("Audio core accesssed at 0x%08X\n", address); 
    if ((address >= AUDIO_CORE_START) && (address < AUDIO_CORE_END)) {
      /* make it relative instead of absolute */
      address -= AUDIO_CORE_START;
      /* alignment */
      address &= ~3;
      switch (address)	{
      case AUDIO_CORE_CONTROLREG :  
	DEBUG("io: AUDIO_CORE: Control register is accessed!\n");
	*data = audio_core->controlreg;
	break;
      case AUDIO_CORE_STARTADDR :  
	DEBUG("io: AUDIO_CORE: Start address register is accessed!\n");
	*data = audio_core->startaddr;
	break;
      case AUDIO_CORE_STOPADDRR :  
	DEBUG("io: AUDIO_CORE: Stop address register is accessed!\n");
	*data = audio_core->stopaddrr;
	break;
      case AUDIO_CORE_SCALERUPR :  
	DEBUG("io: AUDIO_CORE: SCALERUPR register is accessed!\n");
	*data = audio_core->scalerupr;
	break;
      case AUDIO_CORE_DISPLCONTR :
	DEBUG("io: AUDIO_CORE: Display controller is accessed!\n");
	*data = audio_core->displcontr;
	break;
      case AUDIO_CORE_BUTTONREG :  
	DEBUG("io: AUDIO_CORE: Button register is accessed!\n");
	*data = audio_core->buttonreg;
	break;
      case AUDIO_CORE_ACT_MEM_ADR :  
	DEBUG("io: AUDIO_CORE: ACT_MEM_ADR register is accessed!\n");
	*data = audio_core->act_mem_adr;
	break;
      default:
	DEBUG("io: AUDIO_CORE: This should not happen! Error!\n");
	break;
      }
      
      return(0);
    } else
      return(1);
}

static int audio_core_write(address, data, ws, size) 
unsigned int address, *data, *ws, size; 
{ 
  /* save for local use */
  int tmpdata = 0;

  *ws = 4;

  DEBUG("io: AUDIO_CORE:  io_write at 0x%08X\n", address);

  if ((address >= AUDIO_CORE_START) && (address < AUDIO_CORE_END)) {
    address -= AUDIO_CORE_START;
    switch(size) {
    case 2:
      /* only word access is allowed */
      /* alignment */
      address &= ~3;
      switch (address)	{
      case AUDIO_CORE_CONTROLREG :  
	DEBUG("io: AUDIO_CORE:  Control register is accessed!\n");
	tmpdata = *data;
	/* only the last 5 bits are used */
	tmpdata &= 0x1F;
	/* save the value */
	audio_core->controlreg = tmpdata;
	/* first bit, Audiocore 1=on, 0 = off */
	if ( (tmpdata & 0x1) != 0 ) {
	  DEBUG("io: AUDIO_CORE: Audiocore is turned on..\n");
	} else {
	  DEBUG("io: AUDIO_CORE: Audiocore is turned off..\n");
	  return(0);
	}
	/* third bit, loopmode,  1=on, 0 = off */
	if ( (tmpdata & 0x4 ) != 0) {
	  DEBUG("io: AUDIO_CORE: loopmode is turned on..(not yet implemented) \n");
	} else {
	  DEBUG("io: AUDIO_CORE: loopmode is off..(not yet implemented) \n");
	}
	/* fourth bit, irqen,  1=on, 0 = off */
	if ( (tmpdata & 0x8 ) != 0) {
	  DEBUG("io: AUDIO_CORE: irqen is turned on..\n");
	} else {
	  DEBUG("io: AUDIO_CORE: irqen is turned off..\n");
	}
	/* fifth bit, irq 1=on, 0 = off */
	if ( (tmpdata & 0x10) != 0 ) {
	  DEBUG("io: AUDIO_CORE: irq bit is actually not writable)\n");
	} else {
	  DEBUG("io: AUDIO_CORE: irq bit is actually not writable\n");
	}
	/* second bit, Aufnahme 1=record, 0=play */
	if ( (tmpdata & 0x2) != 0) {
	  DEBUG("io: AUDIO_CORE: Recording not yet implemented ... ");
	} else {
	  DEBUG("io: AUDIO_CORE: Playback the content ...");
	  /* Play back */
	  {
	    int size, i;
	    int * dmabuf;

	    /* DMA read */
	    /* only 32-bit word transfers are allowed */
	    size = (audio_core->stopaddrr - audio_core->startaddr);
	    dmabuf = (int *) malloc(size * sizeof(int));
	    if ( dmabuf == 0 ) {
	      fprintf(stderr, "io: AUDIO_CORE: malloc for dmabuf error\n");
	      return(-1);
	    }
	    DEBUG("io: AUDIO_CORE: Starting DMA read of %d bytes from 0x%08X to 0x%08X ...\n", 
		   size, audio_core->startaddr, audio_core->stopaddrr);
	    /* last argument of dma_read seems to be no. of words */
	    if ( ioif.dma_read(audio_core->startaddr, dmabuf, size/4 ) != 0 ) {
		    fprintf(stderr, "io: DMA bus error\n");
		    return(1);
	    }
	    DEBUG("io: AUDIO_CORE: Data read are:\n");
	    for ( i = 0; i < size/4 && i < 20 ; i = i++ ) {
	      DEBUG("io: AUDIO_CORE: 0x%08X = 0x%08X or %d\n", audio_core->startaddr + i*4, dmabuf[i], dmabuf[i]);
	    }
	    if ( size/4 > i ) {
	      DEBUG("[more] ...\n");
	    }

	    /* Play the sound */
	    DEBUG("io: AUDIO_CORE: audio_fd = %d\n",audio_fd);
	    if ( audio_fd != -1 ) { 
	      playsound(dmabuf,size);
	    } else {
	      writetofile(dmabuf,size);
	    }

	    free(dmabuf);

	    /* Send interrupt to LEON */
	    if ( (audio_core->controlreg & 0x8) != 0 ) {
	      DEBUG("io: AUDIO_CORE: send interrupt to LEON...\n");
	      ioif.set_irq(IRQNUMBER,IRQLEVEL);
	      DEBUG("io: AUDIO_CORE: irq sent..\n");
	    }

	    /* reset the last bit */
	    audio_core->controlreg &= ~0x1;
	  }
	}
	break;
      case AUDIO_CORE_STARTADDR :  
	DEBUG("io: AUDIO_CORE: Start address register is accessed!\n");
	audio_core->startaddr = *data;
	DEBUG("io: AUDIO_CORE: startaddr set to %08X\n", audio_core->startaddr);
	break;
      case AUDIO_CORE_STOPADDRR :  
	DEBUG("io: AUDIO_CORE: Stop address register is accessed!\n");
	audio_core->stopaddrr = *data;
	DEBUG("io: AUDIO_CORE: stopaddrr set to %08X\n", audio_core->stopaddrr);
	break;
      case AUDIO_CORE_SCALERUPR :  
	DEBUG("io: AUDIO_CORE: SCALERUPRl register is accessed!\n");
	audio_core->scalerupr = *data;
	DEBUG("io: AUDIO_CORE: scalerups set to %08X\n", audio_core->scalerupr);
	/* Set the output sampling frequency in case of we output to real audio device */
	if ( audio_fd != -1 ) {
	  int speed;
	  switch( *data ) {
	  case 1 :
	    speed = 22050;
	    break;
	  case 2:
	    speed = 11025;
	    break;
	  default:
	    speed = 44100;
	    break;
	  }
	  DEBUG("io: AUDIO_CORE: set SNDCTL_DSP_SPEED to %d..\n",speed);
	  if ( ioctl(audio_fd, SNDCTL_DSP_SPEED, &speed) == -1 ) {
	    perror("SNDCTL_DSP_SPEED");
	    exit(1);
	  }
	}
	break;
      case AUDIO_CORE_DISPLCONTR :
	DEBUG("io: AUDIO_CORE: Display controller is accessed!\n");
	audio_core->displcontr = *data;
	tmpdata = *data;
	/* Check if the 9th bit = 1 */
	tmpdata &= 0x0100;
	if ( tmpdata != 0x100 ) {
	  /* 9th bit = 0 */
	  fprintf(stderr, "io: AUDIO_CORE: HEX display turns off.\n");
	} else {
	  /* Show only the last 2 bytes */
	  tmpdata = *data;
	  tmpdata &= 0x00FF;
	  fprintf(stderr, "io:AUDIO_CORE:  Hex displays \'%02X\'.\n",tmpdata);
	}
	break;
      case AUDIO_CORE_BUTTONREG : 
	DEBUG("io: AUDIO_CORE: Button register is accessed!\n");
	DEBUG("io: AUDIO_CORE: Button register is for reading only, not for writing!\n");
	break;
      case AUDIO_CORE_ACT_MEM_ADR :  
	DEBUG("io: AUDIO_CORE: ACT_MEM_ADR register is accessed!\n");
	DEBUG("io: AUDIO_CORE: ACT_MEM_ADR register is for reading only, not for writing!\n");
	break;
      default:
	fprintf(stderr, "io: AUDIO_CORE: This should not happen! Error!\n");
      }
      break;
    default:
      fprintf(stderr, "io: AUDIO_CORE: Error, access with size = %d, only word access is allowed!\n",size);
      return(1);
    }
    return(0);
  } else
    return(1);
}

