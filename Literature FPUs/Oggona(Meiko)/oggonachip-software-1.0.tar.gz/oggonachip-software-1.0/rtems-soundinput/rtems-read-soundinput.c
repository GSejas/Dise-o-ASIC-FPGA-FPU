/*
 * A simple rtems program to test sound input device driver
 * 
 * ott@linux.thai.net
 *
 * $Id: rtems-read-soundinput.c,v 1.1 2002/03/03 01:44:18 pattara Exp $
 */

#include <rtems.h>
/* configuration information */

#define CONFIGURE_INIT

#include <bsp.h> /* for device driver prototypes */

rtems_task Init( rtems_task_argument argument);	/* forward declaration needed */

/* configuration information */

#define CONFIGURE_APPLICATION_NEEDS_CONSOLE_DRIVER
#define CONFIGURE_APPLICATION_NEEDS_CLOCK_DRIVER

#define CONFIGURE_MAXIMUM_TASKS             4

#define CONFIGURE_RTEMS_INIT_TASKS_TABLE

#define CONFIGURE_EXTRA_TASK_STACKS         (3 * RTEMS_MINIMUM_STACK_SIZE)

#define CONFIGURE_HAS_OWN_DEVICE_DRIVER_TABLE

#define CONFIGURE_MAXIMUM_DRIVERS 3

#define CONFIGURE_LIBIO_MAXIMUM_FILE_DESCRIPTORS 5

#include <console.h>
#include "soundinput.h"

rtems_driver_address_table Device_drivers[] = {
        CONSOLE_DRIVER_TABLE_ENTRY,
        SOUNDINPUT_DRIVER_TABLE_ENTRY,
        { NULL, NULL, NULL, NULL, NULL, NULL }
};

#include <confdefs.h>

#include <stdio.h>
#include <fcntl.h>

#define BUFFERSIZE 1024
#define DEVICE_NAME "/dev/soundinput"

rtems_task Init(
  rtems_task_argument ignored
)
{
  int soundinput_fd;

  fprintf(stderr, "Try to open %s...\n",DEVICE_NAME);
  /* Open sound input device */
  if ( (soundinput_fd = open(DEVICE_NAME, O_RDONLY, 0) ) == -1 ) {
    /* open of a device failed */
    perror(DEVICE_NAME);
    exit(1);
  }
  
  fprintf(stderr, "Open sound input device successful\n");

  /* Read the sound file content and write it to stdout */

  {
    int size = 0;
    int sum = 0;
    char eof = 0;
    unsigned char buffer[BUFFERSIZE];
    unsigned char header[200];

    //    while ( eof == 0) {
    while ( sum < 200 ) {
      size = read(soundinput_fd, buffer, BUFFERSIZE);
      printf("Reading %d bytes from %s..\n",size,DEVICE_NAME);
      if ( size != BUFFERSIZE) eof = 1;
      { 
	int minsize;
	minsize = ( size > 200 ? 200 : size );
	memcpy(header + sum, buffer, minsize); 
      }
      sum += size;
    }
   
    /* Show first part of data */
    { 
      int i;
      printf("Showing first %d bytes of read data...\n", 200);
      
      for ( i = 0 ; i < 200 ; i++ ) {
	printf("%02X ", header[i]);
	if ( (i+1)/32*32 == (i+1)*32/32) printf("\n");
      }
      printf("\n");
    }
    
    /* Read the rest */
    while ( eof == 0) {
      size = read(soundinput_fd, buffer, BUFFERSIZE);
      if ( size != BUFFERSIZE) eof = 1;
      sum += size;
    }
    printf("Total bytes read from %s: %d\n",DEVICE_NAME, sum); 
  }
  
  /* Close */
  if ( close(soundinput_fd) < 0 ) {
   perror("Closing sound device ...");
   exit(1);
  }

  printf("Closing successfull\n");

  exit(0);

}
