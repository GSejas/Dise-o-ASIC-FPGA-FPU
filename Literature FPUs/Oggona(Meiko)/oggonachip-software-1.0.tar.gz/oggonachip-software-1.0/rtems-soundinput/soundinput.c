/* soundinput.c
 *
 * Sound Input Device Driver for RTEMS on LEON/XSV-800 board
 *
 * @author Pattara Kiatisevi
 * $Id: soundinput.c,v 1.12 2002/07/24 10:51:16 pattara Exp $
 */

#include <bsp.h>
#include <rtems/libio.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>

#include "soundinput.h"

#ifndef DEBUG

#ifdef DEBUG_RTEMS_DEVICE_DRIVER
#define DEBUG(x, y...) { fprintf (stderr, x, ## y); }
#else
#define DEBUG(x, y...) 
#endif

#endif


//#include "../musicdata/musicdata10-2.c"  /* gettin.ogg */
//#include "../musicdata/musicdata6.c"  /* nightbirds.ogg */
//#include "../musicdata/musicdata7.c"  /* nightbirds-q0-bigendian.ogg */
//#include "../musicdata/musicdata11-2.c"  /* nightbirds24-bigendian.ogg */
//#include "../musicdata/musicdata12-2.c"  /* n24-22-bigendian.ogg */
//#include "../musicdata/musicdata13-2.c"  /* n44-44-bigendian.ogg */
//#include "../musicdata/musicdata14-2.c"  /* n24-24-bigendian.ogg */
//#include "../musicdata/musicdata15-2.c"  /* n44-44-q0-bigendian.ogg */
//#include "../musicdata/musicdata16-2.c"  /* n48-48-q0-bigendian.ogg */
//#include "../musicdata/musicdata17-2.c"  /* n24-24-q9-bigendian.ogg */
#include "../musicdata/musicdata18-2.c"  /* gettin24-bigendian.ogg */

static char soundinput_alreadyopened = 0;
unsigned int musicsize = 0;
unsigned char *char_musicdata;


/*
 *  Soundinput Device Driver Entry Points
 *
 */
 
rtems_device_driver soundinput_initialize(
  rtems_device_major_number  major,
  rtems_device_minor_number  minor,
  void                      *arg
)
{
  rtems_status_code status;

  /*
   *  Register Device Names
   */

  status = rtems_io_register_name( "/dev/soundinput", major, 0 );
  if (status != RTEMS_SUCCESSFUL)  rtems_fatal_error_occurred(status);

  /*
   *  Init
   */
  char_musicdata = (unsigned char *) musicdata;
  musicsize = sizeof(musicdata);

  return RTEMS_SUCCESSFUL;
}

/* from rtems/libio.h */
/*
typedef struct {
    rtems_libio_t          *iop;
    unsigned32              flags;
    unsigned32              mode;
} rtems_libio_open_close_args_t;
*/

//struct rtems_libio_tt {
//    rtems_driver_name_t              *driver;
//    off_t                             size;      /* size of file */
//    off_t                             offset;    /* current offset into file */
//    unsigned32                        flags;
//    rtems_filesystem_location_info_t  pathinfo;
//    Objects_Id                        sem;
//    unsigned32                        data0;     /* private to "driver" */
//    void                             *data1;     /* ... */
//    void                             *file_info; /* used by file handlers */
//    rtems_filesystem_file_handlers_r *handlers;  /* type specific handlers */
//};

#ifdef DEBUG_RTEMS_DEVICE_DRIVER
void dump_iop(rtems_libio_open_close_args_t  *arg) {

  printf("Dumping IOP content:\n");
  printf("driver: %s\n", (char*) arg->iop->driver);
  printf("size: %d\n", (int) arg->iop->size);
  printf("offset: %d\n", (int) arg->iop->offset);
  printf("flags: %d\n", (int) arg->iop->flags);
}
#endif

rtems_device_driver soundinput_open(
  rtems_device_major_number major,
  rtems_device_minor_number minor,
  void                    * arg
)
{
  rtems_libio_open_close_args_t *args = arg;
  
  if ( soundinput_alreadyopened == 1 ) {
    /* We always assume O_NONBLOCK for now */
    return RTEMS_RESOURCE_IN_USE;
  } else {
    soundinput_alreadyopened = 1;
    printf("/dev/soundinput opened...\n");

    /* Set variables */
    args->iop->size = musicsize;

#ifdef DEBUG_RTEMS_DEVICE_DRIVER
    dump_iop(args);
#endif

    return RTEMS_SUCCESSFUL;
  }
}
 
rtems_device_driver soundinput_close(
  rtems_device_major_number major,
  rtems_device_minor_number minor,
  void                    * arg
)
{
  printf("/dev/soundinput closed...\n");
  soundinput_alreadyopened = 0;
  return RTEMS_SUCCESSFUL;
}

/*
typedef struct {
    rtems_libio_t          *iop;
    off_t                   offset;
    unsigned8              *buffer;
    unsigned32              count;
    unsigned32              flags;
    unsigned32              bytes_moved;
} rtems_libio_rw_args_t;
*/

rtems_device_driver soundinput_read(
  rtems_device_major_number major,
  rtems_device_minor_number minor,
  void                    * arg
)
{
  /* FIXME: No appropriate handling for concurrency issue yet */
  rtems_libio_rw_args_t* args = arg;

  unsigned int fpos = (unsigned int) args->offset;
  args->bytes_moved = 0;

  //  DEBUG("soundinput: read %d bytes, offset=%d, size = %d \n",args->count, fpos, args->iop->size );
  
  // check the offset range
  if ( fpos < musicsize ) { 
    if ( (fpos + args->count) < musicsize ) {
      /* calculate the possible transfer size */
      args->bytes_moved = args->count;
    } else {
      args->bytes_moved =  (musicsize - fpos);
    }
    memcpy(args->buffer, char_musicdata + fpos, args->bytes_moved);
    //DEBUG("Read done...\n");
    return RTEMS_SUCCESSFUL;
  } else {
    return RTEMS_INVALID_ADDRESS;
  }
}
 
rtems_device_driver soundinput_write(
  rtems_device_major_number major,
  rtems_device_minor_number minor,
  void                    * arg
)
{
  /* FIXME: No appropriate handling for concurrency issue yet */
  // rtems_libio_rw_args_t* args = arg;

  // Write is not yet implemented
    
  return RTEMS_SUCCESSFUL;
}

/* from libio.h 
typedef struct {
    rtems_libio_t          *iop;
    unsigned32              command;
    void                   *buffer;
    unsigned32              ioctl_return;
} rtems_libio_ioctl_args_t;
*/
 
rtems_device_driver soundinput_control(
  rtems_device_major_number major,
  rtems_device_minor_number minor,
  void                    * arg
)
{
  return RTEMS_SUCCESSFUL;
}

