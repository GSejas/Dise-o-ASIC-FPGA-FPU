/*  sound.h
 *
 *  Sound Input Device Driver for RTEMS on LEON/XSV-800 board
 *  (static version contains the content of a song)
 *
 *  @author Pattara Kiatisevi
 *
 *  $Id: soundinput.h,v 1.1 2002/03/03 01:44:18 pattara Exp $
 */

#ifndef _SOUNDINPUT_DRIVER_h
#define _SOUNDINPUT_DRIVER_h

#ifdef __cplusplus
extern "C" {
#endif

#define SOUNDINPUT_DRIVER_TABLE_ENTRY \
  { soundinput_initialize, soundinput_open, soundinput_close, \
    soundinput_read, soundinput_write, soundinput_control }

rtems_device_driver soundinput_initialize(
  rtems_device_major_number,
  rtems_device_minor_number,
  void *
);

rtems_device_driver soundinput_open(
  rtems_device_major_number,
  rtems_device_minor_number,
  void *
);

rtems_device_driver soundinput_close(
  rtems_device_major_number,
  rtems_device_minor_number,
  void *
);

rtems_device_driver soundinput_read(
  rtems_device_major_number,
  rtems_device_minor_number,
  void *
);

rtems_device_driver soundinput_write(
  rtems_device_major_number,
  rtems_device_minor_number,
  void *
);

rtems_device_driver soundinput_control(
  rtems_device_major_number,
  rtems_device_minor_number,
  void *
);

#ifdef __cplusplus
}
#endif

#endif
/* end of include file */
