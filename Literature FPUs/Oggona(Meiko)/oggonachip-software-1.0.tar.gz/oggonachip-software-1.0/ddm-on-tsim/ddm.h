#ifndef __ASSEMBLER__

struct ddmregs {
  volatile unsigned int controlreg; /* 0x00 */
  volatile unsigned int startaddr;  /* 0x04 */ 
  volatile unsigned int stopaddrr;  /* 0x08 */
  volatile unsigned int scalerupr;  /* 0x0C */
  volatile unsigned int displcontr; /* 0x10 */	
  volatile unsigned int buttonreg;  /* 0x14 */
  volatile unsigned int act_mem_adr;/* 0x18 */
};

/* For TSIM  */ 
/*
#define	REGSTART    0x20000000 
#define	REGEND      0x2000001C
*/

/* For XSV-800 */
#define	REGSTART    0x80000200 
#define	REGEND      0x8000001C

#define REGSIZE     0x1C

#define CONTROLREG  0x00
#define STARTADDR   0x04
#define STOPADDRR   0x08
#define SCALERUPR   0x0C
#define DISPLCONTR  0x10
#define BUTTONREG   0x14
#define ACT_MEM_ADR 0x18


#endif
