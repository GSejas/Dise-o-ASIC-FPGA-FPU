#include <stdio.h>

#include "ddm.h"

/* The simple module to test the ddm hardware as implemented in io.c
 * to be used with TSIM
 *
 * @author Pattara Kiatisevi ott@linux.thai.net
 * $Id: ddm-basic-test.c,v 1.2 2002/02/07 16:43:17 pattara Exp $
 */

/* Transfer size = no. of words (4 bytes) to be tested in DMA read transfer */
#define TRANSFERSIZE 375000

struct ddmregs *ddmr = (struct ddmregs *) REGSTART;

volatile unsigned int * test_memory_area;

void hexdisp(unsigned char byte)
{
  ddmr->displcontr=byte|0x100;
}

int main() {
  volatile unsigned int data;

  /* init test memory area */
  test_memory_area = (unsigned int *) malloc(TRANSFERSIZE*sizeof(unsigned int));
  if (test_memory_area == 0) {
    printf("Malloc error ... exiting ...\n");
    return(-1);
  }
  { int i;
  for ( i = 0 ; i < TRANSFERSIZE ; i++) {
    *(test_memory_area + i ) = 0;
  }
  }

  /* begin the test */
  printf("==================================================================\n");
  printf("Testing start address\n");
  printf("==================================================================\n");
  printf("Set startaddr to 0x%08X ... \n", test_memory_area);
  ddmr->startaddr = (unsigned int) test_memory_area;
  data = 0;
  data = ddmr->startaddr;
  fflush(NULL);
  printf("Read back from startaddr [0x%08X]: 0x%08X\n",test_memory_area, data);


  printf("==================================================================\n");
  printf("Testing stop address\n");
  printf("==================================================================\n");
  printf("Set stopaddrr to 0x08X ... \n", test_memory_area + TRANSFERSIZE);
  ddmr->stopaddrr = (unsigned int) (test_memory_area + TRANSFERSIZE);
  data = 0;
  data = ddmr->stopaddrr;
  printf("Read back from stopaddrr [0x%08X]: 0x%08X\n", test_memory_area + TRANSFERSIZE, data);


  printf("==================================================================\n");
  printf("Testing control register\n");
  printf("==================================================================\n");
  printf("Write data in to the test memory area ...\n");
  printf("Write 0x31415926 to address 0x%08X\n", test_memory_area);
  *test_memory_area = 0x31415926;
  printf("Write 0x14285714 to address 0x%08X\n", test_memory_area + 1);
  *(test_memory_area+1) = 0x14285714;
  printf("Write 0x99999999 to address 0x%08X\n", test_memory_area + 2);
  *(test_memory_area+2) = 0x99999999;
  data = 0x1;
  ddmr->controlreg = data;
  data = 0x00;
  data = ddmr->controlreg;
  printf("Read back from control register [0x1]: %X\n", data);


  printf("==================================================================\n");
  printf("Testing scalerupr\n");
  printf("==================================================================\n");
  printf("Set scalerupr to 0x00000001 ... \n");
  ddmr->scalerupr = 0x00000001;
  data = 0xFF;
  data = ddmr->scalerupr;
  printf("Read back from scalerupr [0x00000001]: 0x%08X\n",data);


  printf("==================================================================\n");
  printf("Testing display controller\n");
  printf("==================================================================\n");
  printf("Turn off display...\n");
  ddmr->displcontr = 0x0005;
  printf("Set to display \'05\'\n");
  ddmr->displcontr = 0x0105;
  printf("Set to display \'1C\'\n");
  ddmr->displcontr = 0x011C;
  data = ddmr->displcontr;
  printf("Read data back [0x011C]: 0x%04X\n",data);

  printf("==================================================================\n");
  printf("Testing button register\n");
  printf("==================================================================\n");
  data = 0xFF;
  data = ddmr->buttonreg;
  printf("Read from buttonreg [0x0000]: 0x%04X\n",data);

  printf("==================================================================\n");
  printf("Testing act_mem_adr\n");
  printf("==================================================================\n");
  data = 0xFF;
  data = ddmr->act_mem_adr;
  printf("Read from act_mem_adr [0x0000]: 0x%04X\n",data);
  printf("==================================================================\n");
  
  free(test_memory_area);
			    
}
 
