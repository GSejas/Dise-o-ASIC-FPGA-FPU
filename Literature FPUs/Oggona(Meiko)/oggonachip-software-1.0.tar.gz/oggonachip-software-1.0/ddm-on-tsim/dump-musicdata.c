#include <stdio.h>
#include "musicdata1.c"

main() {
  int i;

  fprintf(stderr, "Dumping %d elements of short data\n", sizeof(musicdata)/sizeof(musicdata[0]));
	 
  for (i = 0 ; i < sizeof(musicdata)/sizeof(musicdata[0]) ; i++ ) {
    //printf("%d\t", i);
    printf("%c", musicdata[i] & 0xFF);
    printf("%c", musicdata[i] >> 8 & 0xFF);
  };
  return(0);
}

  
