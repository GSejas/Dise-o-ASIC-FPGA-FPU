/* A simple program to generate music sound for testing ddm sound playing function
 *
 * @author Pattara Kiatisevi ott@linux.thai.net
 * 01.02.2002
 *
 * $Id: ddm-sound-music-test.c,v 1.8 2002/02/22 18:34:20 pattara Exp $
 *
 */

#include <math.h>
#include <stdio.h>
#include "ddm.h"

/* BIT_PER_SAMPLE = 20 or 16 */
#define BIT_PER_SAMPLE 16

/* CHANNELS = 1 or 2 */
#define CHANNELS 2

#define SAMPLING_RATE 19050

/* Song data in array of short (16 bit) named musicdata[] */
#include "../musicdata/musicdata2.c"

volatile struct ddmregs *ddmr = (struct ddmregs *) REGSTART;
int *soundbuf32;
short *soundbuf16;

int soundsource_samples;

void hexdisp(unsigned char byte)
{
  ddmr->displcontr=byte|0x100;
}

int init() { 
  int test_length = sizeof(musicdata);

  soundsource_samples = test_length/sizeof(musicdata[0]); 
  
  printf("Number of sound samples found in music data: %d\n", soundsource_samples);

  /* malloc for each case */
  if ( BIT_PER_SAMPLE == 20 ) {
    soundbuf32 = (int *) malloc (soundsource_samples * 4 * CHANNELS);
    if (soundbuf32 == 0 ) {
      printf("malloc error\n");
      return(-1);
    }
    printf("Allocated memory of %d bytes for sound buffer\n",soundsource_samples * 4 * CHANNELS);
  } else {
    soundbuf16 = (short *) malloc (soundsource_samples * 2 * CHANNELS);
    if (soundbuf16 == 0 ) {
      printf("malloc error\n");
      return(-1);
    }
    printf("Allocated memory of %d bytes for sound buffer\n",soundsource_samples * 2 * CHANNELS);
  }
  return(0);
}

int main() {

  printf("Sound test program. Sampling rate = %d, Bit-per-sample = %d, %d-channel\n", 
	 SAMPLING_RATE, BIT_PER_SAMPLE, CHANNELS);

  if ( init() != 0 ) {
    printf("Error initializing the program ... \n");
    return(-1);
  }

  {
    int i, flip;

    flip = 1;
    /* Load to memory in order to convert 16 bit -> 20 bit */
    printf("Loading music data to memory ... \n" );
    for ( i = 0; i < soundsource_samples ; i++ ) { 
      if (CHANNELS == 1 ) {
	if ( BIT_PER_SAMPLE == 20 ) {
	  *(soundbuf32 + i) = (int) musicdata[i];
	  /* make it 20 bit */
	  *(soundbuf32 + i) = *(soundbuf32 + i) << 4;
	} else {
	  /* conceptually --> *(soundbuf16 + i) =  musicdata[i]; */
          /* Because of LITTLE ENDIAN --> BIG ENDIAN problem, we swap half-word */
	  if ( i/2*2 == i*2/2 ) {
	    /* even */
	    *(soundbuf16 + i) = musicdata[i+1];
	  } else {
	    *(soundbuf16 + i) = musicdata[i-1];
	  }
	}
      } else {
	/* 2 channels */
	int j=2*i;
	/*printf("i is %d\tj is %d\n",i,j); */
	if ( BIT_PER_SAMPLE == 20 ) {
	  /* for right channel */
	  *(soundbuf32 + j) = (int) musicdata[i];
	  /* make it 20 bit */
	  *(soundbuf32 + j) = *(soundbuf32 + j) << 4;
	  /* and then left */
	  j++;
	  *(soundbuf32 + j) = (int) musicdata[i];
	  /* make it 20 bit */
	  *(soundbuf32 + j) = *(soundbuf32 + i) << 4;
	} else {
	  /* conceptually --> *(soundbuf16 + i) =  musicdata[i]; */
          /* Because of LITTLE ENDIAN --> BIG ENDIAN problem, we swap half-word */
	  /* for left channel */
	  if ( j/2*2 == j*2/2 ) {
	    /* even */
	    *(soundbuf16 + j) = musicdata[i+1];
	  } else {
	    *(soundbuf16 + j) = musicdata[i-1];
	  }
	  /* left channel */
	  j++;
	  if ( j/2*2 == j*2/2 ) {
	    /* even */
	    *(soundbuf16 + j) = musicdata[i+1];
	  } else {
	    *(soundbuf16 + j) = musicdata[i-1];
	  }
	}
	/* printf("i is %d\tj is %d\n",i,j); */
      }
    }
  }
      
  printf("Done...\n");

  /* text out put for debug */
  /*
  {
    int i;
    int maxvalue20 = pow(2,20)/2 -1 ; 
    int maxvalue16 = pow(2,16)/2 -1 ;
    for ( i = 0; i < soundsource_samples ; i++) {
      if ( BIT_PER_SAMPLE == 20 ) {
	printf("%d:\t%d \t or 0x%08X\tor %2.0f%% \n", 
	       i,  *(soundbuf32 + i), *(soundbuf32 + i), (*(soundbuf32+i))*100.0/maxvalue20 );
      } else {
	printf("%d:\t%d \t or 0x%04X\tor %2.0f%% \n", 
	       i,  *(soundbuf16 + i), *(soundbuf16 + i) & 0xFFFF, (*(soundbuf16+i))*100.0/maxvalue16 );
      }
    }
  }
  */

  printf("Now start to play the sound ... \n");
  /* set the sampling frequency to 20,000 Hz */
  ddmr->scalerupr = 1;
  if ( BIT_PER_SAMPLE == 20 ) {
    /* set the sound location to be read */
    ddmr->startaddr = (unsigned int) soundbuf32;
    ddmr->stopaddrr = (unsigned int) (soundbuf32 + soundsource_samples*CHANNELS) ;
  } else {
    /* set the sound location to be read */
    ddmr->startaddr = (unsigned int) soundbuf16;
    ddmr->stopaddrr = (unsigned int) (soundbuf16 + soundsource_samples*CHANNELS) ;
  }

  /* play it */
  ddmr->controlreg = 0x1;
  /* HEX display */
  hexdisp(0x55);

  if ( BIT_PER_SAMPLE == 20 ) {
    free(soundbuf32);
  } else {
    free(soundbuf16);
  }
}
