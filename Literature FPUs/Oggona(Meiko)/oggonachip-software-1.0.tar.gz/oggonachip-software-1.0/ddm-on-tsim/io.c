/* 
   IO module to behave as a DDM hardware developed by Daniel Bretz,
   modified from the TSIM's example io.c.

   @author Pattara Kiatisevi
   $Id: io.c,v 1.4 2002/02/22 18:33:56 pattara Exp $
*/

#include "tsim.h"
#include <stdio.h>
#include <string.h>
#include <malloc.h>

#include "ddm.h"

#define AUDIO_OUT_FILENAME "audioout.raw"

struct ddmregs *ddmr;

/* called on simulator exit */
static void io_exit() 
{
   printf("io_exit: releasing flash memory\n");
   free(ddmr);
}

static void io_init() 
{

  printf("io_init: DDM Core initializing at 0x%x\n", REGSTART);
  printf("time = %d\n",(long)simif.simtime());
   
  ddmr = (struct ddmregs *) malloc (REGSIZE);
  ddmr->controlreg = 0;
  ddmr->startaddr  = 0;
  ddmr->stopaddrr  = 0;
  ddmr->scalerupr  = 0;
  ddmr->displcontr = 0;
  ddmr->buttonreg  = 0;
  ddmr->act_mem_adr= 0;
  

};

/* I/O read/write. Called on I/O or undecoded access. Should return 0 on
   success, 1 on memory error (MEXC will be generated). Data should be
   retuned in *data, number of BUSRDY waitstates should be returned in *ws.
   Size is encoded as: 0=byte, 1=half-word, 2=word, 3=doubel-word  */

static int io_read(address, data, ws) 
unsigned int address, *data, *ws; 
{ 
    *ws = 4;
#ifdef DEBUG
    printf("io: io_read at 0x%08X\n", address); 
#endif
    if ((address >= REGSTART) && (address < REGEND)) {
      /* make it relative instead of absolute */
      address -= REGSTART;
      /* alignment */
      address &= ~3;
      switch (address)	{
      case CONTROLREG :  
#ifdef DEBUG
	printf("io: Control register is accessed!\n");
#endif 
	break;
      case STARTADDR :  
#ifdef DEBUG
	printf("io: Start address register is accessed!\n");
#endif 
	*data = ddmr->startaddr;
	break;
      case STOPADDRR :  
#ifdef DEBUG
	printf("io: Stop address register is accessed!\n");
#endif 
	*data = ddmr->stopaddrr;
	break;
      case SCALERUPR :  
#ifdef DEBUG
	printf("io: SCALERUPR register is accessed!\n");
#endif 
	*data = ddmr->scalerupr;
	break;
      case DISPLCONTR :
#ifdef DEBUG
	printf("io: Display controller is accessed!\n");
#endif 
	*data = ddmr->displcontr;
	break;
      case BUTTONREG :  
#ifdef DEBUG
	printf("io: Button register is accessed!\n");
#endif
	*data = ddmr->buttonreg;
	break;
      case ACT_MEM_ADR :  
#ifdef DEBUG
	printf("io: ACT_MEM_ADR register is accessed!\n");
#endif 
	*data = ddmr->act_mem_adr;
	break;
      default:
	printf("io: This should not happen! Error!\n");
	break;
      }
      
      return(0);
    } else
      return(1);
}

static int io_write(address, data, ws, size) 
unsigned int address, *data, *ws, size; 
{ 
  /* save for local use */
  int tmpdata = 0;

  *ws = 4;

#ifdef DEBUG
  printf("io: io_write at 0x%08X\n", address);
#endif

  if ((address >= REGSTART) && (address < REGEND)) {
    address -= REGSTART;
    switch(size) {
    case 2:
      /* only word access is allowed */
      /* alignment */
      address &= ~3;
      switch (address)	{
      case CONTROLREG :  
#ifdef DEBUG
	
	printf("io: Control register is accessed!\n");
#endif
	tmpdata = *data;
	/* only the last 5 bits are used */
	tmpdata &= 0x1F;
	/* first bit, Audiocore 1=on, 0 = off */
	if ( (tmpdata & 0x1) != 0 ) {
	  printf("io: Audiocore is turned on..\n");
	} else {
	  printf("io: Audiocore is turned off..\n");
	  return(0);
	}
	/* third bit, loopmode,  1=on, 0 = off */
	if ( (tmpdata & 0x4 ) != 0) {
	  printf("io: loopmode is turned on..(not yet implemented) \n");
	} else {
	  printf("io: loopmode is off..(not yet implemented) \n");
	}
	/* fourth bit, irqen,  1=on, 0 = off */
	if ( (tmpdata & 0x8 ) != 0) {
	  printf("io: irqen is turned on..(not yet implemented) \n");
	} else {
	  printf("io: irqen is turned off..(not yet implemented) \n");
	}
	/* fifth bit, irq 1=on, 0 = off */
	if ( (tmpdata & 0x10) != 0 ) {
	  printf("io: irq is turned on..(not yet implemented)\n");
	} else {
	  printf("io: irq is turned off..(not yet implemented)\n");
	}
	/* second bit, Aufnahme 1=record, 0=play */
	if ( (tmpdata & 0x2) != 0) {
	  printf("io: Recording not yet implemented ... ");
	} else {
	  printf("io: Playback the content ...");
	  /* Play back */
	  {
	    int size, i;
	    int * dmabuf;

	    /* DMA read */
	    /* only 32-bit word transfers are allowed */
	    size = (ddmr->stopaddrr - ddmr->startaddr);
	    dmabuf = (int *) malloc(size * sizeof(int));
	    if ( dmabuf == 0 ) {
	      printf("io: malloc for dmabuf error\n");
	      return(-1);
	    }
	    printf("io: Starting DMA read of %d bytes from 0x%08X to 0x%08X ...\n", 
		   size, ddmr->startaddr, ddmr->stopaddrr);
	    /* last argument of dma_read seems to be no. of words */
	    if ( ioif.dma_read(ddmr->startaddr, dmabuf, size/4 ) != 0 ) {
		    printf("io: DMA bus error\n");
		    return(1);
	    }
	    printf("io: Data read are:\n");
	    for ( i = 0; i < size/4 && i < 20 ; i = i++ ) {
	      printf("io: 0x%08X = 0x%08X or %d\n", ddmr->startaddr + i*4, dmabuf[i], dmabuf[i]);
	    }
	    if ( size/4 > i ) {
	      printf("[more] ...\n");
	    }

	    /* Play the sound */
	    {
	      FILE* audio_out;
	      const char *audio_out_filename = AUDIO_OUT_FILENAME;
	      printf("Writing data of size %d bytes to file %s\n", size, audio_out_filename);
	      audio_out = fopen(audio_out_filename, "wb");
	      if ( fwrite(dmabuf, size, 1, audio_out) != 1 ) {
		printf("Error writing the %s\n",audio_out_filename);
		return(1);
	      }
	      close(audio_out);
	    }
	    free(dmabuf);
	  }
	}
	break;
      case STARTADDR :  
#ifdef DEBUG
	printf("io: Start address register is accessed!\n");
#endif
	ddmr->startaddr = *data;
	printf("io: startaddr set to %08X\n", ddmr->startaddr);
	break;
      case STOPADDRR :  
#ifdef DEBUG
	printf("io: Stop address register is accessed!\n");
#endif
	ddmr->stopaddrr = *data;
	printf("io: stopaddrr set to %08X\n", ddmr->stopaddrr);
	break;
      case SCALERUPR :  
#ifdef DEBUG
	printf("io: SCALERUPRl register is accessed!\n");
#endif
	ddmr->scalerupr = *data;
	printf("io: scalerups set to %08X\n", ddmr->scalerupr);
	break;
      case DISPLCONTR :
#ifdef DEBUG
	printf("io: Display controller is accessed!\n");
#endif
	ddmr->displcontr = *data;
	tmpdata = *data;
	/* Check if the 9th bit = 1 */
	tmpdata &= 0x0100;
	if ( tmpdata != 0x100 ) {
	  /* 9th bit = 0 */
	  printf("io: HEX display turns off.\n");
	} else {
	  /* Show only the last 2 bytes */
	  tmpdata = *data;
	  tmpdata &= 0x00FF;
	  printf("io: Hex displays \'%02X\'.\n",tmpdata);
	}
	break;
      case BUTTONREG : 
#ifdef DEBUG
	printf("io: Button register is accessed!\n");
#endif
	printf("io: Button register is for reading only, not for writing!\n");
	break;
      case ACT_MEM_ADR :  
#ifdef DEBUG
	printf("io: ACT_MEM_ADR register is accessed!\n");
#endif
	printf("io: ACT_MEM_ADR register is for reading only, not for writing!\n");
	break;
      default:
	printf("io: This should not happen! Error!\n");
      }
      break;
    default:
      printf("io: Error, only word access is allowed!\n");
      return(1);
    }
    return(0);
  } else
    return(1);
}


static struct io_subsystem ddmcore = {
	io_init,	/* io_init */
	io_exit,	/* io_exit */
	NULL,		/* io_reset */
	NULL,		/* io_restart */
	io_read,	/* io_read */
	io_write,	/* io_write */
	NULL,	        /* get_io_ptr */
	NULL,	        /* command */
	NULL,		/* sigio */
	NULL,	        /* save */
	NULL	        /* restore */
};

/* Attached to TSIM */

struct io_subsystem *iosystem = &ddmcore;

