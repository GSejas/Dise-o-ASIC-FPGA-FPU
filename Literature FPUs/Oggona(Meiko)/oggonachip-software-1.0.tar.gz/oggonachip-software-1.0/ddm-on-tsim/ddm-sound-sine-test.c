/* A simple program to generate sine-wave sound for testing ddm sound playing function
 *
 * @author Pattara Kiatisevi ott@linux.thai.net
 * 30.01.2002
 *
 * $Id: ddm-sound-sine-test.c,v 1.1 2002/02/01 10:22:09 pattara Exp $
 *
 */

#include <math.h>
#include <stdio.h>
#include "ddm.h"


/* BIT_PER_SAMPLE = 20 hard-coded :(  */
#define BIT_PER_SAMPLE 20

/* CHANNELS = 1 */
#define CHANNELS 1
#define TEST_LENGTH 3

#define SAMPLING_RATE 20000

volatile struct ddmregs *ddmr = (struct ddmregs *) REGSTART;
volatile int* soundbuf;
int soundbuf_size = SAMPLING_RATE * 4 * TEST_LENGTH * CHANNELS;
int max_value = 0;

int init() { 
  printf("Allocating sound buffer size = %d bytes\n", soundbuf_size);
  /* 32 bit = 4 bytes */
  soundbuf = (int *) malloc (soundbuf_size * 4);
  max_value = pow(2,32)/2 - 1; /* (2^32)/2 -1 */
  if (soundbuf == 0 ) {
    printf("malloc error\n");
    return(-1);
  }
  return(0);
}

int main() {

  printf("Sound test program. Sampling rate = %d, Bit-per-sample = %d, %d-channel\n", 
	 SAMPLING_RATE, BIT_PER_SAMPLE, CHANNELS);

  if ( init() != 0 ) {
    printf("Error initializing the program ... \n");
    return(-1);
  }

  {
    int i, flip;

    flip = 1;
    printf("Generating data of the 1000 Hz sound of length %d seconds ... \n",
	  TEST_LENGTH );
    for ( i = 0; i < soundbuf_size/(10 * 4) ; i = i++ ) { 
      if (CHANNELS == 1 ) {
	*(soundbuf + i*10) = 0 ;
	*(soundbuf + i*10+1) = (int ) (0.31 * max_value * flip) >> 0xC;
	*(soundbuf + i*10+2) = (int ) (0.59 * max_value * flip) >> 0xC;
	*(soundbuf + i*10+3) = (int ) (0.81 * max_value * flip) >> 0xC;
	*(soundbuf + i*10+4) = (int ) (0.95 * max_value * flip) >> 0xC;
	*(soundbuf + i*10+5) = (int ) (1 * max_value * flip   ) >> 0xC;
	*(soundbuf + i*10+6) = (int ) (0.95 * max_value * flip) >> 0xC;
	*(soundbuf + i*10+7) = (int ) (0.81 * max_value * flip) >> 0xC;
	*(soundbuf + i*10+8) = (int ) (0.59 * max_value * flip) >> 0xC;
	*(soundbuf + i*10+9) = (int ) (0.31 * max_value * flip) >> 0xC;
	flip = flip * (-1);
      } else {
	printf("2 CHANNELS not yet implemented .. \n");
	return(-1);
      }
    }
  }
      
  printf("Done...\n");

  /* for debug */
  /*
  {
    int i;
    int maxvalue20 = pow(2,20)/2 -1 ; 
    for ( i = 0; i < soundbuf_size/4 ; i++) {
      printf("%d:\t%d \t or 0x%08X\tor %2.0f%% \n", 
	     i,  *(soundbuf + i), *(soundbuf + i), (*(soundbuf+i))*100.0/maxvalue20 );
    }
  }
*/

  printf("Now start to play the sound ... \n");
  /* set the sampling frequency to 20,000 Hz */
  ddmr->scalerupr = 1;
  /* set the sound location to be read */
  ddmr->startaddr = (unsigned int) soundbuf;
  /* DMA transfer each time the word (4-byte) data */
  ddmr->stopaddrr = (unsigned int) (soundbuf + soundbuf_size/4) ;

  /* play it */
  ddmr->controlreg = 0x1;

  free(soundbuf);
}
