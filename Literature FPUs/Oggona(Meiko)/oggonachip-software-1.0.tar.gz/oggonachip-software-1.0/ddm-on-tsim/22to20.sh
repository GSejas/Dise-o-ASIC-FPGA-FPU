#!/bin/sh
sox -r 22000 -s -w -c 1 $1 -r 20000 -s -w -c 1 $2
