#include <stdio.h>
#include <math.h>

main () {
  double a,b,c;
  char passed = 1;

  printf("Starting the program, initializing the variable...\n");
  a = 0.5;
  b = 1.5;
  c = 3.0;

  /* Addition */
  printf("0.5 + 1.5 = %f\n", a+b );
  if ( a+b == 2.0 ) {
    printf("Addition correct\n");
  } else {
    printf("Addition WRONG\n");
    passed = 0;
  }
  
  /* Subtraction */
  printf("0.5 - 1.5 = %f\n", a-b );
  if ( a-b == -1.0 ) {
    printf("Subtraction correct\n");
  } else {
    printf("Subtraction WRONG\n");
    passed = 0;
  }
  
  /* Multiplication */
  printf("0.5 * 3.0 = %f\n", a * c );
  if ( a*c == 1.5 ) {
    printf("Multiplication correct\n");
  } else {
    printf("Multiplication WRONG\n");
    passed = 0;
  }
  
   /* Division */
  printf("3.0 / 0.5 = %f\n", c/a );
  if ( c/a == 6 ) {
    printf("Division correct\n");
  } else {
    printf("Division WRONG\n");
    passed = 0;
  }
   
    /* Round */
  printf("rint(1.5) = %d\n", (int) (rint(b)) );
  if ( (int) rint(b) == 2 ) {
    printf("Rounding correct\n");
  } else {
    printf("Rounding WRONG\n");
    passed = 0;
  };

  /* Calculate PI */
  {
    double x=0;
    int i;
    printf("Calculating value of PI, might take a long time ...\n");
    for(i=1;i<3000000;i+=4) { // for PC we could set i to 30 000 000
      x += 1.0/i - 1.0/(i+2);
    };
    printf("PI is %lf\n",x*4.0);
  }

  
  if ( passed == 1 ) {
    printf("Floating point test PASSED\n");
  } else {
    printf("Floating point test FAILED\n");
  }
   

}
