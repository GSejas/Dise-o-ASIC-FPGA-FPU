/* Test program for the MDCT function
 *
 * set #define MDCT_INTEGERIZED in mdct.h to test either
 * floating point or integer version
 *
 * ott@linux.thai.net 21.03.2002
 */

#include "misc.h"
#include "mdct.h"
#include "mdct.c"

#define ARRAYSIZE 256 /* Minimum = 64 -- limit from libvorbis */
int main() {

  /* Input is always vector of float, output can be either float or int */
  DATA_TYPE *in;
  DATA_TYPE *out;
  unsigned int i;
  static mdct_lookup lookup;

  printf("MDCT  test program started ..\n");
#ifdef MDCT_INTEGERIZED
  printf("Integer Mode..\n");
#else
  printf("Floating Point Mode..\n");
#endif

  printf("Allocate memory ...\n");
  in = (DATA_TYPE *) malloc (ARRAYSIZE * sizeof(DATA_TYPE));
  out = (DATA_TYPE *) malloc (ARRAYSIZE * sizeof(DATA_TYPE));

  
  printf("Initializing values of input array...\n");
  for (i = 0 ; i < ARRAYSIZE ; i++) {
    *(in + i) = FLOAT_TO_INT(0.5);
    //printf("%d: %f\t",i, (float) *(in + i) );
    //if ( i % 4 == 3 ) printf("\n");
  }

  printf("Initializing values of output array...\n");
  for (i = 0 ; i < ARRAYSIZE ; i++) {
    *(out +i) = 0;
  }

  printf("Calling mdct_init functions...\n");
  mdct_init(&lookup, ARRAYSIZE);
  printf("Calling mdct_backward functions...\n");
  mdct_backward(&lookup, (DATA_TYPE*) in, out);


  printf("Output values:\n");
  for (i = 0 ; i < ARRAYSIZE ; i++) {
#ifdef MDCT_INTEGERIZED
    printf("%d:\t%d\t",i , *( (int*) out + i) ); 
#else
    int tmp;
    tmp = (int) ( *(out+i) * 32768.f);
    printf("%d: %f,%d\t",i , *(out+i), tmp);
#endif
    if ( i % 3 == 2 ) printf("\n");
  }
  printf("\n");

  return(0);
}
