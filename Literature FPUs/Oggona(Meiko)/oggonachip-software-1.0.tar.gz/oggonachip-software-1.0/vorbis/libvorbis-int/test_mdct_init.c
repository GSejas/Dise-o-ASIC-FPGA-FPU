#include "misc.h"
#include "mdct.h"

mdct_lookup m;

int main () {
  int n,i;

  n=2048; 
  mdct_init(&m, n);

  printf("n = %d\n\n",n);
  printf("bitrev:\n");
  for (i = 0 ; i < n/4 ; i++ ) {
    printf("%d: \"%d\"\n",i, *(m.bitrev+i));
  }
  printf("T:\n");
  for (i = 0 ; i < n+n/4 ; i++ ) {
	  if ( abs(*(m.trig+i)) >= 16384 ) {
	    printf("***** value exceeds the boundary of 16-bit...\n");
	  }
#ifdef VORBIS_INTEGERIZED
    printf("%d: \"%d\"\n",i, *(m.trig+i));
#else
    printf("%d: \"%f\"\n",i, *(m.trig+i));
#endif
  }
  return 0;
}
