#include <stdio.h>
#include "mdct.h"
#include "mdct.c"
#include "misc.h"

#define ARRAYSIZE 64

int printoutput(int array[], int n) {
  int i;
  printf("Values:\n");
  for (i = 0 ; i < n ; i++) {
#ifdef VORBIS_INTEGERIZED
    printf("array[%d]:\t%5d\t",i, array[i]);
#else
    printf("array[%d]:\t%f\t",i, array[i]*1.f);
#endif
    if( i % 4 == 3 ) printf("\n");
  }
  printf("\n");
  return(0);
};

void setinput(int array[], int n, float defaultx) {
  int i;
  printf("Setting %d input elements, defaultx = %f...(if -1 means 0.01*i)\n", n, defaultx);
  for (i = 0; i < n ; i++) {
    // if defaultx is set to -1 then we set the input to vary with i
    if ( defaultx == -1 ) { 
      array[i] = FLOAT_TO_INT(0.01*i);
    } else {
      array[i] = FLOAT_TO_INT(defaultx);
    }
  };
}

int main () {
  int n = ARRAYSIZE;
  DATA_TYPE array[ARRAYSIZE], array2[ARRAYSIZE];
  int n2 = n>>1;
  mdct_lookup m;
 
  printf("call mdct_init(%d)..\n",n);
  mdct_init(&m,n);

  /* one array for output and input */


  setinput(array, 8, -1);
  printoutput(array, 8);
  printf("call mdct_butterfly_8(array)...\n");
  mdct_butterfly_8(array);
  printoutput(array,8);

  setinput(array, 16, -1);
  printoutput(array, 16);
  printf("call mdct_butterfly_16(array)...\n");
  mdct_butterfly_16(array);
  printoutput(array,16);

  setinput(array, 32, -1);
  printoutput(array, 32);
  printf("call mdct_butterfly_32(array)...\n");
  mdct_butterfly_32(array);
  printoutput(array,32);

  setinput(array, n, -1);
  printoutput(array, n);
  printf("call mdct_butterflies(array + %d, %d)...\n", n2, n2);
  mdct_butterflies(&m, array + n2, n2);
  printoutput(array,n);

  setinput(array, n, 0.5);
  printoutput(array, n);
  printf("call mdct_bitreverse(array)...\n");
  mdct_bitreverse(&m, array);
  printoutput(array,n);

  /* separate arrays for input and output */
  setinput(array, n, -1);
  setinput(array2, n, 0);
  printoutput(array, n);
  printf("call mdct_butterfly_first(array, array2, %d )...\n", ARRAYSIZE);
  mdct_butterfly_first(array, array2, ARRAYSIZE);
  printoutput(array2,n);

  setinput(array, n, -1);
  setinput(array2, n, 0);
  printoutput(array, n);
  printf("call mdct_butterfly_generic(array, array2, %d, %d )...\n", ARRAYSIZE,2);
  mdct_butterfly_generic(array, array2, ARRAYSIZE,2);
  printoutput(array2,n);

  setinput(array, n, 0.5);
  setinput(array2, n, 0);
  printoutput(array, n);
  printf("call mdct_backward(array, array2)...\n");
  mdct_backward(&m, array, array2);
  printoutput(array2,n);

  return(0);

}
    
