/* A simple program to test the Audio MDCT Core module
 *
 * @author Pattara Kiatisevi ott@linux.thai.net
 * 13.03.2002
 *
 * $Id: test_mdct_nohardware.c,v 1.1 2002/06/10 15:31:27 pattara Exp $
 *
 */

#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include "misc.h"
#include "mdct.h"

/* array size either 256 or 2048 only */
#define ARRAYSIZE 2048

/* forward declaration */
void mdct_init(mdct_lookup* lookup, int n);
void mdct_backward(mdct_lookup* lookup, DATA_TYPE* in, DATA_TYPE* out);

int main() {
  DATA_TYPE *in;
  DATA_TYPE *out;
  unsigned int i;
  mdct_lookup lookup;

  /*
  printf("MDCT est program started ..\n");
  printf("TRIGBITS = %d\n", TRIGBITS);
  
  printf("Allocate memory ...\n");
  */
  in = malloc (ARRAYSIZE * sizeof(DATA_TYPE));
  out = malloc (ARRAYSIZE * sizeof(DATA_TYPE));

  //printf("Calling mdct_init(%d)..\n", ARRAYSIZE);
  mdct_init(&lookup, ARRAYSIZE);

  printf("Initializing values of input array...\n");
  for (i = 0 ; i < ARRAYSIZE ; i++) {
    *(in + i) = 1 << (FRACBITS - 1 );
    //printf("%d: %d\t",i, *(in + i) );
    //if ( i % 5 == 4 ) printf("\n");
  }

  {
    int i;
    for ( i = 0 ; i < 1000 ; i++ ){
      mdct_backward(&lookup, in, out);
    }
  }
  /*
  for (i = 0 ; i < ARRAYSIZE ; i++) {
    printf("%d: %d\t",i , *( (int*) out + i) ); 
    if ( i % 5 == 4 ) printf("\n");
  }
  */
  printf("Done..\n");
  return(0);
}
