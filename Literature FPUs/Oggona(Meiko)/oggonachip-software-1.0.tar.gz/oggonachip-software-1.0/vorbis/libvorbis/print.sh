a2ps -A fill -o out.ps  \
*.h analysis.c bitrate.c block.c codebook.c envelope.c floor0.c floor1.c info.c \
lookup.c lpc.c lsp.c mapping0.c mdct.c psy.c registry.c res0.c sharedbook.c \
smallft.c synthesis.c time0.c window.c vorbisfile.c --line-numbers=10 --toc
