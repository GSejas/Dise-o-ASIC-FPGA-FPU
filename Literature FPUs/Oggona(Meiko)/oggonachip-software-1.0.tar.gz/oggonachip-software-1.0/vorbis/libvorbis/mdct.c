/*
 * MDCT interface to work with hardware MDCT core
 * developed for Ogg on a Chip project
 *
 * Support for both floating point and integer version
 * set it at mdct.h
 *
 * $Id: mdct.c,v 1.7 2002/03/26 18:17:17 pattara Exp $
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "vorbis/codec.h"
#include "mdct.h"
#include "os.h"
#include "../../mdct_core/mdct_core.h"

#ifdef DEBUG_LIBVORBIS
#define DEBUG(x, y...) { fprintf (stderr, x, ## y); }
#else
#define DEBUG(x, y...)
#endif

/* build lookups for trig functions; also pre-figure scaling and
   some window function algebra. */

volatile struct mdct_core_regs *regs;

void mdct_init(mdct_lookup *lookup,int n){


  DEBUG("mdct_init is called, n = %d\n",n);

  /* Set up pointer to hardware if not yet */
  if ( regs == NULL) { 
    regs = (struct mdct_core_regs *) MDCT_CORE_START;
  }
 
  lookup->n=n;

  /* The rest is done in hardware */

  //DEBUG("mdct_init finished\n");
}

void mdct_clear(mdct_lookup *l){
  if(l){
    if(l->trig)_ogg_free(l->trig);
    if(l->bitrev)_ogg_free(l->bitrev);
    memset(l,0,sizeof(*l));
  }
}



void mdct_backward(mdct_lookup *init, DATA_TYPE *in, DATA_TYPE *out){
  unsigned int n=init->n;

  DEBUG("mdct_backward is called, n = %d\n", n);

  /* Set the n value, if it is not the same as last one  */
  if (n != regs->arraysize ) {
    DEBUG("set the value of n to hardware...\n");
    regs->arraysize=n;
    /* Wait for the hardware init process */
    while(regs->status != 1);
  } else {
    DEBUG("same array size as last time, no need to set it again\n");
  }

  /* Write the start read and write addresses */
  DEBUG("Write the startreadaddr register to 0x%08X..\n",(unsigned int in));
  regs->startreadaddr=(unsigned int) in;
  DEBUG("Write the startwriteaddr register to 0x%08X..\n",(unsigned int out));
  regs->startwriteaddr=(unsigned int) out;

  /* Go transform! */
  DEBUG("Write to controlreg to start the transform...\n");
  regs->controlreg = 0x1;

  /* Wait until finish */
  while(regs->status != 1);

#ifdef MDCT_INTEGERIZED
  /* This should not actually be done as we need anyway the int output */
  /*
  DEBUG("MDCT Integer version, converting output vector back to float ...\n");
  {
    int i;
    for (i = 0 ; i < n ; i++) {
      *( (float*) out + i) = (float) ( *( (int *) out + i) / 32768.f);

      //if ( i < 10 ) {
      //printf("Output %d: %f\n", i, *( (float*) out+ i));
      //}
    }
  }
  */
#endif

  DEBUG("mdct_backward finished\n");
}

void mdct_forward(mdct_lookup *init, DATA_TYPE *in, DATA_TYPE *out){
  printf("Not implemented...\n");
}
