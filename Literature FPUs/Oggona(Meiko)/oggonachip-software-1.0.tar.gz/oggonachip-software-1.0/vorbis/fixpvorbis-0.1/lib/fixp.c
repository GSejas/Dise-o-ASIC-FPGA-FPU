inline int mul(int s,int a,int b) {
  volatile int* regs = (int*) 0x80000400;
  printf("s,a,b = %d, %d, %d\n",s,a,b);
  *(regs) = s;
  *(regs+1) = a;
  *(regs+2) = b;
  return *(regs+4);
}
