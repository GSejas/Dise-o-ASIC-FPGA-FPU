/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE Ogg Vorbis SOFTWARE CODEC SOURCE CODE.  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS DISTRIBUTING.                            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-2000             *
 * by Monty <monty@xiph.org> and The XIPHOPHORUS Company            *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 function: channel mapping 0 implementation
 last mod: $Id: mapping0.c,v 1.2 2002/03/27 14:31:22 pattara Exp $

 ********************************************************************/

#include <stdlib.h>
#include <string.h>
#include <math.h>
//#include "vorbis/codec.h"
//#include "vorbis/backends.h"
#include "codec.h"
#include "backends.h"
#include "bitwise.h"
#include "bookinternal.h"
#include "registry.h"
#include "misc.h"
#include "checkalloc.h"

#include "autoprofile.h"

/* simplistic, wasteful way of doing this (unique lookup for each
   mode/submapping); there should be a central repository for
   identical lookups.  That will require minor work, so I'm putting it
   off as low priority.

   Why a lookup for each backend in a given mode?  Because the
   blocksize is set by the mode, and low backend lookups may require
   parameters from other areas of the mode/mapping */

typedef struct {
  vorbis_info_mode *mode;
  vorbis_info_mapping0 *map;

  vorbis_look_time **time_look;
  vorbis_look_floor **floor_look;

  vorbis_look_residue **residue_look;

  vorbis_func_time **time_func;
  vorbis_func_floor **floor_func;
  vorbis_func_residue **residue_func;

  int ch;
  float **decay;
  long lastframe; /* if a different mode is called, we need to 
		     invalidate decay */
} vorbis_look_mapping0;

static void mapping0_free_info(vorbis_info_mapping *i){
  if(i){
    memset(i,0,sizeof(vorbis_info_mapping0));
    free(i);
  }
}

static void mapping0_free_look(vorbis_look_mapping *look){
  int i;
  vorbis_look_mapping0 *l=(vorbis_look_mapping0 *)look;
  if(l){
    for(i=0;i<l->map->submaps;i++){
      l->time_func[i]->free_look(l->time_look[i]);
      l->floor_func[i]->free_look(l->floor_look[i]);
      l->residue_func[i]->free_look(l->residue_look[i]);
    }

    if(l->decay){
      for(i=0;i<l->ch;i++){
	if(l->decay[i])free(l->decay[i]);
      }
      free(l->decay);
    }

    free(l->time_func);
    free(l->floor_func);
    free(l->residue_func);
    free(l->time_look);
    free(l->floor_look);
    free(l->residue_look);
    memset(l,0,sizeof(vorbis_look_mapping0));
    free(l);
  }
}

static vorbis_look_mapping *mapping0_look(vorbis_dsp_state *vd,vorbis_info_mode *vm,
			  vorbis_info_mapping *m){
#ifdef PROFILE
FunctionProfiler fp("mapping0_look");
#endif	// PROFILE
  int i;
  vorbis_info *vi=vd->vi;
  vorbis_look_mapping0 *look=(vorbis_look_mapping0*)calloc(1,sizeof(vorbis_look_mapping0));
  vorbis_info_mapping0 *info=look->map=(vorbis_info_mapping0 *)m;
  CHECK_ALLOC(look);
  CHECK_ALLOC(info);
  look->mode=vm;
  
  look->time_look=(void**)calloc(info->submaps,sizeof(vorbis_look_time *));
  CHECK_ALLOC(look->time_look);
  look->floor_look=(void**)calloc(info->submaps,sizeof(vorbis_look_floor *));
  CHECK_ALLOC(look->floor_look);

  look->residue_look=(void**)calloc(info->submaps,sizeof(vorbis_look_residue *));
  CHECK_ALLOC(look->residue_look);

  look->time_func=(vorbis_func_time **)calloc(info->submaps,sizeof(vorbis_func_time *));
  CHECK_ALLOC(look->time_func);
  look->floor_func=(vorbis_func_floor **)calloc(info->submaps,sizeof(vorbis_func_floor *));
  CHECK_ALLOC(look->floor_func);
  look->residue_func=(vorbis_func_residue **)calloc(info->submaps,sizeof(vorbis_func_residue *));
  CHECK_ALLOC(look->residue_func);
  
  for(i=0;i<info->submaps;i++){
    int timenum=info->timesubmap[i];
    int floornum=info->floorsubmap[i];
    int resnum=info->residuesubmap[i];

    look->time_func[i]=_time_P[vi->time_type[timenum]];
    look->time_look[i]=look->time_func[i]->
      look(vd,vm,vi->time_param[timenum]);
    look->floor_func[i]=_floor_P[vi->floor_type[floornum]];
    look->floor_look[i]=look->floor_func[i]->
      look(vd,vm,vi->floor_param[floornum]);
    look->residue_func[i]=_residue_P[vi->residue_type[resnum]];
    look->residue_look[i]=look->residue_func[i]->
      look(vd,vm,vi->residue_param[resnum]);
    
  }

  look->ch=vi->channels;

  return(look);
}

/* also responsible for range checking */
static vorbis_info_mapping *mapping0_unpack(vorbis_info *vi,oggpack_buffer *opb){
#ifdef PROFILE
FunctionProfiler fp("mapping0_unpack");
#endif	// PROFILE
  int i;
  vorbis_info_mapping0 *info=(vorbis_info_mapping0*)calloc(1,sizeof(vorbis_info_mapping0));
  CHECK_ALLOC(info);
  memset(info,0,sizeof(vorbis_info_mapping0));

  info->submaps=_oggpack_read(opb,4)+1;

  if(info->submaps>1){
    for(i=0;i<vi->channels;i++){
      info->chmuxlist[i]=_oggpack_read(opb,4);
      if(info->chmuxlist[i]>=info->submaps)goto err_out;
    }
  }
  for(i=0;i<info->submaps;i++){
    info->timesubmap[i]=_oggpack_read(opb,8);
    if(info->timesubmap[i]>=vi->times)goto err_out;
    info->floorsubmap[i]=_oggpack_read(opb,8);
    if(info->floorsubmap[i]>=vi->floors)goto err_out;
    info->residuesubmap[i]=_oggpack_read(opb,8);
    if(info->residuesubmap[i]>=vi->residues)goto err_out;
  }

  return info;

 err_out:
  mapping0_free_info(info);
  return(NULL);
}

#include "os.h"
#include "lsp.h"
#include "mdct.h"
#include "bitwise.h"
#include "scales.h"

static int mapping0_inverse(vorbis_block *vb,vorbis_look_mapping *l){
#ifdef PROFILE
FunctionProfiler fp("mapping0_inverse");
#endif	// PROFILE
  vorbis_dsp_state     *vd=vb->vd;
  vorbis_info          *vi=vd->vi;
  vorbis_look_mapping0 *look=(vorbis_look_mapping0 *)l;
  vorbis_info_mapping0 *info=look->map;
  vorbis_info_mode     *mode=look->mode;
  int                   i,j;
  long                  n=vb->pcmend=vi->blocksizes[vb->W];

  Real *window=vd->window[vb->W][vb->lW][vb->nW][mode->windowtype];
#define USE_ALLOCA
#ifdef USE_ALLOCA
  Real **pcmbundle=(Real**)alloca(sizeof(Real *)*vi->channels);
  int *nonzero=(int*)alloca(sizeof(int)*vi->channels);
#else
  Real **pcmbundle=(Real**)malloc(sizeof(Real *)*vi->channels);
  int *nonzero=(int*)malloc(sizeof(int)*vi->channels);
#endif
  CHECK_ALLOC(pcmbundle);
  CHECK_ALLOC(nonzero);
  
  /* time domain information decode (note that applying the
     information would have to happen later; we'll probably add a
     function entry to the harness for that later */
  /* NOT IMPLEMENTED */

  /* recover the spectral envelope; store it in the PCM vector for now */
  for(i=0;i<vi->channels;i++){
    Real *pcm=vb->pcm[i];
    int submap=info->chmuxlist[i];
    nonzero[i]=look->floor_func[submap]->
      inverse(vb,look->floor_look[submap],pcm);
  }

  /* recover the residue, apply directly to the spectral envelope */

  for(i=0;i<info->submaps;i++){
    int ch_in_bundle=0;
    for(j=0;j<vi->channels;j++){
      if(info->chmuxlist[j]==i && nonzero[j])
	pcmbundle[ch_in_bundle++]=vb->pcm[j];
    }

    look->residue_func[i]->inverse(vb,look->residue_look[i],pcmbundle,ch_in_bundle);
  }

  /* transform the PCM data; takes PCM vector, vb; modifies PCM vector */
  /* only MDCT right now.... */
  for(i=0;i<vi->channels;i++){
    Real *pcm=vb->pcm[i];
    mdct_backward((mdct_lookup*)vd->transform[vb->W][0],pcm,pcm);
  }

  /* now apply the decoded pre-window time information */
  /* NOT IMPLEMENTED */
  
  /* window the data */
  for(i=0;i<vi->channels;i++){
    Real *pcm=vb->pcm[i];
    Real *pcmend=vb->pcm[i]+n;

    if(nonzero[i]){

#ifdef USE_ASSEMBLY
      asm volatile("stmdb  SP!,{r4-r11};"
		   "mov    r1,%2;"
		   "5:"
		   "ldmia  %0,{r4-r7};"
		   "ldmia  r1!,{r8-r11};"
		   "mul    r4,r8,r4;"
		   "mul    r5,r9,r5;"
		   "mul    r6,r10,r6;"
		   "mul    r7,r11,r7;"
		   "mov    r4,r4,asr #15;"
		   "mov    r5,r5,asr #15;"
		   "mov    r6,r6,asr #15;"
		   "mov    r7,r7,asr #15;"
		   "stmia  %0!,{r4-r7};"
		   "cmp    %1,%0;"
		   "bhi    5b;"
		   "ldmia  SP!,{r4-r11};"
		   :"+r"(pcm)
		   :"r"(pcmend),"r"(window)
		   :"r1"
		   );
#else
      for(j=0;j<n;j++) {
	pcm[j]*=window[j];
	MULTEQ_REAL(pcm[j], window[j]);
	pcm[j] = (pcm[j] * window[j]) >> FRACBITS;
      }
#endif

    }else{
#ifdef USE_ASSEMBLY
      asm volatile("stmdb  SP!,{r4-r11};"
		   "mov    r4,#0;"
		   "mov    r5,#0;"
		   "mov    r6,#0;"
		   "mov    r7,#0;"
		   "mov    r8,#0;"
		   "mov    r9,#0;"
		   "mov    r10,#0;"
		   "mov    r11,#0;"
		   "0:"
		   "stmia  %0!,{r4-r11};"
		   "cmp    %1,%0;"
		   "bhi    0b;"
		   "ldmia  SP!,{r4-r11};"
		   :"+r"(pcm)
		   :"r"(pcmend)
		   );
#else
      for(j=0;j<n;j++) pcm[j]=REAL_ZERO;
#endif
    }
  }

  /* now apply the decoded post-window time information */
  /* NOT IMPLEMENTED */

#ifndef USE_ALLOCA
  free(pcmbundle);
  free(nonzero);
#endif
  /* all done! */
  return(0);
};

/* export hooks */
vorbis_func_mapping mapping0_exportbundle={
  NULL,&mapping0_unpack,&mapping0_look,&mapping0_free_info,
  &mapping0_free_look,NULL,&mapping0_inverse

};
