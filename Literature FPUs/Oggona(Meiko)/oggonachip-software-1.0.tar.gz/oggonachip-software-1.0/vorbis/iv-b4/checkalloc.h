#ifndef CHECKALLOC_H_
#define CHECKALLOC_H_

//#include "debug.h"

//#define USE_ALLOCA

//#define CHECK_ALLOC(a) if(!(a)) diag_printf("Alloc error: " __FILE__ " %d\n", __LINE__)
#define CHECK_ALLOC(a)


#endif	// CHECKALLOC_H_
