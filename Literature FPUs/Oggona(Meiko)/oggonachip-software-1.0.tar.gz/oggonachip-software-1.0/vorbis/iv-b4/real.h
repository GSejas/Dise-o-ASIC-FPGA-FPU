#ifndef _REAL_H
#define _REAL_H

//#define REAL_IS_FLOAT
#define REAL_IS_INT


#ifdef REAL_IS_FLOAT

#define Real float

#define INT_TO_REAL(a) ((float)(a))
#define REAL_TO_INT(a) (a)
#define FLOAT_TO_REAL(a) (a)
#define REAL_TO_FLOAT(a) (a)
#define REAL_ZERO	0

#define REAL_ABS(a) fabs(a)
#define MULT_REAL(a, b) ((a) * (b))
#define MULTEQ_REAL(a, b) a *= b
#define DIVIDE_REAL_BY_REAL(a,b) ((a) / (b))
#define DIVIDE_REAL_BY_INT(a,b) ((a) / ((float)(b)))

#define MULT_REAL(a, b) ((a) * (b))
#define MULTEQ_REAL(a, b) a *= b

#define SMALLREAL

#define SmallReal	float
#define INT_TO_SMALL_REAL(a) ((float)(a))
#define SMALL_REAL_TO_INT(a) (a)
#define FLOAT_TO_SMALL_REAL(a) (a)
#define SMALL_REAL_TO_FLOAT(a) (a)
#define SMALL_REAL_ZERO	0
#define REAL_TO_SMALL_REAL(a) (a)

#define SMALL_REAL_ABS(a) fabs(a)
#define DIVIDE_SMALL_REAL_BY_SMALL_REAL(a,b) ((a) / (b))
#define DIVIDE_SMALL_REAL_BY_INT(a,b) ((a) / ((float)(b)))
#define DIVIDE_SMALL_REAL_BY_SMALL_REAL_TO_REAL(a,b) ((a) / (b))
#define MULT_REAL_BY_SMALL_REAL_TO_REAL(a, b) ((a) * (b))
#define MULT_SMALL_REAL_BY_REAL_TO_SMALL_REAL(a, b) ((a) * (b))
#define MULT_SMALL_REAL_BY_INT(a, b) ((a) * (b))
#define MULT_SMALL_REAL(a, b) ((a) * (b))
#define MULTEQ_SMALL_REAL(a, b) a *= b




#elif defined(REAL_IS_INT)



typedef long LONGLONG;


#define Real	int


#define FRACBITS 15
#define FRACF ((float)(1<<FRACBITS))


#define INT_TO_REAL(a) ((a) << FRACBITS)
#define REAL_TO_INT(a) ((a) >> FRACBITS)

#define FLOAT_TO_REAL(a) ((int)((a) * FRACF))
#define REAL_TO_FLOAT(a) ((a) / FRACF)
#define REAL_ZERO	0

#define REAL_ABS(a) fabs(a)
#define DIVIDE_REAL_BY_REAL(a,b) (((a) / (b)) << FRACBITS)
#define DIVIDE_REAL_BY_INT(a,b) ((a) / (b))
#define MULT_REAL_BY_INT(a,b) ((a) * (b))

#define MULT_REAL(a, b) mult_real(a, b)
#define MULTEQ_REAL(a, b) multeq_real(&a, b)


#define SMALLREAL

#define SmallReal       int

#define SMALL_FRACBITS 22
#define SMALL_FRACF ((float)(1<<SMALL_FRACBITS))

#define INT_TO_SMALL_REAL(a) ((a) << SMALL_FRACBITS)
#define SMALL_REAL_TO_INT(a) ((a) >> SMALL_FRACBITS)
#define FLOAT_TO_SMALL_REAL(a) ((int)((a) * SMALL_FRACF))
#define SMALL_REAL_TO_FLOAT(a) ((a) / SMALL_FRACF)

#define SMALL_REAL_ZERO 0
#define REAL_TO_SMALL_REAL(a) ((a) << (SMALL_FRACBITS - FRACBITS))

#define SMALL_REAL_ABS(a) fabs(a)
#define DIVIDE_SMALL_REAL_BY_SMALL_REAL_TO_REAL(a,b) (((a) / (b)) << FRACBITS)
#define MULT_SMALL_REAL_BY_INT(a, b) ((a) * (b))


#define MULT_SMALL_REAL(a, b) mult_small_real(a, b)
#define MULTEQ_SMALL_REAL(a, b) multeq_small_real(&a, b)
#define MULT_REAL_BY_SMALL_REAL_TO_REAL(a, b) mult_real_by_small_real(a, b)

inline Real mult_real(Real o1, Real o2);
inline Real multeq_real(Real *o1,Real o2);
inline SmallReal mult_small_real(SmallReal o1, SmallReal o2);
inline SmallReal multeq_small_real(SmallReal *o1, SmallReal o2);
inline Real mult_real_by_small_real(Real o1, SmallReal o2);

#endif 

#endif	//  _REAL_H

