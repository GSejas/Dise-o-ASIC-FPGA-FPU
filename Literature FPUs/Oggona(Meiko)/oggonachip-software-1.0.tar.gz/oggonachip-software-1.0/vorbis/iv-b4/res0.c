/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE Ogg Vorbis SOFTWARE CODEC SOURCE CODE.  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS DISTRIBUTING.                            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-2000             *
 * by Monty <monty@xiph.org> and The XIPHOPHORUS Company            *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 function: residue backend 0 implementation
 last mod: $Id: res0.c,v 1.2 2002/03/27 14:31:22 pattara Exp $

 ********************************************************************/

/* Slow, slow, slow, simpleminded and did I mention it was slow?  The
   encode/decode loops are coded for clarity and performance is not
   yet even a nagging little idea lurking in the shadows.  Oh and BTW,
   it's slow. */

#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
//#include "vorbis/codec.h"
#include "codec.h"
#include "bitwise.h"
#include "registry.h"
#include "bookinternal.h"
#include "sharedbook.h"
#include "misc.h"
#include "os.h"

#include "autoprofile.h"
#include "checkalloc.h"

typedef struct {
  vorbis_info_residue0 *info;
  int         map;
  
  int         parts;
  codebook   *phrasebook;
  codebook ***partbooks;

  int         partvals;
  int       **decodemap;
} vorbis_look_residue0;

void res0_free_info(vorbis_info_residue *i){
  if(i){
    memset(i,0,sizeof(vorbis_info_residue0));
    free(i);
  }
}

void res0_free_look(vorbis_look_residue *i){
  int j;
  if(i){
    vorbis_look_residue0 *look=(vorbis_look_residue0 *)i;
    for(j=0;j<look->parts;j++)
      if(look->partbooks[j])free(look->partbooks[j]);
    free(look->partbooks);
    for(j=0;j<look->partvals;j++)
      free(look->decodemap[j]);
    free(look->decodemap);
    memset(i,0,sizeof(vorbis_look_residue0));
    free(i);
  }
}

/* vorbis_info is for range checking */
vorbis_info_residue *res0_unpack(vorbis_info *vi,oggpack_buffer *opb){
  int j,acc=0;
  vorbis_info_residue0 *info=(vorbis_info_residue0*)calloc(1,sizeof(vorbis_info_residue0));

  info->begin=_oggpack_read(opb,24);
  info->end=_oggpack_read(opb,24);
  info->grouping=_oggpack_read(opb,24)+1;
  info->partitions=_oggpack_read(opb,6)+1;
  info->groupbook=_oggpack_read(opb,8);
  for(j=0;j<info->partitions;j++){
    int cascade=info->secondstages[j]=_oggpack_read(opb,4);
    if(cascade>1)goto errout; /* temporary!  when cascading gets
                                 reworked and actually used, we don't
                                 want old code to DTWT */
    acc+=cascade;
  }
  for(j=0;j<acc;j++)
    info->booklist[j]=_oggpack_read(opb,8);

  if(info->groupbook>=vi->books)goto errout;
  for(j=0;j<acc;j++)
    if(info->booklist[j]>=vi->books)goto errout;

  return(info);
 errout:
  res0_free_info(info);
  return(NULL);
}

vorbis_look_residue *res0_look (vorbis_dsp_state *vd,vorbis_info_mode *vm,
			  vorbis_info_residue *vr){
  vorbis_info_residue0 *info=(vorbis_info_residue0 *)vr;
  vorbis_look_residue0 *look=(vorbis_look_residue0*)calloc(1,sizeof(vorbis_look_residue0));
  int j,k,acc=0;
  int dim;
  look->info=info;
  look->map=vm->mapping;

  look->parts=info->partitions;
  look->phrasebook=vd->fullbooks+info->groupbook;
  dim=look->phrasebook->dim;

  look->partbooks=(codebook***)calloc(look->parts,sizeof(codebook **));

  for(j=0;j<look->parts;j++){
    int stages=info->secondstages[j];
    if(stages){
      look->partbooks[j]=(codebook**)malloc(stages*sizeof(codebook *));
      for(k=0;k<stages;k++)
	look->partbooks[j][k]=vd->fullbooks+info->booklist[acc++];
    }
  }

  look->partvals=rint(pow(look->parts,dim));
  look->decodemap=(int**)malloc(look->partvals*sizeof(int *));
  for(j=0;j<look->partvals;j++){
    long val=j;
    long mult=look->partvals/look->parts;
    look->decodemap[j]=(int*)malloc(dim*sizeof(int));
    for(k=0;k<dim;k++){
      long deco=val/mult;
      val-=deco*mult;
      mult/=look->parts;
      look->decodemap[j][k]=deco;
    }
  }

  return(look);
}

// doesn't do cascading yet
static int _decodepart(oggpack_buffer *opb,SmallReal *work,Real *vec, int n,
		       int stages, codebook **books){
  int i;
  if(stages){
	  int dim=books[0]->dim;
	  int step=n/dim;
	  if(s_vorbis_book_decodevs(books[0],work,opb,step)==-1)
		  return(-1);

	  for(i=0;i<n;i++)
		  vec[i] = MULT_SMALL_REAL(vec[i],work[i]) >> (SMALL_FRACBITS - FRACBITS);
	  //    vec[i] = (vec[i] * (work[i] >> (SMALL_FRACBITS - FRACBITS))) >> FRACBITS;
	  
  }else{
	  for(i=0;i<n;i++)
		  vec[i] = 0;
  }
  
  return(0);
}

/* a truncated packet here just means 'stop working'; it's not an error */
int res0_inverse(vorbis_block *vb,vorbis_look_residue *vl,Real **in,int ch){
#ifdef PROFILE
FunctionProfiler fp("res0_inverse");
#endif	// PROFILE
  long i,j,k,l,transend=vb->pcmend/2;
  vorbis_look_residue0 *look=(vorbis_look_residue0 *)vl;
  vorbis_info_residue0 *info=look->info;

  /* move all this setup out later */
  int samples_per_partition=info->grouping;
  int partitions_per_word=look->phrasebook->dim;
  int n=info->end-info->begin;

  int partvals=n/samples_per_partition;
  int partwords=(partvals+partitions_per_word-1)/partitions_per_word;
#define USE_ALLOCA
#ifdef USE_ALLOCA
  int **partword=(int**)alloca(ch*sizeof(long *));
//  Real *work=alloca(sizeof(Real)*samples_per_partition);
  SmallReal *work=(SmallReal*)alloca(sizeof(SmallReal)*samples_per_partition);
#else
  int **partword=(int**)malloc(ch*sizeof(long *));
//  Real *work=malloc(sizeof(Real)*samples_per_partition);
  SmallReal *work=(SmallReal*)malloc(sizeof(SmallReal)*samples_per_partition);
#endif
  CHECK_ALLOC(partword);
  CHECK_ALLOC(work);
  partvals=partwords*partitions_per_word;

  /* make sure we're zeroed up to the start */
  for(j=0;j<ch;j++)
    memset(in[j],0,sizeof(Real)*info->begin);

  for(i=info->begin,l=0;i<info->end;){
    /* fetch the partition word for each channel */
    for(j=0;j<ch;j++){
      int temp=vorbis_book_decode(look->phrasebook,&vb->opb);
      if(temp==-1)goto eopbreak;
      partword[j]=look->decodemap[temp];
      if(partword[j]==NULL)goto errout;
    }
    
    /* now we decode interleaved residual values for the partitions */
    for(k=0;k<partitions_per_word;k++,l++,i+=samples_per_partition)
      for(j=0;j<ch;j++){
	int part=partword[j][k];
	if(_decodepart(&vb->opb,work,in[j]+i,samples_per_partition,
		    info->secondstages[part],
		       look->partbooks[part])==-1)goto eopbreak;
      }
  }

 eopbreak:
  if(i<transend){
    for(j=0;j<ch;j++)
      memset(in[j]+i,0,sizeof(Real)*(transend-i));
  }

#ifndef USE_ALLOCA
  free(partword);
  free(work);
#endif
  return(0);

 errout:
//diag_printf("erroring out of res0_inverse\n");
  printf("erroring out of res0_inverse\n");
  for(j=0;j<ch;j++)
    memset(in[j],0,sizeof(Real)*transend);
#ifndef USE_ALLOCA
  free(partword);
  free(work);
#endif
  return(0);
}

vorbis_func_residue residue0_exportbundle={
  NULL,
  &res0_unpack,
  &res0_look,
  &res0_free_info,
  &res0_free_look,
  NULL,
  &res0_inverse
};
