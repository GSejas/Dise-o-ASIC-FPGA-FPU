/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE Ogg Vorbis SOFTWARE CODEC SOURCE CODE.  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS DISTRIBUTING.                            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-2000             *
 * by Monty <monty@xiph.org> and The XIPHOPHORUS Company            *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

  function: lookup based functions
  last mod: $Id: lookup.c,v 1.1 2002/03/18 13:55:39 pattara Exp $

 ********************************************************************/

#include <math.h>
#include "lookup.h"
#include "lookup_data.h"

#ifdef _V_INCLUDED
/* interpolated 1./sqrt(p) where .5 <= a < 1. (.100000... to .111111...) in
   16.16 format 

   returns in m.8 format */

static long ADJUST_SQRT2[2]={8192,5792};
static inline long vorbis_invsqlook_i(long a,long e){
  long i=(a&0x7fff)>>(INVSQ_LOOKUP_I_SHIFT-1); 
  long d=a&INVSQ_LOOKUP_I_MASK;                              /*  0.10 */
  long val=INVSQ_LOOKUP_I[i]-                                /*  1.16 */
    ((INVSQ_LOOKUP_IDel[i]*d)>>INVSQ_LOOKUP_I_SHIFT);        /* result 1.16 */
  val*=ADJUST_SQRT2[e&1];
  e=(e>>1)+21;
  return(val>>e);
}

/* interpolated lookup based fromdB function, domain -140dB to 0dB only */
/* a is in n.12 format */
static inline Real vorbis_fromdBlook_i(long a){
  int i=(-a)>>(12-FROMdB2_SHIFT);
  return (i<0)?INT_TO_REAL(1):
    ((i>=(FROMdB_LOOKUP_SZ<<FROMdB_SHIFT))?REAL_ZERO:
     MULT_SMALL_REAL(FROMdB_LOOKUP[i>>FROMdB_SHIFT],
		     FROMdB2_LOOKUP[i&FROMdB2_MASK]));
}

/* interpolated lookup based cos function, domain 0 to PI only */
/* a is in 0.16 format, where 0==0, 2^^16==PI, return 0.14 */
static inline long vorbis_coslook_i(long a){
  int i=a>>COS_LOOKUP_I_SHIFT;
  int d=a&COS_LOOKUP_I_MASK;
  return COS_LOOKUP_I[i]- ((d*(COS_LOOKUP_I[i]-COS_LOOKUP_I[i+1]))>>
			   COS_LOOKUP_I_SHIFT);
}

#else

/* interpolated lookup based cos function */
/* a is in 0.16 format, where 0==0, 2^^16==PI, return REAL */
Real vorbis_coslook2_i(long a){
	a=a&0x1ffff;

	if(a>0x10000)a=0x20000-a;
	{		
		int i=a>>COS_LOOKUP_I_SHIFT;
		int d=a&COS_LOOKUP_I_MASK;
		a=((COS_LOOKUP_I[i]<<COS_LOOKUP_I_SHIFT)-
			d*(COS_LOOKUP_I[i]-COS_LOOKUP_I[i+1]))>>
					 (COS_LOOKUP_I_SHIFT-FRACBITS+14);
	}
	
	return(a);
}

/* interpolated lookup based sin function */
/* a is in 0.16 format, where 0==0, 2^^16==PI, return REAL */
Real vorbis_sinlook2_i(long a){
	return(vorbis_coslook2_i(a+0x18000));
}
#endif

