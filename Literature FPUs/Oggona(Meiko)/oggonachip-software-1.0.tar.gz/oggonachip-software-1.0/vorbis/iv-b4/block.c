/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE Ogg Vorbis SOFTWARE CODEC SOURCE CODE.  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS DISTRIBUTING.                            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-2000             *
 * by Monty <monty@xiph.org> and The XIPHOPHORUS Company            *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 function: PCM data vector blocking, windowing and dis/reassembly
 last mod: $Id: block.c,v 1.1 2002/03/18 13:55:37 pattara Exp $

 Handle windowing, overlap-add, etc of the PCM vectors.  This is made
 more amusing by Vorbis' current two allowed block sizes.
 
 Vorbis manipulates the dynamic range of the incoming PCM data
 envelope to minimise time-domain energy leakage from percussive and
 plosive waveforms being quantized in the MDCT domain.

 ********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include "vorbis/codec.h"
//#include "vorbis/real.h"
#include "codec.h"
#include "real.h"

#include "window.h"
#include "mdct.h"
#include "bitwise.h"
#include "registry.h"
#include "sharedbook.h"
#include "bookinternal.h"
#include "misc.h"
#include "checkalloc.h"
#include "autoprofile.h"

static int ilog2(unsigned int v){
  int ret=0;
  while(v>1){
    ret++;
    v>>=1;
  }
  return(ret);
}

/* pcm accumulator examples (not exhaustive):

 <-------------- lW ---------------->
                   <--------------- W ---------------->
:            .....|.....       _______________         |
:        .'''     |     '''_---      |       |\        |
:.....'''         |_____--- '''......|       | \_______|
:.................|__________________|_______|__|______|
                  |<------ Sl ------>|      > Sr <     |endW
                  |beginSl           |endSl  |  |endSr   
                  |beginW            |endlW  |beginSr


                      |< lW >|       
                   <--------------- W ---------------->
                  |   |  ..  ______________            |
                  |   | '  `/        |     ---_        |
                  |___.'___/`.       |         ---_____| 
                  |_______|__|_______|_________________|
                  |      >|Sl|<      |<------ Sr ----->|endW
                  |       |  |endSl  |beginSr          |endSr
                  |beginW |  |endlW                     
                  mult[0] |beginSl                     mult[n]

 <-------------- lW ----------------->
                          |<--W-->|                               
:            ..............  ___  |   |                    
:        .'''             |`/   \ |   |                       
:.....'''                 |/`....\|...|                    
:.........................|___|___|___|                  
                          |Sl |Sr |endW    
                          |   |   |endSr
                          |   |beginSr
                          |   |endSl
			  |beginSl
			  |beginW
*/

/* block abstraction setup *********************************************/

#ifndef WORD_ALIGN
#define WORD_ALIGN 8
#endif

int vorbis_block_init(vorbis_dsp_state *v, vorbis_block *vb){
  memset(vb,0,sizeof(vorbis_block));
  vb->vd=v;
  vb->localalloc=0;
  vb->localstore=NULL;

  return(0);
}

void *_vorbis_block_alloc(vorbis_block *vb,long bytes){
  bytes=(bytes+(WORD_ALIGN-1)) & ~(WORD_ALIGN-1);
  if(bytes+vb->localtop>vb->localalloc){
    /* can't just realloc... there are outstanding pointers */
    if(vb->localstore){
      struct alloc_chain *link=(struct alloc_chain*)malloc(sizeof(struct alloc_chain));
	  CHECK_ALLOC(link);
      vb->totaluse+=vb->localtop;
      link->next=vb->reap;
      link->ptr=vb->localstore;
      vb->reap=link;
    }
    /* highly conservative */
    vb->localalloc=bytes;
    vb->localstore=malloc(vb->localalloc);
	CHECK_ALLOC(vb->localstore);
    vb->localtop=0;
  }
  {
    void *ret=(void *)(((char *)vb->localstore)+vb->localtop);
    vb->localtop+=bytes;
    return ret;
  }
}

/* reap the chain, pull the ripcord */
void _vorbis_block_ripcord(vorbis_block *vb){
  /* reap the chain */
  struct alloc_chain *reap=vb->reap;
  while(reap){
    struct alloc_chain *next=reap->next;
    free(reap->ptr);
    memset(reap,0,sizeof(struct alloc_chain));
    free(reap);
    reap=next;
  }
  /* consolidate storage */
  if(vb->totaluse){
    vb->localstore=realloc(vb->localstore,vb->totaluse+vb->localalloc);
	CHECK_ALLOC(vb->localstore);
    vb->localalloc+=vb->totaluse;
    vb->totaluse=0;
  }

  /* pull the ripcord */
  vb->localtop=0;
  vb->reap=NULL;
}

int vorbis_block_clear(vorbis_block *vb){
  if(vb->vd)
  _vorbis_block_ripcord(vb);
  if(vb->localstore)free(vb->localstore);

  memset(vb,0,sizeof(vorbis_block));
  return(0);
}

static int _vds_shared_init(vorbis_dsp_state *v,vorbis_info *vi,int encp){
  int i;
  memset(v,0,sizeof(vorbis_dsp_state));

  v->vi=vi;
  v->modebits=ilog2(vi->modes);

  v->transform[0]=(void**)calloc(VI_TRANSFORMB,sizeof(vorbis_look_transform *));
  CHECK_ALLOC(v->transform[0]);
  v->transform[1]=(void**)calloc(VI_TRANSFORMB,sizeof(vorbis_look_transform *));
  CHECK_ALLOC(v->transform[1]);

  /* MDCT is tranform 0 */

  v->transform[0][0]=calloc(1,sizeof(mdct_lookup));
  CHECK_ALLOC(v->transform[0][0]);
  v->transform[1][0]=calloc(1,sizeof(mdct_lookup));
  CHECK_ALLOC(v->transform[0][1]);
  mdct_init((mdct_lookup*)v->transform[0][0],vi->blocksizes[0]);
  mdct_init((mdct_lookup*)v->transform[1][0],vi->blocksizes[1]);

  v->window[0][0][0]=(Real**)calloc(VI_WINDOWB,sizeof(Real *));
  CHECK_ALLOC(v->window[0][0][0]);
  v->window[0][0][1]=v->window[0][0][0];
  v->window[0][1][0]=v->window[0][0][0];
  v->window[0][1][1]=v->window[0][0][0];
  v->window[1][0][0]=(Real**)calloc(VI_WINDOWB,sizeof(Real *));
  CHECK_ALLOC(v->window[1][0][0]);
  v->window[1][0][1]=(Real**)calloc(VI_WINDOWB,sizeof(Real *));
  CHECK_ALLOC(v->window[1][0][1]);
  v->window[1][1][0]=(Real**)calloc(VI_WINDOWB,sizeof(Real *));
  CHECK_ALLOC(v->window[1][1][0]);
  v->window[1][1][1]=(Real**)calloc(VI_WINDOWB,sizeof(Real *));
  CHECK_ALLOC(v->window[1][1][1]);

  for(i=0;i<VI_WINDOWB;i++){
    v->window[0][0][0][i]=
      _vorbis_window(i,vi->blocksizes[0],vi->blocksizes[0]/2,vi->blocksizes[0]/2);
    v->window[1][0][0][i]=
      _vorbis_window(i,vi->blocksizes[1],vi->blocksizes[0]/2,vi->blocksizes[0]/2);
    v->window[1][0][1][i]=
      _vorbis_window(i,vi->blocksizes[1],vi->blocksizes[0]/2,vi->blocksizes[1]/2);
    v->window[1][1][0][i]=
      _vorbis_window(i,vi->blocksizes[1],vi->blocksizes[1]/2,vi->blocksizes[0]/2);
    v->window[1][1][1][i]=
      _vorbis_window(i,vi->blocksizes[1],vi->blocksizes[1]/2,vi->blocksizes[1]/2);
  }

  /* finish the codebooks */
  v->fullbooks=(codebook*)calloc(vi->books,sizeof(codebook));
  CHECK_ALLOC(v->fullbooks);
  for(i=0;i<vi->books;i++)
    vorbis_book_init_decode(v->fullbooks+i,vi->book_param[i]);

  /* initialize the storage vectors to a decent size greater than the
     minimum */
  
  v->pcm_storage=8192; /* we'll assume later that we have
			  a minimum of twice the blocksize of
			  accumulated samples in analysis */
  v->pcm=(Real**)malloc(vi->channels*sizeof(Real *));
  CHECK_ALLOC(v->pcm);
  v->pcmret=(Real**)malloc(vi->channels*sizeof(Real *));
  CHECK_ALLOC(v->pcmret);
  {
    int i;
    for(i=0;i<vi->channels;i++)
	{
      v->pcm[i]=(Real*)calloc(v->pcm_storage,sizeof(Real));
	  CHECK_ALLOC(v->pcm[i]);
	}
  }

  /* all 1 (large block) or 0 (small block) */
  /* explicitly set for the sake of clarity */
  v->lW=0; /* previous window size */
  v->W=0;  /* current window size */

  /* all vector indexes */
  v->centerW=vi->blocksizes[1]/2;

  v->pcm_current=v->centerW;

  /* initialize all the mapping/backend lookups */
  v->mode=(void**)calloc(vi->modes,sizeof(vorbis_look_mapping *));
  CHECK_ALLOC(v->mode);
  for(i=0;i<vi->modes;i++){
    int mapnum=vi->mode_param[i]->mapping;
    int maptype=vi->map_type[mapnum];
    v->mode[i]=_mapping_P[maptype]->look(v,vi->mode_param[i],
					 vi->map_param[mapnum]);
  }

  return(0);
}

void vorbis_dsp_clear(vorbis_dsp_state *v){
#ifdef PROFILE
FunctionProfiler fp("vorbis_dsp_clear");
#endif	// PROFILE
  int i,j,k;
  if(v){
    vorbis_info *vi=v->vi;

    if(v->window[0][0][0]){
      for(i=0;i<VI_WINDOWB;i++)
	if(v->window[0][0][0][i])free(v->window[0][0][0][i]);
      free(v->window[0][0][0]);

      for(j=0;j<2;j++)
	for(k=0;k<2;k++){
	  for(i=0;i<VI_WINDOWB;i++)
	    if(v->window[1][j][k][i])free(v->window[1][j][k][i]);
	  free(v->window[1][j][k]);
	}
    }
    
    if(v->pcm){
      for(i=0;i<vi->channels;i++)
	if(v->pcm[i])free(v->pcm[i]);
      free(v->pcm);
      if(v->pcmret)free(v->pcmret);
    }

    if(v->transform[0]){
      mdct_clear((mdct_lookup*)v->transform[0][0]);
      free(v->transform[0][0]);
      free(v->transform[0]);
    }
    if(v->transform[1]){
      mdct_clear((mdct_lookup*)v->transform[1][0]);
      free(v->transform[1][0]);
      free(v->transform[1]);
    }

    /* free mode lookups; these are actually vorbis_look_mapping structs */
    if(vi){
      for(i=0;i<vi->modes;i++){
	int mapnum=vi->mode_param[i]->mapping;
	int maptype=vi->map_type[mapnum];
	_mapping_P[maptype]->free_look(v->mode[i]);
      }
      /* free codebooks */
      for(i=0;i<vi->books;i++)
	vorbis_book_clear(v->fullbooks+i);
    }

    if(v->mode)free(v->mode);    
    if(v->fullbooks)free(v->fullbooks);

    memset(v,0,sizeof(vorbis_dsp_state));
  }
}

int vorbis_synthesis_init(vorbis_dsp_state *v,vorbis_info *vi){
#ifdef PROFILE
FunctionProfiler fp("vorbis_synthesis_init");
#endif	// PROFILE
  _vds_shared_init(v,vi,0);

  /* Adjust centerW to allow an easier mechanism for determining output */
  v->pcm_returned=v->centerW;
  v->centerW-= vi->blocksizes[v->W]/4+vi->blocksizes[v->lW]/4;
  v->frameno=-1;
  v->sequence=-1;

  return(0);
}

/* Unike in analysis, the window is only partially applied for each
   block.  The time domain envelope is not yet handled at the point of
   calling (as it relies on the previous block). */

int vorbis_synthesis_blockin(vorbis_dsp_state *v,vorbis_block *vb){
#ifdef PROFILE
FunctionProfiler fp("vorbis_synthesis_blockin");
#endif	// PROFILE
  vorbis_info *vi=v->vi;

  /* Shift out any PCM that we returned previously */
  /* centerW is currently the center of the last block added */
  if(v->pcm_returned > 8192  && v->centerW>vi->blocksizes[1]/2){
#ifdef PROFILE
    FunctionProfiler fp("vorbis_synthesis_blockin shiftdata");
#endif	// PROFILE

    /* don't shift too much; we need to have a minimum PCM buffer of
       1/2 long block */

    int shiftPCM=v->centerW-vi->blocksizes[1]/2;
    shiftPCM=(v->pcm_returned<shiftPCM?v->pcm_returned:shiftPCM)& 0xfffffff0;
    
    v->pcm_current-=shiftPCM;
    v->centerW-=shiftPCM;
    v->pcm_returned-=shiftPCM;
    
    if(shiftPCM){
      int i;
      for(i=0;i<vi->channels;i++){
	Real *to=v->pcm[i];
	Real *from=v->pcm[i]+shiftPCM;
	Real *end=v->pcm[i]+v->pcm_current;

#ifdef USE_ASSEMBLY
	asm volatile(
	    "stmdb  SP!,{r4-r11};"
	    "2:"
	    "ldmia  %1!,{r4-r11};"
	    "stmia  %0!,{r4-r11};"
	    "ldmia  %1!,{r4-r11};"
	    "stmia  %0!,{r4-r11};"
	    "cmp    %2,%0;"
	    "bhi    2b;"
	    "ldmia  SP!,{r4-r11};"
	    :"+r"(to),"+r"(from)
	    :"r"(end)
	    );
#else
	memmove(v->pcm[i],v->pcm[i]+shiftPCM, v->pcm_current*sizeof(Real));
#endif
      }
    }
  }

  v->lW=v->W;
  v->W=vb->W;
  v->nW=-1;

  v->glue_bits+=vb->glue_bits;
  v->time_bits+=vb->time_bits;
  v->floor_bits+=vb->floor_bits;
  v->res_bits+=vb->res_bits;

  if(v->sequence+1 != vb->sequence)v->frameno=-1; /* out of sequence;
                                                     lose count */

  v->sequence=vb->sequence;

  {
    int sizeW=vi->blocksizes[v->W];
    int centerW=v->centerW+vi->blocksizes[v->lW]/4+sizeW/4;
    int beginW=centerW-sizeW/2;
    int endW=beginW+sizeW;
    int beginSl;
    int endSl;
    int i,j;

    /* Do we have enough PCM/mult storage for the block? */
    if(endW>v->pcm_storage){
#ifdef PROFILE
FunctionProfiler fp("vorbis_synthesis_blockin realloc");
#endif	// PROFILE

      /* expand the storage */
      v->pcm_storage=endW+vi->blocksizes[1];
   
      for(i=0;i<vi->channels;i++)
	  {
		v->pcm[i]=(Real*)realloc(v->pcm[i],v->pcm_storage*sizeof(Real)); 
		CHECK_ALLOC(v->pcm[i]);
	  }
    }

    /* overlap/add PCM */

    switch(v->W){
    case 0:
      beginSl=0;
      endSl=vi->blocksizes[0]/2;
      break;
    case 1:
      beginSl=vi->blocksizes[1]/4-vi->blocksizes[v->lW]/4;
      endSl=beginSl+vi->blocksizes[v->lW]/2;
      break;
    }

    {
#ifdef PROFILE
      FunctionProfiler fp("vorbis_synthesis_blockin lapping");
#endif	// PROFILE

    for(j=0;j<vi->channels;j++){
      Real *pcmbase=v->pcm[j]+beginW+beginSl;
      Real *pbase=vb->pcm[j]+beginSl;
      Real *pcmendadd=v->pcm[j]+beginW+endSl;
      Real *pcmendcopy=v->pcm[j]+beginW+sizeW;
      
#ifdef USE_ASSEMBLY
      asm volatile(
	  "stmdb  SP!,{r4-r11};"
	  "3:"
	  "ldmia  %0,{r4-r7};"
	  "ldmia  %1!,{r8-r11};"
	  "add    r4,r4,r8;"
	  "add    r5,r5,r9;"
	  "add    r6,r6,r10;"
	  "add    r7,r7,r11;"
	  "stmia  %0!,{r4-r7};"

	  "ldmia  %1!,{r8-r11};"
	  "ldmia  %0,{r4-r7};"
	  "add    r4,r4,r8;"
	  "add    r5,r5,r9;"
	  "add    r6,r6,r10;"
	  "add    r7,r7,r11;"
	  "stmia  %0!,{r4-r7};"

	  "cmp    %2,%0;"
	  "bhi    3b;"

	  "4:"
	  "ldmia  %1!,{r4-r11};"
	  "stmia  %0!,{r4-r11};"
	  "ldmia  %1!,{r4-r11};"
	  "stmia  %0!,{r4-r11};"
	  "cmp    %3,%0;"
	  "bhi    4b;"
	  "ldmia  SP!,{r4-r11};"
	  :"+r"(pcmbase),"+r"(pbase)
	  :"r"(pcmendadd),"r"(pcmendcopy)
	  );
#else
      /* the overlap/add section */
      for(i=beginSl;i<endSl;i++)
	pcmbase[i]+=pbase[i];
      /* the remaining section */
      for(;i<sizeW;i++)
	pcmbase[i]=pbase[i];
#endif
    }
    }

    /* track the frame number... This is for convenience, but also
       making sure our last packet doesn't end with added padding.  If
       the last packet is partial, the number of samples we'll have to
       return will be past the vb->frameno.
       
       This is not foolproof!  It will be confused if we begin
       decoding at the last page after a seek or hole.  In that case,
       we don't have a starting point to judge where the last frame
       is.  For this reason, vorbisfile will always try to make sure
       it reads the last two marked pages in proper sequence */

    if(v->frameno==-1)
      v->frameno=vb->frameno;
    else{
      v->frameno+=(centerW-v->centerW);
      if(vb->frameno!=-1 && v->frameno!=vb->frameno){
	if(v->frameno>vb->frameno && vb->eofflag){
	  /* partial last frame.  Strip the padding off */
	  centerW-=(v->frameno-vb->frameno);
	}/* else{ Shouldn't happen *unless* the bitstream is out of
            spec.  Either way, believe the bitstream } */
	v->frameno=vb->frameno;
      }
    }

    /* Update, cleanup */

    v->centerW=centerW;
    v->pcm_current=endW;

    if(vb->eofflag)v->eofflag=1;
  }

  return(0);
}

/* pcm==NULL indicates we just want the pending samples, no more */
int vorbis_synthesis_pcmout(vorbis_dsp_state *v,Real ***pcm){
#ifdef PROFILE
FunctionProfiler fp("vorbis_synthesis_pcmout");
#endif	// PROFILE
  vorbis_info *vi=v->vi;
  if(v->pcm_returned<v->centerW){
    if(pcm){
      int i;
      for(i=0;i<vi->channels;i++)
	v->pcmret[i]=v->pcm[i]+v->pcm_returned;
      *pcm=v->pcmret;
    }
    return(v->centerW-v->pcm_returned);
  }
  return(0);
}

int vorbis_synthesis_read(vorbis_dsp_state *v,int bytes){
  if(bytes && v->pcm_returned+bytes>v->centerW)return(-1);
  v->pcm_returned+=bytes;
  return(0);
}

