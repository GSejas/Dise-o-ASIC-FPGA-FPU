/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE Ogg Vorbis SOFTWARE CODEC SOURCE CODE.  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS DISTRIBUTING.                            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-2000             *
 * by Monty <monty@xiph.org> and The XIPHOPHORUS Company            *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 function: basic shared codebook operations
 last mod: $Id: sharedbook.c,v 1.1 2002/03/18 13:55:40 pattara Exp $

 ********************************************************************/

#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "os.h"
//#include "vorbis/codec.h"
//#include "vorbis/codebook.h"
#include "codec.h"
#include "codebook.h"
#include "bitwise.h"
#include "scales.h"
#include "sharedbook.h"

#include "autoprofile.h"

/**** pack/unpack helpers ******************************************/
int _ilog(unsigned int v){
  int ret=0;
  while(v){
    ret++;
    v>>=1;
  }
  return(ret);
}

/* 32 bit Real (not IEEE; nonnormalized mantissa +
   biased exponent) : neeeeeee eeemmmmm mmmmmmmm mmmmmmmm 
   Why not IEEE?  It's just not that important here. */

#define VQ_FEXP 10
#define VQ_FMAN 21
#define VQ_FEXP_BIAS 768 /* bias toward values smaller than 1. */

/*
Real _float32_unpack(long val){
  Real mant=val&0x1fffff;
  Real sign=val&0x80000000;
  Real exp =(val&0x7fe00000)>>VQ_FMAN;
  if(sign)mant= -mant;
  return(ldexp(mant,exp-(VQ_FMAN-1)-VQ_FEXP_BIAS));
}
*/
float _float32_unpack(long val){
#ifdef PROFILE
FunctionProfiler fp("_float32_unpack");
#endif	// PROFILE
  float mant=val&0x1fffff;
  float sign=val&0x80000000;
  float exp =(val&0x7fe00000)>>VQ_FMAN;
  if(sign)mant= -mant;
  return(ldexp(mant,exp-(VQ_FMAN-1)-VQ_FEXP_BIAS));
}

/* given a list of word lengths, generate a list of codewords.  Works
   for length ordered or unordered, always assigns the lowest valued
   codewords first.  Extended to handle unused entries (length 0) */
long *_make_words(long *l,long n){
  long i,j;
  long marker[33];
  long *r=(long*)malloc(n*sizeof(long));
  memset(marker,0,sizeof(marker));

  for(i=0;i<n;i++){
    long length=l[i];
    if(length>0){
      long entry=marker[length];
      
      /* when we claim a node for an entry, we also claim the nodes
	 below it (pruning off the imagined tree that may have dangled
	 from it) as well as blocking the use of any nodes directly
	 above for leaves */
      
      /* update ourself */
      if(length<32 && (entry>>length)){
	/* error condition; the lengths must specify an overpopulated tree */
	free(r);
	return(NULL);
      }
      r[i]=entry;
    
      /* Look to see if the next shorter marker points to the node
	 above. if so, update it and repeat.  */
      {
	for(j=length;j>0;j--){
	  
	  if(marker[j]&1){
	    /* have to jump branches */
	    if(j==1)
	      marker[1]++;
	    else
	      marker[j]=marker[j-1]<<1;
	    break; /* invariant says next upper marker would already
		      have been moved if it was on the same path */
	  }
	  marker[j]++;
	}
      }
      
      /* prune the tree; the implicit invariant says all the longer
	 markers were dangling from our just-taken node.  Dangle them
	 from our *new* node. */
      for(j=length+1;j<33;j++)
	if((marker[j]>>1) == entry){
	  entry=marker[j];
	  marker[j]=marker[j-1]<<1;
	}else
	  break;
    }    
  }
    
  /* bitreverse the words because our bitwise packer/unpacker is LSb
     endian */
  for(i=0;i<n;i++){
    long temp=0;
    for(j=0;j<l[i];j++){
      temp<<=1;
      temp|=(r[i]>>j)&1;
    }
    r[i]=temp;
  }

  return(r);
}

/* build the decode helper tree from the codewords */
decode_aux *_make_decode_tree(codebook *c){
  const static_codebook *s=c->c;
  long top=0,i,j,n;
  decode_aux *t=(decode_aux *)malloc(sizeof(decode_aux));
  long *ptr0=t->ptr0=(long*)calloc(c->entries*2,sizeof(long));
  long *ptr1=t->ptr1=(long*)calloc(c->entries*2,sizeof(long));
  long *codelist=_make_words(s->lengthlist,s->entries);

  if(codelist==NULL)return(NULL);
  t->aux=c->entries*2;

  for(i=0;i<c->entries;i++){
    if(s->lengthlist[i]>0){
      long ptr=0;
      for(j=0;j<s->lengthlist[i]-1;j++){
	int bit=(codelist[i]>>j)&1;
	if(!bit){
	  if(!ptr0[ptr])
	    ptr0[ptr]= ++top;
	  ptr=ptr0[ptr];
	}else{
	  if(!ptr1[ptr])
	    ptr1[ptr]= ++top;
	  ptr=ptr1[ptr];
	}
      }
      if(!((codelist[i]>>j)&1))
	ptr0[ptr]=-i;
      else
	ptr1[ptr]=-i;
    }
  }
  free(codelist);

  t->tabn = _ilog(c->entries)-4; /* this is magic */
  if(t->tabn<5)t->tabn=5;
  n = 1<<t->tabn;
  t->tab = (long*)malloc(n*sizeof(long));
  t->tabl = (int*)malloc(n*sizeof(int));
  for (i = 0; i < n; i++) {
    long p = 0;
    for (j = 0; j < t->tabn && (p > 0 || j == 0); j++) {
      if (i & (1 << j))
	p = ptr1[p];
      else
	p = ptr0[p];
    }
    /* now j == length, and p == -code */
    t->tab[i] = p;
    t->tabl[i] = j;
  }

  return(t);
}

/* there might be a straightforward one-line way to do the below
   that's portable and totally safe against roundoff, but I haven't
   thought of it.  Therefore, we opt on the side of caution */
long _book_maptype1_quantvals(const static_codebook *b){
  long vals=floor(pow(b->entries,1./b->dim));

  /* the above *should* be reliable, but we'll not assume that FP is
     ever reliable when bitstream sync is at stake; verify via integer
     means that vals really is the greatest value of dim for which
     vals^b->bim <= b->entries */
  /* treat the above as an initial guess */
  while(1){
    long acc=1;
    long acc1=1;
    int i;
    for(i=0;i<b->dim;i++){
      acc*=vals;
      acc1*=vals+1;
    }
    if(acc<=b->entries && acc1>b->entries){
      return(vals);
    }else{
      if(acc>b->entries){
	vals--;
      }else{
	vals++;
      }
    }
  }
}

/* unpack the quantized list of values for encode/decode ***********/
/* we need to deal with two map types: in map type 1, the values are
   generated algorithmically (each column of the vector counts through
   the values in the quant vector). in map type 2, all the values came
   in in an explicit list.  Both value lists must be unpacked */
SmallReal *_book_unquantize(const static_codebook *b){
  long j,k;
  if(b->maptype==1 || b->maptype==2){
    int quantvals;
	SmallReal mindel=FLOAT_TO_SMALL_REAL(_float32_unpack(b->q_min));
	SmallReal delta=FLOAT_TO_SMALL_REAL(_float32_unpack(b->q_delta));
	SmallReal *r=(SmallReal*)calloc(b->entries*b->dim,sizeof(SmallReal));

		/* maptype 1 and 2 both use a quantized value vector, but
		   different sizes */
		switch(b->maptype)
		{
		case 1:
		  /* most of the time, entries%dimensions == 0, but we need to be
		 well defined.  We define that the possible vales at each
		 scalar is values == entries/dim.  If entries%dim != 0, we'll
		 have 'too few' values (values*dim<entries), which means that
		 we'll have 'left over' entries; left over entries use zeroed
		 values (and are wasted).  So don't generate codebooks like
		 that */
			quantvals=_book_maptype1_quantvals(b);
			for(j=0;j<b->entries;j++)
			{
				SmallReal last = SMALL_REAL_ZERO;
				int indexdiv=1;
				for(k=0;k<b->dim;k++)
				{
					int index= (j/indexdiv)%quantvals;
					SmallReal val=INT_TO_SMALL_REAL(b->quantlist[index]);
					val = MULT_SMALL_REAL(SMALL_REAL_ABS(val), delta) + mindel + last;
					if(b->q_sequencep)last=val;	  
					r[j*b->dim+k]=val;
					indexdiv*=quantvals;
				}
			}
			break;

		case 2:
			for(j=0;j<b->entries;j++)
			{
				SmallReal last = SMALL_REAL_ZERO;
				for(k=0;k<b->dim;k++)
				{
					SmallReal val=INT_TO_SMALL_REAL(b->quantlist[j*b->dim+k]);
					val = MULT_SMALL_REAL(SMALL_REAL_ABS(val), delta) + mindel + last;
					if(b->q_sequencep)last=val;	  
						r[j*b->dim+k]=val;
				}
			}
		}
		return(r);
	}
	return(NULL);
}

void vorbis_staticbook_clear(static_codebook *b){
  if(b->quantlist)free(b->quantlist);
  if(b->lengthlist)free(b->lengthlist);
  memset(b,0,sizeof(static_codebook));
}

void vorbis_book_clear(codebook *b){
  /* static book is not cleared; we're likely called on the lookup and
     the static codebook belongs to the info struct */
  if(b->decode_tree){
    free(b->decode_tree->ptr0);
    free(b->decode_tree->ptr1);
    memset(b->decode_tree,0,sizeof(decode_aux));
    free(b->decode_tree);
  }
  if(b->valuelist)free(b->valuelist);
  if(b->codelist)free(b->codelist);
  memset(b,0,sizeof(codebook));
}

int vorbis_book_init_decode(codebook *c,const static_codebook *s){
  memset(c,0,sizeof(codebook));
  c->c=s;
  c->entries=s->entries;
  c->dim=s->dim;
  c->valuelist=_book_unquantize(s);
  c->decode_tree=_make_decode_tree(c);
  if(c->decode_tree==NULL)goto err_out;
  return(0);
 err_out:
  vorbis_book_clear(c);
  return(-1);
}

