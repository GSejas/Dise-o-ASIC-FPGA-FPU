/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE Ogg Vorbis SOFTWARE CODEC SOURCE CODE.  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS DISTRIBUTING.                            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-2000             *
 * by Monty <monty@xiph.org> and The XIPHOPHORUS Company            *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 function: floor backend 0 implementation
 last mod: $Id: floor0.c,v 1.2 2002/03/27 14:31:22 pattara Exp $

 ********************************************************************/

#include <stdlib.h>
#include <string.h>
#include <math.h>
//#include "vorbis/codec.h"
#include "codec.h"
#include "bitwise.h"
#include "registry.h"
#include "lsp.h"
#include "bookinternal.h"
#include "sharedbook.h"
#include "scales.h"
#include "misc.h"
#include "os.h"
#include "lookup.h"
#include "checkalloc.h"

#include "misc.h"
#include <stdio.h>

#include "autoprofile.h"

typedef struct {
  long n;
  int ln;
  int  m;
  int *linearmap;

  vorbis_info_floor0 *vi;
  long *lsp_look;

} vorbis_look_floor0;

/***********************************************/

static void floor0_free_info(vorbis_info_floor *i){
  if(i){
    memset(i,0,sizeof(vorbis_info_floor0));
    free(i);
  }
}

static void floor0_free_look(vorbis_look_floor *i){
  vorbis_look_floor0 *look=(vorbis_look_floor0 *)i;
  if(i){
    if(look->linearmap)free(look->linearmap);
    if(look->lsp_look)free(look->lsp_look);
    memset(look,0,sizeof(vorbis_look_floor0));
    free(look);
  }
}

static vorbis_info_floor *floor0_unpack (vorbis_info *vi,oggpack_buffer *opb){
#ifdef PROFILE
FunctionProfiler fp("floor0_unpack");
#endif	// PROFILE
  int j;
  vorbis_info_floor0 *info=(vorbis_info_floor0*)malloc(sizeof(vorbis_info_floor0));
  CHECK_ALLOC(info);
  info->order=_oggpack_read(opb,8);
  info->rate=_oggpack_read(opb,16);
  info->barkmap=_oggpack_read(opb,16);
  info->ampbits=_oggpack_read(opb,6);
  info->ampdB=_oggpack_read(opb,8);
  info->numbooks=_oggpack_read(opb,4)+1;
  
  if(info->order<1)goto err_out;
  if(info->rate<1)goto err_out;
  if(info->barkmap<1)goto err_out;
  if(info->numbooks<1)goto err_out;

  for(j=0;j<info->numbooks;j++){
    info->books[j]=_oggpack_read(opb,8);
    if(info->books[j]<0 || info->books[j]>=vi->books)goto err_out;
  }
  return(info);  
 err_out:
  floor0_free_info(info);
  return(NULL);
}

/* initialize Bark scale and normalization lookups.  We could do this
   with static tables, but Vorbis allows a number of possible
   combinations, so it's best to do it computationally.

   The below is authoritative in terms of defining scale mapping.
   Note that the scale depends on the sampling rate as well as the
   linear block and mapping sizes */

static vorbis_look_floor *floor0_look (vorbis_dsp_state *vd,vorbis_info_mode *mi,
                              vorbis_info_floor *i){
#ifdef PROFILE
FunctionProfiler fp("floor0_look");
#endif	// PROFILE
  int j;
  Real scale;
  vorbis_info        *vi=vd->vi;
  vorbis_info_floor0 *info=(vorbis_info_floor0 *)i;
  vorbis_look_floor0 *look=(vorbis_look_floor0*)calloc(1,sizeof(vorbis_look_floor0));
  CHECK_ALLOC(look);
  look->m=info->order;
  look->n=vi->blocksizes[mi->blockflag]/2;
  look->ln=info->barkmap;
  look->vi=info;

  /* we choose a scaling constant so that:
     floor(bark(rate/2-1)*C)=mapped-1
     floor(bark(rate/2)*C)=mapped */
  scale=FLOAT_TO_REAL(look->ln/toBARK(info->rate/2.));

  /* the mapping from a linear scale to a smaller bark scale is
     straightforward.  We do *not* make sure that the linear mapping
     does not skip bark-scale bins; the decoder simply skips them and
     the encoder may do what it wishes in filling them.  They're
     necessary in some mapping combinations to keep the scale spacing
     accurate */
  look->linearmap=(int*)malloc((look->n+1)*sizeof(int));
  CHECK_ALLOC(look->linearmap);
  for(j=0;j<look->n;j++){
    int val=floor((int)(toBARK((info->rate/2.)/look->n*j)*scale)>>FRACBITS); /* bark numbers represent band edges */
    if(val>=look->ln)val=look->ln; /* guard against the approximation */
    look->linearmap[j]=val;
  }
  look->linearmap[j] = -1;

  look->lsp_look=(long*)malloc(look->ln*sizeof(long));
  CHECK_ALLOC(look->lsp_look);
  for(j=0;j<look->ln;j++)
	  look->lsp_look[j]=(long)((vorbis_coslook2_i(0x10000*j/look->ln))>>(FRACBITS-14));
//    look->lsp_look[j]=MULT_REAL_BY_INT(FLOAT_TO_REAL(cos(M_PI/look->ln*j)), 2);

  return look;
}

/* generate the whole freq response curve of an LPC IIR filter */

static int floor0_inverse(vorbis_block *vb,vorbis_look_floor *i,Real *out){
#ifdef PROFILE
FunctionProfiler fp("floor0_inverse");
#endif	// PROFILE
	vorbis_look_floor0 *look=(vorbis_look_floor0 *)i;
	vorbis_info_floor0 *info=look->vi;
	int j,k;

	int ampraw=_oggpack_read(&vb->opb,info->ampbits);
	if(ampraw>0){ /* also handles the -1 out of data case */
		long maxval=(1<<info->ampbits)-1;
#ifdef REAL_IS_INT
//		Real amp = (ampraw << FRACBITS) / maxval * info->ampdB;
		int amp = ((ampraw * info->ampdB) << 4) / maxval;
#else
		Real amp=FLOAT_TO_REAL((float)ampraw/maxval*info->ampdB);
#endif
		int booknum=_oggpack_read(&vb->opb,_ilog(info->numbooks));
		SmallReal *lsp=(SmallReal*)alloca(sizeof(SmallReal)*look->m);
		CHECK_ALLOC(lsp);

		if(booknum!=-1)
		{
			codebook *b=vb->vd->fullbooks+info->books[booknum];
			SmallReal last = SMALL_REAL_ZERO;

			for(j=0;j<look->m;j+=b->dim)
				if(vorbis_book_decodevs(b,lsp+j,&vb->opb,1,-1)==-1)
					goto eop;
			for(j=0;j<look->m;){
				for(k=0;k<b->dim;k++,j++)
					lsp[j]+=last;
				last=lsp[j-1];
			}

			/* take the coefficients back to a spectral envelope curve */
			//			_analysis_output("lsp",seq++,lsp,n,0,0);
			vorbis_lsp_to_curve(out,look->linearmap,look->n,look->ln,
//				outsmall,look->m,amp,INT_TO_REAL(info->ampdB));
				lsp,look->m,amp,info->ampdB,look->lsp_look);
			return(1);
		}
	}

eop:
	memset(out,0,sizeof(Real)*look->n);
	return(0);
}

/* export hooks */
vorbis_func_floor floor0_exportbundle={
  NULL,&floor0_unpack,&floor0_look,&floor0_free_info,
  &floor0_free_look,NULL,&floor0_inverse
};


