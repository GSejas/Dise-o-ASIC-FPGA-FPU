/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE Ogg Vorbis SOFTWARE CODEC SOURCE CODE.  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS DISTRIBUTING.                            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-2000             *
 * by Monty <monty@xiph.org> and The XIPHOPHORUS Company            *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

  function: packing variable sized words into an octet stream
  last mod: $Id: bitwise.h,v 1.2 2002/03/27 14:31:22 pattara Exp $

 ********************************************************************/

/* We're 'LSb' endian; if we write a word but read individual bits,
   then we'll read the lsb first */


#ifndef _V_BITW_H_
#define _V_BITW_H_

//#include "vorbis/codec.h"
#include "codec.h"

static unsigned long mask[]=
{0x00000000,0x00000001,0x00000003,0x00000007,0x0000000f,
 0x0000001f,0x0000003f,0x0000007f,0x000000ff,0x000001ff,
 0x000003ff,0x000007ff,0x00000fff,0x00001fff,0x00003fff,
 0x00007fff,0x0000ffff,0x0001ffff,0x0003ffff,0x0007ffff,
 0x000fffff,0x001fffff,0x003fffff,0x007fffff,0x00ffffff,
 0x01ffffff,0x03ffffff,0x07ffffff,0x0fffffff,0x1fffffff,
 0x3fffffff,0x7fffffff,0xffffffff };

extern static void _oggpack_readinit(oggpack_buffer *b,unsigned char *buf,int bytes);
extern static inline long _oggpack_look(oggpack_buffer *b,int bits);
extern static inline void _oggpack_adv(oggpack_buffer *b,int bits);
extern static inline long _oggpack_read(oggpack_buffer *b,int bits);
extern static inline long _oggpack_read1(oggpack_buffer *b);
extern static inline long vorbis_book_decode(codebook *book, oggpack_buffer *b);
extern static inline long vorbis_book_decodevs(codebook *book,SmallReal *a,oggpack_buffer *b, 
		int step,int addmul);
extern static inline long s_vorbis_book_decodevs(codebook *book,SmallReal *a,oggpack_buffer *b, int step);
#endif
