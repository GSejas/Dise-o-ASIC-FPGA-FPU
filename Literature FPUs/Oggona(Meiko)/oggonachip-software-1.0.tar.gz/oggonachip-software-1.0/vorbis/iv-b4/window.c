/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE Ogg Vorbis SOFTWARE CODEC SOURCE CODE.  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS DISTRIBUTING.                            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-2000             *
 * by Monty <monty@xiph.org> and The XIPHOPHORUS Company            *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

 function: window functions
 last mod: $Id: window.c,v 1.1 2002/03/18 13:55:42 pattara Exp $

 ********************************************************************/

#include <stdlib.h>
#include <math.h>
#include "os.h"
#include "misc.h"
#include "lookup.h"

//#include "autoprofile.h"

Real *_vorbis_window(int type, int window,int left,int right){
#ifdef PROFILE
FunctionProfiler fp("_vorbis_window");
#endif	// PROFILE
  Real *ret=(Real*)calloc(window,sizeof(Real));

  switch(type){
  case 0:
    /* The 'vorbis window' (window 0) is sin(sin(x)*sin(x)*2pi) */
    {
      int leftbegin=window/4-left/2;
      int rightbegin=window-window/4-right/2;
      int i;
    
      for(i=0;i<left;i++){
/*
	Real x=(i+.5)/left*M_PI/2.;
	x=sin(x);
	x*=x;
	x*=M_PI/2.;
	x=sin(x);
	ret[i+leftbegin]=x;
*/
	// TODO: Optimize
	      long x=((i*0x8000)+0x4000)/left;//    (i+.5)/left*M_PI/2.;
	      x=vorbis_sinlook2_i(x);
	      x=(x*x)>>15;
	      x=vorbis_sinlook2_i(x);
	      ret[i+leftbegin]=x;//FLOAT_TO_REAL(x);
      }
      
      for(i=leftbegin+left;i<rightbegin;i++)
	ret[i]=INT_TO_REAL(1);
      
      for(i=0;i<right;i++){
/*
	Real x=(right-i-.5)/right*M_PI/2.;
	x=sin(x);
	x*=x;
	x*=M_PI/2.;
	x=sin(x);
	ret[i+rightbegin]=x;
*/
	      long x=((right-i)*0x8000-0x4000)/right; //float x=(right-i-.5)/right*M_PI/2.;
	      x=vorbis_sinlook2_i(x);
	      x=(x*x)>>15;
	      x=vorbis_sinlook2_i(x);
	      ret[i+rightbegin]=x;
      }
    }
    break;
  default:
    free(ret);
    return(NULL);
  }
  return(ret);
}

