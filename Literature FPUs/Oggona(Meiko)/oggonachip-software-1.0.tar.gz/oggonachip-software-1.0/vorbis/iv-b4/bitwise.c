/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE Ogg Vorbis SOFTWARE CODEC SOURCE CODE.  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS DISTRIBUTING.                            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-2000             *
 * by Monty <monty@xiph.org> and The XIPHOPHORUS Company            *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

  function: packing variable sized words into an octet stream
  last mod: $Id: bitwise.c,v 1.2 2002/03/27 14:31:21 pattara Exp $

 ********************************************************************/

#include <string.h>
#include <stdlib.h>
#include "os_types.h"
#include "bitwise.h"
#include "misc.h"
#include "os.h"
#include "checkalloc.h"
#include "autoprofile.h"

/* Going to assuming our read buffer is a 32 bit little endian buffer.
   This is passed in (and handled elsewhere) as a bytewise buffer, so
   the hack is potentially dangerous wrt alignment.  Assume/enforce
   the following:

   1) our 'first' byte is likely not word aligned; we find the word
   aligned value and 'fast forward' to our byte.  We assume this
   preceeding word aligned byte is valid as our buffer as a whole must
   begin byte aligned as per malloc/alloc spec.

   2) the last byte may not be aligned at the end of the last word.
   In framing.c, we make sure our buffer is adequately padded
   (_os_body_expand) */
 
static void _oggpack_readinit(oggpack_buffer *b,unsigned char *buf,int bytes){
  int ffwd=(((int)buf)&0x3);
  memset(b,0,sizeof(oggpack_buffer));
  b->buffer=b->ptr=(ogg_uint32_t *)(((ogg_int32_t)buf)&0xfffffffc);
  b->storage=(bytes+ffwd)<<3;
  b->endbit+=(ffwd<<3);
}

/* Read in bits without advancing the bitptr; bits <= 32 */
static inline long _oggpack_look(oggpack_buffer *b,int bits){
  long ret;
  long m=mask[bits];
  int           endbit=b->endbit&31;

  if(b->endbit+bits>b->storage)return(-1);
  
  ret=b->ptr[0]>>endbit;
  if(bits+endbit>32)
    ret|=b->ptr[1]<<(32-endbit);

  return(m&ret);
}

static inline void _oggpack_adv(oggpack_buffer *b,int bits){
  b->endbit+=bits;
  b->ptr=b->buffer+(b->endbit>>5);
}

/* bits <= 32 */
static inline long _oggpack_read(oggpack_buffer *b,int bits){
  unsigned long ret;
  unsigned long m=mask[bits];
  int           endbit=b->endbit&31;

  b->endbit+=bits;
  if(b->endbit>b->storage)return(-1);
  bits+=endbit;
  
  ret=b->ptr[0]>>endbit;
  if(bits>32)
    ret|=b->ptr[1]<<(32-endbit);

  b->ptr+=bits>>5;

  return(ret&m);
}

static inline long _oggpack_read1(oggpack_buffer *b){
  unsigned long ret;
  int           endbit=b->endbit&31;  
  ++b->endbit;

  if(b->endbit>b->storage)return(-1);
  ret=(b->ptr[0]>>endbit)&1;

  if(endbit==31) b->ptr++;

  return(ret);
}

/* Decode side is specced and easier, because we don't need to find
   matches using different criteria; we simply read and map.  There are
   two things we need to do 'depending':
   
   We may need to support interleave.  We don't really, but it's
   convenient to do it here rather than rebuild the vector later.

   Cascades may be additive or multiplicitive; this is not inherent in
   the codebook, but set in the code using the codebook.  Like
   interleaving, it's easiest to do it here.  
   addmul==0 -> declarative (set the value)
   addmul==1 -> additive
   addmul==2 -> multiplicitive */

/* returns the entry number or -1 on eof *************************************/
static inline long vorbis_book_decode(codebook *book, oggpack_buffer *b){
  long ptr=0;
  decode_aux *t=book->decode_tree;
  int lok = _oggpack_look(b, t->tabn);

  if (lok >= 0) {
    ptr = t->tab[lok];
    _oggpack_adv(b, t->tabl[lok]);
    if (ptr <= 0)
      return -ptr;
  }

  do{
    switch(_oggpack_read1(b)){
    case 0:
      ptr=t->ptr0[ptr];
      break;
    case 1:
      ptr=t->ptr1[ptr];
      break;
    case -1:
      return(-1);
    }
  }while(ptr>0);
  return(-ptr);
}

/* returns the entry number or -1 on eof *************************************/
static inline long vorbis_book_decodevs(codebook *book,SmallReal *a,oggpack_buffer *b,
			  int step,int addmul){
  long entry=vorbis_book_decode(book,b);
  int i,o;
  SmallReal *t;
  if(entry==-1)return(-1);
  t = book->valuelist+entry*book->dim;
  switch(addmul){
  case -1:
    for(i=0,o=0;i<book->dim-3;i+=4,o+=4*step) {
      a[o]=t[i];
      a[o+step]=t[i+1];
      a[o+2*step]=t[i+2];
      a[o+3*step]=t[i+3];
    }
    for(;i<book->dim;i++,o+=step)
      a[o]=t[i];
    break;
  case 0:
    for(i=0,o=0;i<book->dim-3;i+=4,o+=4*step) {
      a[o]+=t[i];
      a[o+step]+=t[i+1];
      a[o+2*step]+=t[i+2];
      a[o+3*step]+=t[i+3];
    }
    for(;i<book->dim;i++,o+=step)
      a[o]+=t[i];
    break;
  case 1:
    for(i=0,o=0;i<book->dim-3;i+=4,o+=4*step) {
/*
      a[o]*=t[i];
      a[o+step]*=t[i+1];
      a[o+2*step]*=t[i+2];
      a[o+3*step]*=t[i+3];
*/
      MULTEQ_SMALL_REAL(a[o], t[i]);
      MULTEQ_SMALL_REAL(a[o+step], t[i+1]);
      MULTEQ_SMALL_REAL(a[o+2*step], t[i+2]);
      MULTEQ_SMALL_REAL(a[o+3*step], t[i+3]);
    }
    for(;i<book->dim;i++,o+=step)
//      a[o]*=t[i];
      MULTEQ_SMALL_REAL(a[o], t[i]);
    break;
  }
  return(entry);
}

/* returns 0 on OK or -1 on eof *************************************/
static inline long s_vorbis_book_decodevs(codebook *book,SmallReal *a,oggpack_buffer *b,
                         int step){
  int i,j,o;

  for (j = 0; j < step; j++) {
    long entry=vorbis_book_decode(book,b);
    if(entry==-1)return(-1);
    
    for(i=0,o=0;i<book->dim;i++,o+=step)
	    a[o+j] = (book->valuelist+entry*book->dim)[i];
  }

  return(0);
}
