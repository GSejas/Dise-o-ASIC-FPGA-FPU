/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE Ogg Vorbis SOFTWARE CODEC SOURCE CODE.  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS DISTRIBUTING.                            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-2000             *
 * by Monty <monty@xiph.org> and The XIPHOPHORUS Company            *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

  function: lookup based functions
  last mod: $Id: lookup.h,v 1.1 2002/03/12 16:45:20 pattara Exp $

 ********************************************************************/

#ifndef _V_LOOKUP_H_

//#include "vorbis/real.h"
#include "real.h"

/* undefine both for the 'old' but more precise implementation */
//#define  FLOAT_LOOKUP
//#undef   INT_LOOKUP
#define  INT_LOOKUP
#undef   FLOAT_LOOKUP


#ifdef FLOAT_LOOKUP
extern float vorbis_coslook(float a);
extern float vorbis_invsqlook(float a);
extern float vorbis_invsq2explook(int a);
extern float vorbis_fromdBlook(float a);
#endif
#ifdef INT_LOOKUP
//extern long vorbis_invsqlook_i(long a,long e);
//extern long vorbis_coslook_i(long a);
//extern Real vorbis_fromdBlook_i(long a);
#endif 

extern Real vorbis_coslook2_i(long a);
extern Real vorbis_sinlook2_i(long a);

#endif
