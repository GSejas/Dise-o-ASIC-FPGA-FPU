/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE Ogg Vorbis SOFTWARE CODEC SOURCE CODE.  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS GOVERNED BY *
 * THE GNU PUBLIC LICENSE 2, WHICH IS INCLUDED WITH THIS SOURCE.    *
 * PLEASE READ THESE TERMS DISTRIBUTING.                            *
 *                                                                  *
 * THE OggSQUISH SOURCE CODE IS (C) COPYRIGHT 1994-2000             *
 * by Monty <monty@xiph.org> and The XIPHOPHORUS Company            *
 * http://www.xiph.org/                                             *
 *                                                                  *
 ********************************************************************

  function: LSP (also called LSF) conversion routines
  last mod: $Id: lsp.c,v 1.2 2002/03/27 14:31:22 pattara Exp $

 ********************************************************************/

#include <math.h>
#include <string.h>
#include <stdlib.h>
#include "lsp.h"
#include "os.h"
#include "misc.h"
#include "lookup.h"
#include "scales.h"

#include "autoprofile.h"
//#include <debug.h>

#define _V_INCLUDED
#include "lookup.c"
#undef _V_INCLUDED

#ifndef USE_ASSEMBLY
static int MLOOP_1[64]={
  0,10,11,11, 12,12,12,12, 13,13,13,13, 13,13,13,13,
  14,14,14,14, 14,14,14,14, 14,14,14,14, 14,14,14,14,
  15,15,15,15, 15,15,15,15, 15,15,15,15, 15,15,15,15,
  15,15,15,15, 15,15,15,15, 15,15,15,15, 15,15,15,15,
};

static int MLOOP_2[64]={
  0,4,5,5, 6,6,6,6, 7,7,7,7, 7,7,7,7,
  8,8,8,8, 8,8,8,8, 8,8,8,8, 8,8,8,8,
  9,9,9,9, 9,9,9,9, 9,9,9,9, 9,9,9,9,
  9,9,9,9, 9,9,9,9, 9,9,9,9, 9,9,9,9,
};

static int MLOOP_3[8]={0,1,2,2,3,3,3,3};
#endif

/* catch this in the build system; we #include for
                       compilers (like gcc) that can't inline across
                       modules */

/* side effect: changes *lsp to cosines of lsp */
void vorbis_lsp_to_curve(Real *curve,int *map,int n,int ln,SmallReal *lsp,int m,
//			    Real amp,Real ampoffset){
			    Real amp,int ampoffset,
			 long *icos){
#ifdef PROFILE
FunctionProfiler fp("vorbis_lsp_to_curve");
#endif	// PROFILE
  int i;

  int ampoffseti = ampoffset * 4096;
  int ampi = amp;
  long *ilsp=(long*)alloca(m*sizeof(long));
  long invpi=21361415L; /* (1./PI * (1<<(48-SMALL_FRACBITS)) */
#ifdef PROFILE
{
FunctionProfiler fp("vorbis_lsp_to_curve loop");
#endif	// PROFILE
 
 for(i=0;i<m;i++){
   long temp;
#ifdef USE_ASSEMBLY
   asm volatile("ldr   r1,[%1,%3,lsl#2];"
		"umull r1,%0,%2,r1;"
		:"=r"(temp)
		:"r"(lsp),"r"(invpi),"r"(i)
		:"r1"
		);
   ilsp[i]=vorbis_coslook_i(temp); 
#else
   ilsp[i]= (((ogg_int64_t)lsp[i]) << 16) /  FLOAT_TO_SMALL_REAL(M_PI);
#endif

 }
#ifdef PROFILE
}
#endif	// PROFILE

 
 i=0;
 while(i<n)
   {
     int k=map[i];
     unsigned long pi=46341; /* 2**-.5 in 0.16 */
     unsigned long qi=46341;
     int qexp=0;
     long wi=icos[k];
     

#ifdef USE_ASSEMBLY

     asm("mov     r0,%3;"
	 "mov     r1,%5,asr#1;"
	 "add     r0,r0,r1,lsl#3;"
	 "1:"

	 "ldmdb   r0!,{r1,r3};"
	 "subs    r1,r1,%4;"          //ilsp[j]-wi
	 "rsbmi   r1,r1,#0;"          //labs(ilsp[j]-wi)
	 "umull   %0,r2,r1,%0;"       //qi*=labs(ilsp[j]-wi)
	     
	 "subs    r1,r3,%4;"          //ilsp[j+1]-wi
	 "rsbmi   r1,r1,#0;"          //labs(ilsp[j+1]-wi)
	 "umull   %1,r3,r1,%1;"       //pi*=labs(ilsp[j+1]-wi)
	     
	 "cmn     r2,r3;"             // shift down 16?
	 "beq     0f;"
	 "add     %2,%2,#16;"
	 "mov     %0,%0,lsr #16;"
	 "orr     %0,%0,r2,lsl #16;"
	 "mov     %1,%1,lsr #16;"
	 "orr     %1,%1,r3,lsl #16;"
	 "0:"
	 "cmp     r0,%3;\n"
	 "bhi     1b;\n"

	 // odd filter assymetry
	 "ands    r0,%5,#1;\n"
	 "beq     2f;\n"
	 "add     r0,%3,%5,lsl#2;\n"

	 "ldr     r1,[r0,#-4];\n"
	 "mov     r0,#0x4000;\n"
	 
	 "subs    r1,r1,%4;\n"          //ilsp[j]-wi
	 "rsbmi   r1,r1,#0;\n"          //labs(ilsp[j]-wi)
	 "umull   %0,r2,r1,%0;\n"       //qi*=labs(ilsp[j]-wi)
	 "umull   %1,r3,r0,%1;\n"       //pi*=labs(ilsp[j+1]-wi)
	 
	 "cmn     r2,r3;\n"             // shift down 16?
	 "beq     2f;\n"
	 "add     %2,%2,#16;\n"
	 "mov     %0,%0,lsr #16;\n"
	 "orr     %0,%0,r2,lsl #16;\n"
	 "mov     %1,%1,lsr #16;\n"
	 "orr     %1,%1,r3,lsl #16;\n"
	 
	 //qi=(pi>>shift)*labs(ilsp[j]-wi);
	 //pi=(qi>>shift)*labs(ilsp[j+1]-wi);
	 //qexp+=shift;
	 
	 //}
	 
	 /* normalize to max 16 sig figs */
	 "2:"
	 "mov     r2,#0;"
	 "orr     r1,%0,%1;"
	 "tst     r1,#0xff000000;"
	 "addne   r2,r2,#8;"
	 "movne   r1,r1,lsr #8;"
	 "tst     r1,#0x00f00000;"
	 "addne   r2,r2,#4;"
	 "movne   r1,r1,lsr #4;"
	 "tst     r1,#0x000c0000;"
	 "addne   r2,r2,#2;"
	 "movne   r1,r1,lsr #2;"
	 "tst     r1,#0x00020000;"
	 "addne   r2,r2,#1;"
	 "movne   r1,r1,lsr #1;"
	 "tst     r1,#0x00010000;"
	 "addne   r2,r2,#1;"
	 "mov     %0,%0,lsr r2;"
	 "mov     %1,%1,lsr r2;"
	 "add     %2,%2,r2;"
	 
	 : "+r"(qi),"+r"(pi),"+r"(qexp)
	 : "r"(ilsp),"r"(wi),"r"(m)
	 : "r0","r1","r2","r3"
     
     );
#else
     /* Code taken from libvorbis RC3 -- ott */
     int shift, j;

     pi*=labs(ilsp[0]-wi);
     qi*=labs(ilsp[1]-wi);

    for(j=3;j<m;j+=2){
      if(!(shift=MLOOP_1[(pi|qi)>>25]))
        if(!(shift=MLOOP_2[(pi|qi)>>19]))
          shift=MLOOP_3[(pi|qi)>>16];
      qi=(qi>>shift)*labs(ilsp[j-1]-wi);
      pi=(pi>>shift)*labs(ilsp[j]-wi);
      qexp+=shift;
    }
    if(!(shift=MLOOP_1[(pi|qi)>>25]))
      if(!(shift=MLOOP_2[(pi|qi)>>19]))
        shift=MLOOP_3[(pi|qi)>>16];     

    /* comment from Integer version for HipZip */
    /*
      for(j=0;j<m;){
      qi=(pi>>shift)*labs(ilsp[j]-wi);
      pi=(qi>>shift)*labs(ilsp[j+1]-wi);
      qexp+=shift;
       }
    */
#endif
     
     pi=((pi*pi)>>16);
     qi=((qi*qi)>>16);

     if(m&1){
	     /* odd filter finish */
	     /* pi,qi normalized collectively, both tracked using qexp */
	     /* p*=p(1-w^2), let normalization drift because it isn't
		worth tracking step by step */
	     
	     qexp= qexp*2-28*((m+1)>>1)+m;
	     
	     pi*=(1<<14)-((wi*wi)>>14);
	     qi+=pi>>14;
	     
     }
     else{
	     /* even filter finish */
	     /* pi,qi normalized collectively, both tracked using qexp */
	     /* p*=p(1-w), q*=q(1+w), let normalization drift because it isn't
		worth tracking step by step */

	     qexp= qexp*2-13*m;
	     
	     pi*=(1<<14)-wi;
	     qi*=(1<<14)+wi;
	     
	     qi=(qi+pi)>>14;
     }
     
     /* we've let the normalization drift because it wasn't important;
	however, for the lookup, things must be normalized again.  We
	need at most one right shift or a number of left shifts */
     
     if(qi&0xffff0000){ /* checks for 1.xxxxxxxxxxxxxxxx */
       qi>>=1; qexp++; 
     }else
#ifdef USE_ASSEMBLY
       /* to max 16 sig figs */
       asm("tst     %0,#0x0000ff00;"
	   "moveq   %0,%0,lsl #8;"
	   "subeq   %1,%1,#8;"
	   "tst     %0,#0x0000f000;"
	   "moveq   %0,%0,lsl #4;"
	   "subeq   %1,%1,#4;"
	   "tst     %0,#0x0000c000;"
	   "moveq   %0,%0,lsl #2;"
	   "subeq   %1,%1,#2;"
	   "tst     %0,#0x00008000;"
	   "moveq   %0,%0,lsl #1;"
	   "subeq   %1,%1,#1;"
	   : "+r"(qi),"+r"(qexp)
	   );
#else
     /* taken from original libvorbis's code -- ott */
     while(qi && !(qi&0x8000)){ /* checks for 0.0xxxxxxxxxxxxxxx or less*/
       qi<<=1; qexp--;
     }
#endif

     amp=vorbis_fromdBlook_i(ampi*                     /*  n.4         */
			     vorbis_invsqlook_i(qi,qexp)- 
			     /*  m.8, m+n<=8 */
			     ampoffseti);                      /*  8.12[0]     */
     
     curve[i]=amp;
     while(map[++i]==k) curve[i]=amp;
   }
}
