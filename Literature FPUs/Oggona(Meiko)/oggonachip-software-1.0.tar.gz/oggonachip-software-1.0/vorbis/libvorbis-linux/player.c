/*
 * Simple Ogg Vorbis Player
 * 
 * -no thread, no music output
 * -contain checksum module to verify the correctness of audio output
 *  (-DCHECKSUM)
 * -compile with -DLINUX or -DRTEMS to run on Linux or RTEMS respectively
 *
 * ott@linux.thai.net
 * 15.02.2002
 *
 * Code adapted from decoder_example.c that came with libvorbis-1.0rc3
 * package. Please find its copyright below. The mentioned COPYING
 * file is included here as VORBIS-COPYING.
 *
 * $Id: player.c,v 1.8 2002/06/20 09:08:50 pattara Exp $
 */
 
/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis SOFTWARE CODEC SOURCE CODE.   *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS LIBRARY SOURCE IS     *
 * GOVERNED BY A BSD-STYLE SOURCE LICENSE INCLUDED WITH THIS SOURCE *
 * IN 'COPYING'. PLEASE READ THESE TERMS BEFORE DISTRIBUTING.       *
 *                                                                  *
 * THE OggVorbis SOURCE CODE IS (C) COPYRIGHT 1994-2001             *
 * by the XIPHOPHORUS Company http://www.xiph.org/                  *
 *                                                                  *
 ********************************************************************
 */

#ifdef RTEMS

/* RTEMS stuff */
#include <rtems.h>
/* configuration information */

#define CONFIGURE_INIT

#include <bsp.h> /* for device driver prototypes */

rtems_task Init( rtems_task_argument argument); /* forward declaration needed */

/* configuration information */

#define CONFIGURE_APPLICATION_NEEDS_CONSOLE_DRIVER
#define CONFIGURE_APPLICATION_NEEDS_CLOCK_DRIVER

#define CONFIGURE_MAXIMUM_TASKS             1

#define CONFIGURE_RTEMS_INIT_TASKS_TABLE
#define CONFIGURE_EXTRA_TASK_STACKS         (3 * RTEMS_MINIMUM_STACK_SIZE)
#define CONFIGURE_INIT_TASK_ATTRIBUTES (RTEMS_FLOATING_POINT | RTEMS_DEFAULT_ATTRIBUTES)

#include <confdefs.h>

#endif
/* End of RTEMS area */

/* Note that this is POSIX, not ANSI code */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vorbis/codec.h>
#include <sys/time.h>
#include <string.h>

#ifdef VORBIS_INTEGERIZED
#define DATA_TYPE int
#define REAL_TO_INT(a) a
#else
#define DATA_TYPE float
#define REAL_TO_INT(a) ( (int)( a*32767.f) )
#endif

ogg_int16_t convbuffer[4096]; /* take 8k out of the data segment, not the stack */
int convsize=4096;

#ifdef CHECKSUM
static char checksum = 0;
static long totalsamples = 0;
#endif

/* readAudioData
 *
 * Read audio data of "size" bytes and put in to "buffer", behave a bit like a stream
 *
 * return the real bytes read.
 *
 */

/* The source Ogg Vorbis sound file */
#ifdef LINUX
//#include "../musicdata/musicdata9-1.c"
//#include "../musicdata/musicdata10-1.c"
#include "../musicdata/musicdata5.c"
#else 
#include "../musicdata/musicdata6.c"
#endif

int readAudioData(char* buffer,unsigned int size) {
  static int pos = 0;
  static struct timeval lasttime;
  struct timeval newtime;
  unsigned int tobecopied;

  /* Size of total music in bytes */
  static unsigned int musicsize = sizeof(musicdata);

  if ( pos + size < musicsize ) {
    tobecopied = size;
  } else {
    tobecopied = musicsize - pos;
  }

  memcpy(buffer, ((char*) musicdata )+ pos, tobecopied); 

  pos += tobecopied;
  gettimeofday(&newtime, NULL);
  fprintf(stderr, "Input data read: %2d%%\tTime: %3d\t Diff: %3d\n",
 (int) pos*100/musicsize, (int) newtime.tv_sec,	 (int) (newtime.tv_sec - lasttime.tv_sec));
  lasttime = newtime;

  return tobecopied;
}

void dumpBuffer(char* buffer, unsigned int size) {
  unsigned int i;

  for (i = 0 ; i < size ; i++) {
    if ( i/16*16 == i*16/16 ) printf("\n");
    printf("%02X ",(unsigned char) *(buffer + i));
  }
  printf("\n");

}

#ifdef CHECKSUM
void writeOut(ogg_int16_t* convbuffer, int samplesize, int samples, FILE* outfd) { 
  int i;
  char sizeofelement = sizeof(ogg_int16_t);

  //printf("Calculate checksum of output %d samples ...\n", samples);
  for( i=0 ; i < samples * samplesize/sizeofelement; i++) {
    checksum = (checksum  + *(convbuffer + i) ) % 0xFF;
  }
  totalsamples += samples;
}
#endif

#ifdef RTEMS
rtems_task Init ( rtems_task_argument ignored) {
#else
int main(){
#endif
  ogg_sync_state   oy; /* sync and verify incoming physical bitstream */
  ogg_stream_state os; /* take physical pages, weld into a logical
			  stream of packets */
  ogg_page         og; /* one Ogg bitstream page.  Vorbis packets are inside */
  ogg_packet       op; /* one raw packet of data for decode */
  
  vorbis_info      vi; /* struct that stores all the static vorbis bitstream
			  settings */
  vorbis_comment   vc; /* struct that stores all the bitstream user comments */
  vorbis_dsp_state vd; /* central working state for the packet->PCM decoder */
  vorbis_block     vb; /* local working space for packet->PCM decode */
  
  char *buffer;
  int  bytes;

  /********** Decode setup ************/

  ogg_sync_init(&oy); /* Now we can read pages */
  
  while(1){ /* we repeat if the bitstream is chained */
    int eos=0;
    int i;

    /* grab some data at the head of the stream.  We want the first page
       (which is guaranteed to be small and only contain the Vorbis
       stream initial header) We need the first page to get the stream
       serialno. */

    /* submit a 4k block to libvorbis' Ogg layer */
    buffer=ogg_sync_buffer(&oy,4096);

    /* bytes=fread(buffer,1,4096,stdin); */
    bytes = readAudioData(buffer,4096);
    /*     dumpBuffer(buffer,96); */
    /*    exit(0); */

    ogg_sync_wrote(&oy,bytes);
    
    /* Get the first page. */
    if(ogg_sync_pageout(&oy,&og)!=1){
      /* have we simply run out of data?  If so, we're done. */
      if(bytes<4096)break;
      
      /* error case.  Must not be Vorbis data */
      fprintf(stderr,"Input does not appear to be an Ogg bitstream.\n");
      exit(1);
    }
  
    /* Get the serial number and set up the rest of decode. */
    /* serialno first; use it to set up a logical stream */
    ogg_stream_init(&os,ogg_page_serialno(&og));
    
    /* extract the initial header from the first page and verify that the
       Ogg bitstream is in fact Vorbis data */
    
    /* I handle the initial header first instead of just having the code
       read all three Vorbis headers at once because reading the initial
       header is an easy way to identify a Vorbis bitstream and it's
       useful to see that functionality seperated out. */
    
    vorbis_info_init(&vi);
    vorbis_comment_init(&vc);
    if(ogg_stream_pagein(&os,&og)<0){ 
      /* error; stream version mismatch perhaps */
      fprintf(stderr,"Error reading first page of Ogg bitstream data.\n");
      exit(1);
    }
    
    if(ogg_stream_packetout(&os,&op)!=1){ 
      /* no page? must not be vorbis */
      fprintf(stderr,"Error reading initial header packet.\n");
      exit(1);
    }
    
    if(vorbis_synthesis_headerin(&vi,&vc,&op)<0){ 
      /* error case; not a vorbis header */
      fprintf(stderr,"This Ogg bitstream does not contain Vorbis "
	      "audio data.\n");
      exit(1);
    }
    
    /* At this point, we're sure we're Vorbis.  We've set up the logical
       (Ogg) bitstream decoder.  Get the comment and codebook headers and
       set up the Vorbis decoder */
    
    /* The next two packets in order are the comment and codebook headers.
       They're likely large and may span multiple pages.  Thus we reead
       and submit data until we get our two pacakets, watching that no
       pages are missing.  If a page is missing, error out; losing a
       header page is the only place where missing data is fatal. */
    
    i=0;
    while(i<2){
      while(i<2){
	int result=ogg_sync_pageout(&oy,&og);
	if(result==0)break; /* Need more data */
	/* Don't complain about missing or corrupt data yet.  We'll
	   catch it at the packet output phase */
	if(result==1){
	  ogg_stream_pagein(&os,&og); /* we can ignore any errors here
					 as they'll also become apparent
					 at packetout */
	  while(i<2){
	    result=ogg_stream_packetout(&os,&op);
	    if(result==0)break;
	    if(result<0){
	      /* Uh oh; data at some point was corrupted or missing!
		 We can't tolerate that in a header.  Die. */
	      fprintf(stderr,"Corrupt secondary header.  Exiting.\n");
	      exit(1);
	    }
	    vorbis_synthesis_headerin(&vi,&vc,&op);
	    i++;
	  }
	}
      }
      /* no harm in not checking before adding more */
      buffer=ogg_sync_buffer(&oy,4096);
      /*      bytes=fread(buffer,1,4096,stdin); */
      bytes = readAudioData(buffer,4096);
      if(bytes==0 && i<2){
	fprintf(stderr,"End of file before finding all Vorbis headers!\n");
	exit(1);
      }
      ogg_sync_wrote(&oy,bytes);
    }
    
    /* Throw the comments plus a few lines about the bitstream we're
       decoding */
    {
      char **ptr=vc.user_comments;
      while(*ptr){
	fprintf(stderr,"%s\n",*ptr);
	++ptr;
      }
      fprintf(stderr,"\nBitstream is %d channel, %ldHz\n",vi.channels,vi.rate);
      fprintf(stderr,"Encoded by: %s\n\n",vc.vendor);
    }
    
    convsize=4096/vi.channels;

    /* OK, got and parsed all three headers. Initialize the Vorbis
       packet->PCM decoder. */
    vorbis_synthesis_init(&vd,&vi); /* central decode state */
    vorbis_block_init(&vd,&vb);     /* local state for most of the decode
				       so multiple block decodes can
				       proceed in parallel.  We could init
				       multiple vorbis_block structures
				       for vd here */
    
    /* The rest is just a straight decode loop until end of stream */
    while(!eos){
      while(!eos){
	int result=ogg_sync_pageout(&oy,&og);
	if(result==0)break; /* need more data */
	if(result<0){ /* missing or corrupt data at this page position */
	  fprintf(stderr,"Corrupt or missing data in bitstream; "
		  "continuing...\n");
	}else{
	  ogg_stream_pagein(&os,&og); /* can safely ignore errors at
					 this point */
	  while(1){
	    result=ogg_stream_packetout(&os,&op);

	    if(result==0)break; /* need more data */
	    if(result<0){ /* missing or corrupt data at this page position */
	      /* no reason to complain; already complained above */
	    }else{
	      /* we have a packet.  Decode it */
	      DATA_TYPE **pcm;

	      int samples;
	      
	      if(vorbis_synthesis(&vb,&op)==0) /* test for success! */
		vorbis_synthesis_blockin(&vd,&vb);
	      /* 
		 
	      **pcm is a multichannel float vector.  In stereo, for
	      example, pcm[0] is left, and pcm[1] is right.  samples is
	      the size of each channel.  Convert the float values
	      (-1.<=range<=1.) to whatever PCM format and write it out */
	      
	      while((samples=vorbis_synthesis_pcmout(&vd,&pcm))>0){
		int j;
		int clipflag=0;
		int bout=(samples<convsize?samples:convsize);
		
		/* convert floats to 16 bit signed ints (host order) and
		   interleave */
		for(i=0;i<vi.channels;i++){
		  ogg_int16_t *ptr=convbuffer+i;
		  DATA_TYPE  *mono=  pcm[i];

		  for(j=0;j<bout;j++){
		    int val= REAL_TO_INT(mono[j]);

		    /* might as well guard against clipping */
		    if(val>32767){
		      val=32767;
		      clipflag=1;
		    }
		    if(val<-32768){
		      val=-32768;
		      clipflag=1;
		    }
		    *ptr=val;
		    ptr+=vi.channels;
		  }
		}
		
		/* Uncomment here if you wanna see when it is clipped */
		/*
		  if(clipflag)
		  fprintf(stderr,"Clipping in frame %ld\n",(long)(vd.sequence)); 
		*/
#ifdef CHECKSUM
		writeOut(convbuffer, 2*vi.channels,bout, stdout);
#endif
		/* Uncomment here if you wanna have the output sent to stdout */
		fwrite(convbuffer,2*vi.channels,bout,stdout);
		vorbis_synthesis_read(&vd,bout); /* tell libvorbis how
						   many samples we
						   actually consumed */
	      }	    
	    }
	  }
	  if(ogg_page_eos(&og))eos=1;
	}
      }
      if(!eos){
	buffer=ogg_sync_buffer(&oy,4096);
	/* bytes=fread(buffer,1,4096,stdin); */
	bytes = readAudioData(buffer,4096);
	ogg_sync_wrote(&oy,bytes);
	if(bytes==0)eos=1;
      }
    }
    
    /* clean up this logical bitstream; before exit we see if we're
       followed by another [chained] */

    ogg_stream_clear(&os);
  
    /* ogg_page and ogg_packet structs always point to storage in
       libvorbis.  They're never freed or manipulated directly */
    
    vorbis_block_clear(&vb);
    vorbis_dsp_clear(&vd);
    vorbis_comment_clear(&vc);
    vorbis_info_clear(&vi);  /* must be called last */
  }

  /* OK, clean up the framer */
  ogg_sync_clear(&oy);

#ifdef CHECKSUM
  fprintf(stderr,"Total samples [672192]: %d\n",totalsamples);
  fprintf(stderr,"Check sum [0x3F]: 0x%02X\n",checksum);
#endif
  fprintf(stderr,"Done.\n");

#ifdef RTEMS
 exit(0);
#else
 return(0);
#endif
}
