/* Test program for the MDCT function
 *
 * set #define MDCT_INTEGERIZED in mdct.h to test either
 * floating point or integer version
 *
 * ott@linux.thai.net 21.03.2002
 */

#include "mdct.h"
#include "mdct-org.c"

#define ARRAYSIZE 64 /* Minimum = 64 -- limit from libvorbis */
int main() {

  DATA_TYPE *in, *out;
  unsigned int i;
  static mdct_lookup lookup;


  printf("MDCT  test program started ..\n");

  printf("Allocate memory ...\n");
  in = (DATA_TYPE *) malloc (ARRAYSIZE * sizeof(DATA_TYPE));
  out = (DATA_TYPE *) malloc (ARRAYSIZE * sizeof(DATA_TYPE));

  
  printf("Initializing values of input array...\n");
  for (i = 0 ; i < ARRAYSIZE ; i++) {
    float tmp;
    tmp = 0.5;
#ifdef MDCT_INTEGERIZED
    *(in + i) = (int) ( tmp * 32768.f);
    printf("%d: %d \n",i ,*(in + i) );
#else
    *(in + i) = tmp;
    printf("%d: %f \n",i, *(in + i) );
#endif
  }

  printf("Initializing values of output array...\n");
  for (i = 0 ; i < ARRAYSIZE ; i++) {
    *(out +i) = 0;
  }

  printf("Calling mdct_init functions...\n");
  mdct_init(&lookup, ARRAYSIZE);
  printf("Calling mdct_backward functions...\n");
  mdct_backward(&lookup, in, out);


  printf("Output values:\n");
  for (i = 0 ; i < ARRAYSIZE ; i++) {
#ifdef MDCT_INTEGERIZED
    printf("%d:\t%d\n",i , *( (int*) out + i) ); 
#else
    int tmp;
    tmp = (int) ( *(out+i) * 32768.f);
    printf("%d:\t%f\tor\t%d \n",i , *(out+i), tmp);
#endif
  }

  //  free(lookup);
  return(0);
}
