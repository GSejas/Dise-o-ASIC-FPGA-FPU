/*
 * Ogg Vorbis Player for Ogg-on-a-Chip project, pthread-based
 * 
 * ott@linux.thai.net
 *
 * $Id: player.c,v 3.8 2002/07/01 18:56:02 pattara Exp $
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/ioctl.h>
#include <vorbis/codec.h>
#include <vorbis/vorbisfile.h>
#include <pthread.h>
#include <sys/time.h>

/* For Linux */
#ifdef LINUX
#include <sys/soundcard.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/soundcard.h>
#endif

/* For RTEMS */
#ifdef RTEMS

#include <rtems.h> 
/* configuration information */

#define CONFIGURE_INIT

//#include <pmacros.h>
#include <unistd.h>
#include <errno.h>
#include <sched.h>

#include <bsp.h> /* for device driver prototypes */

/* forward declaration needed */
void *POSIX_Init(void *argument);

/* configuration information */

#define CONFIGURE_APPLICATION_NEEDS_CONSOLE_DRIVER
#define CONFIGURE_APPLICATION_NEEDS_CLOCK_DRIVER

#define CONFIGURE_HAS_OWN_DEVICE_DRIVER_TABLE
#define CONFIGURE_MAXIMUM_DRIVERS 4
#define CONFIGURE_LIBIO_MAXIMUM_FILE_DESCRIPTORS 10

#define CONFIGURE_MAXIMUM_POSIX_THREADS 5
#define CONFIGURE_MAXIMUM_POSIX_MUTEXES 5
#define CONFIGURE_MAXIMUM_POSIX_CONDITION_VARIABLES 5

#define CONFIGURE_POSIX_INIT_THREAD_TABLE

#include <console.h>
#include "../rtems-sound/sound.c"
#include "../rtems-soundinput/soundinput.c"

rtems_driver_address_table Device_drivers[] = {
        CONSOLE_DRIVER_TABLE_ENTRY,
        CLOCK_DRIVER_TABLE_ENTRY,
        SOUND_DRIVER_TABLE_ENTRY,
        SOUNDINPUT_DRIVER_TABLE_ENTRY,
        { NULL, NULL, NULL, NULL, NULL, NULL }
};

#include <confdefs.h>

#endif /* RTEMS */

#define DEVICE_NAME "/dev/dsp"

/* buffer to keep output from Vorbis decoder */
#define AUDIOBUFSIZE 4096
char audiobuf[AUDIOBUFSIZE];

#define OUTBUFSIZE 100000

/* 2 Audio out buffers */
typedef struct buffer_t {
  int size;
  char *buffer;
} buffer_t;

buffer_t outbuffer[2];

/* 1 control struct */
typedef struct control_t {
  char who_comes_first; /* initvalue = 0, decoder = 1, player = 2 */
  char isSongEnded;
  /* mutex to protect the above variables */
  pthread_mutex_t mutex;
  pthread_cond_t goPlay,continueDecode;
} control_t;

control_t control;

#ifdef DEBUG_PLAYER
#define DEBUG(x, y...) { fprintf (stderr, x, ## y); }
#else
#define DEBUG(x, y...) 
#endif

int audio_fd;

int initSound() {
  /* Open the sound device */
  printf("Opening %s...\n",DEVICE_NAME);
  if ( (audio_fd = open(DEVICE_NAME, O_WRONLY, 0) ) == -1 ) {
    /* open of a device failed */
    perror(DEVICE_NAME);
    exit(1);
  }

  /* Set up sound parameters */
  {
    int speed  = 22050; /* actually it is 24400 for our board */
    if ( ioctl(audio_fd, SNDCTL_DSP_SPEED, &speed) == -1 ) {
      perror("SNDCTL_DSP_SPEED");
      exit(1);
    }
  }

#ifdef LINUX
  {
    int format = AFMT_S16_LE;
    int channels = 2;

    if ( ioctl(audio_fd, SNDCTL_DSP_SETFMT, &format) == -1 ) {
      perror("SNDCTL_DSP_SETFMT");
      exit(1);
    }
    if ( ioctl(audio_fd, SNDCTL_DSP_CHANNELS, &channels) == -1 ) {
      perror("SNDCTL_DSP_CHANNELS");
      exit(1);
    }
  }
#endif
  return(0);
}

int closeSound() {
/* Close */
  if ( close(audio_fd) < 0 ) {
   perror("closing sound device");
   exit(1);
  }
  printf("Closing %s..\n",DEVICE_NAME);
  return(0);
}

void hexdisp(unsigned char byte) {
  unsigned int volatile * hexregs = (unsigned int *) 0x80000210;
  *hexregs = byte|0x100;
}

void countTask() {
  int i=0;
  /* Serious time counting */
  long starttime, currenttime;
  { 
    struct timeval gettime;
    gettimeofday(&gettime,NULL);
    starttime = gettime.tv_sec*1000000 + gettime.tv_usec;
  }
  
  while ( 1 ) {
    {
      struct timeval gettime;
      gettimeofday(&gettime,NULL);
      currenttime = gettime.tv_sec*1000000 + gettime.tv_usec;
      //printf("Current time is %d\n",currenttime);
    }; 
    { 
      struct timespec tmp;
      tmp.tv_sec=0;
      tmp.tv_nsec=500000000;
      nanosleep(&tmp, NULL);
    }
    {
      int tmp = (int) rint((currenttime-starttime)/1000000.f);
      if ( i != tmp) {
	i=tmp;
	//printf("%d: %2f\n", i, (currenttime-starttime)/1000000.f );
	printf("%d\n",i);
	hexdisp( (i/10) * 16 + i%10);
      }
    }

  }

  /* Not-so-serious time counting */
  /*
  while ( 1 ) {
    {
      hexdisp( (i/10) * 16 + i);
    }
    printf("%d\n", i++);
    sleep(1);
  }
  */
}

void playAudioTask() {
  int mycurrentbuffer = 0;
  DEBUG("Audio task is started.\n");

  while(1) {
    
    /* Lock the mutex */
    DEBUG("playAudioTask: Try to lock mutex ... \n");
    pthread_mutex_lock(&(control.mutex));
    DEBUG("playAudioTask: Got the mutex ... \n");
    
    if ( control.isSongEnded == 1 ) {
      DEBUG("playAudioTask: The song is ended..exiting\n");
      /* unlock mutex */
      pthread_mutex_unlock(&(control.mutex));
      DEBUG("playAudioTask: send the last signal to main...\n");
      pthread_cond_signal(&(control.continueDecode));
      return;
    };

    /* Check if who comes first */
    if ( control.who_comes_first == 0 ) {
      /* decoder doesn't arrive yet, so we come first, set our signature */
      DEBUG("playAudioTask: I arrive first, set my signature..\n");
      control.who_comes_first = 2;
      DEBUG("playAudioTask: wait for decoder to wake me up..\n");
      /* Unlock and wait for decoder to wake me up when content is ready to be played */
      pthread_cond_wait(&(control.goPlay),&(control.mutex));
    } else {
      /* Decoder is already waiting for us */
      DEBUG("playAudioTask: decoder is waiting for us, reset the signature..\n");
      /* reset the value */
      control.who_comes_first = 0;
    };

    /* unlock mutex */
    pthread_mutex_unlock(&(control.mutex));
   
    /* Give the acknowledge signal to continue decoding */
    DEBUG("playAudioTask: send the continueDecode signal to main...\n");
    pthread_cond_signal(&(control.continueDecode));
    
    DEBUG("playAudioTask: Now trying to play content of buffer: %d", mycurrentbuffer);

    /* play the music, keep locking the currentbuffer */
    DEBUG("playSound: Playing the sound from buffer %d\n", mycurrentbuffer);
    /* text version output for debug */
    /* fwrite(audioout_buffer[mycurrentbuffer].buffer,1,audioout_buffer[mycurrentbuffer].size,stdout); */
    /* Output to real sound device */
    write(audio_fd, outbuffer[mycurrentbuffer].buffer, outbuffer[mycurrentbuffer].size);  

    /* delay test to see pause between block */
    //printf("playAudioTask: clear the buffer and sleeping 2 seconds...\n");
    //memset(outbuffer[mycurrentbuffer].buffer, 0, OUTBUFSIZE);
    //sleep(2);

    /* Read which buffer next to be played */
    mycurrentbuffer = ( mycurrentbuffer == 0 ? 1 : 0 );
  };


} 


#ifdef LINUX
int main(){
#endif
#ifdef RTEMS
  /* rtems_task Init( rtems_task_argument ignored ) { */
  void* POSIX_Init(void *argument) {

#endif

  OggVorbis_File vf;
  int eof=0;
  int current_section;

  int currentbuffer = 0;  

  pthread_t audioPlay, count;
  int taskparameter = 0;

  /* Open the Ogg sound file */

  FILE* audioin;
#ifdef LINUX
  audioin = fopen("nightbirds.ogg","rb");
#endif
#ifdef RTEMS
  audioin = fopen("/dev/soundinput","rb");
#endif

  /* Init the control */
  pthread_mutex_init(&(control.mutex), NULL);
  control.who_comes_first = 0;
  control.isSongEnded = 0;
  pthread_cond_init(&(control.goPlay), NULL);
  pthread_cond_init(&(control.continueDecode), NULL);

  /* Init buffer */
  outbuffer[0].buffer = malloc (OUTBUFSIZE);
  outbuffer[1].buffer = malloc (OUTBUFSIZE);

  /* Decode setup */

  if(ov_open(audioin, &vf, NULL, 0) < 0) {
      fprintf(stderr,"Input does not appear to be an Ogg bitstream.\n");
      exit(1);
  }

  /* initialize the sound output */
  initSound();
  
  /* Start to playAudioTask */
  {
    int task_ret;
    task_ret = pthread_create(&audioPlay, NULL, (void *) playAudioTask, (void *) &taskparameter);
    if (task_ret) {
      perror("pthread_create: playAudioTask");
      exit(EXIT_FAILURE);
    }
  }

  hexdisp(0x0);

  /* Start countTask */
  {
    int task_ret;
    /*
    pthread_attr_t tattr;
    int newprio;
    struct sched_param param;
 
    // set the scheduling policy to SCHED_FIFO 
    pthread_attr_init(&tattr);
    pthread_attr_setschedpolicy(&tattr, SCHED_FIFO);

    
    // set the priority; others are unchanged 
    newprio = 10;
    param.sched_priority = newprio;
    
    // set the new scheduling param 
    pthread_attr_setschedparam(&tattr, &param);

    task_ret = pthread_create(&count, &tattr, (void *) countTask, (void *) &taskparameter);
    */
    
    task_ret = pthread_create(&count, NULL, (void *) countTask, (void *) &taskparameter);
    if (task_ret) {
      perror("pthread_create: countTask");
      exit(EXIT_FAILURE);
    }
  }
  
  /* Say something about the stream before decoding */
  {
    char **ptr=ov_comment(&vf,-1)->user_comments;
    vorbis_info *vi=ov_info(&vf,-1);
    while(*ptr) {
      fprintf(stderr,"%s\n",*ptr);
      ++ptr;
    }
    fprintf(stderr,"\nBitstream is %d channel, %ldHz\n",vi->channels,vi->rate);
    fprintf(stderr,"\nDecoded length: %ld samples\n",
	    (long)ov_pcm_total(&vf,-1));
    fprintf(stderr,"Encoded by: %s\n\n",ov_comment(&vf,-1)->vendor);
  }
  
  /* Main decode loop */
  printf("Elapsed time (second):\n");
  while(!eof){
    long ret;

    /* Set the correct Endian */
#ifdef LINUX
    ret=ov_read(&vf, audiobuf,AUDIOBUFSIZE,0,2,1,&current_section);
#else 
    ret=ov_read(&vf, audiobuf,AUDIOBUFSIZE,1,2,1,&current_section);
#endif

    if (ret == 0) {
      /* EOF */
      eof=1;
    } else if (ret < 0) {
      /* error in the stream. */
      fprintf(stderr,"main: Found error in the stream\n");
      continue;
    } else {
      /* decode is ok OR eof*/
	
      //DEBUG("main: copy decoded data to outbuffer: %d bytes\n", ret);
      if ( ret > AUDIOBUFSIZE ) {
	fprintf(stderr,"main: ret value from ov_read greater than AUDIOBUFSIZE..\n");
	exit(1);
      }

      /* now big buffer is free again, fill in the audio data */
      memcpy(outbuffer[currentbuffer].buffer + outbuffer[currentbuffer].size, audiobuf,ret);
      outbuffer[currentbuffer].size += ret;
    }

    /* if buffer is nearly full or the song is ended */
    if ( (OUTBUFSIZE - outbuffer[currentbuffer].size ) < (ret + AUDIOBUFSIZE) || eof ) {
      /* Submit data to playAudioTask */
	  
      /* Lock the mutex */
      DEBUG("main: Try to lock mutex ... \n");
      pthread_mutex_lock(&(control.mutex));
      DEBUG("main: Got the mutex ... \n");
	  
      /* Check if who comes first */
      if ( control.who_comes_first == 0 ) {
	DEBUG("main: I arrive first, set my signature..\n");
	/* player doesn't arrive yet, so we come first, set our signature */
	control.who_comes_first = 1;
      } else {
	/* player is waiting for us already */
	DEBUG("main: Player is waiting for us already, reset the signature...\n");
	  
	/* reset the value */
	control.who_comes_first = 0;
	  
	/* Now the audioPlay code should start to play to audio */
	DEBUG("main: Sending goPlay signal ... \n");
	pthread_cond_signal(&(control.goPlay));
      };
	
      /* Unlock and then wait for acknowledgement */
      DEBUG("main: Wait for continueDecode signal...\n");	
      pthread_cond_wait(&(control.continueDecode), &(control.mutex));
      DEBUG("main: Got the continueDecode signal, work further...\n");
	
      /* unlock mutex */
      pthread_mutex_unlock(&(control.mutex));
	
      /* toggle the buffer to use next time */
      currentbuffer = ( currentbuffer == 0 ? 1 : 0 );
      DEBUG("main: currentbuffer now changes to: %d \n",currentbuffer);
	
      /* reset the size */
      outbuffer[currentbuffer].size = 0;
    };
  }

    /* cleanup */
  ov_clear(&vf);

  fprintf(stderr,"Decode finishes ... \n");

  /* Decode finishes, wait for audioPlay task */
  /* Lock the mutex and set that the song is ended */
  DEBUG("main: Try to lock mutex ... \n");
  pthread_mutex_lock(&(control.mutex));
  DEBUG("main: Got the mutex ... \n");  
  control.isSongEnded = 1;
  /* unlock mutex */
  pthread_mutex_unlock(&(control.mutex));

  /* let the play task go to end */
  pthread_cond_signal(&(control.goPlay));

  /* Lock the mutex */
  DEBUG("main: Try to lock mutex ... \n");
  pthread_mutex_lock(&(control.mutex));
  DEBUG("main: Got the mutex ... \n");

  /* it will wake me up before end */
  DEBUG("main: Wait for last signal from playAudioTask...\n");	
  pthread_cond_wait(&(control.continueDecode), &(control.mutex));

  /* unlock mutex */
  pthread_mutex_unlock(&(control.mutex));

  pthread_join(audioPlay,NULL); // join here will hang
  printf("Ok, end the program....\n");

  /* Cancel the count task */
  pthread_cancel(count);
  //pthread_join(count,NULL); // join here would be nice but it doesn't work with RTEMS yet

  printf("Closing sound device..\n");
  //closeSound();

  fprintf(stderr,"Done.\n");
  exit(EXIT_SUCCESS);

#ifdef LINUX
  return(0);
#endif

}

