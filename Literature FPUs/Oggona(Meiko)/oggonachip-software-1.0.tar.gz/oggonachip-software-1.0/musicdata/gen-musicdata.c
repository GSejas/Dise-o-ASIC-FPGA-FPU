/* Program to generate the music data to be used with ddm-sound-music-test.c
 *
 * ott@linux.thai.net
 * 01.02.2002
 */

#include <stdio.h>

#define BUFFERSIZE 4096

main () {
  int size, count;
  int first = 0;

  short buffer[BUFFERSIZE];

  count = 0;
  printf("unsigned short musicdata[] = {\n");
  while ( !feof(stdin) ) {
    int i;
    size = fread(buffer, 2, BUFFERSIZE, stdin);
    for ( i = 0 ; i < size ; i++) {
      if ( (i/10*10) == (i*10/10) ) { 
	printf("\n");
      }
      /* Word output */
      if ( first == 0 ) {
	printf("  0x%04X", buffer[i] & 0xFFFF);
	count++;
	first = 1;
      } else {
	printf(", 0x%04X", buffer[i] & 0xFFFF);
	count++;
      }
      /* Output char by char (= like copy input to output) */
      //fprintf(stderr, "%c", buffer[i]);
      //fprintf(stderr, "%c", (buffer[i] >> 8) & 0xFF);



    }
  }
  printf("\n};\n");
  printf("/* Total %d elements */\n", count );

}
