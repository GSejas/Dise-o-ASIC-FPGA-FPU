/* 
   MDCT core module to be included by ../tsim-io/io.c .

   @author Pattara Kiatisevi
   $Id: mdct_core.c,v 1.7 2002/06/24 13:44:51 pattara Exp $
*/

#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <linux/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/soundcard.h>

#include "mdct_core.h"
#include "mdct.h"
#include "mdct.c"

struct mdct_core_regs *mdct_core;

static void mdct_core_init() 
{

  printf("io: mdct_core: MDCT-core initialized at 0x%x\n", MDCT_CORE_START);
  printf("io: mdct_core: time = %ld\n",(long)simif.simtime());
   
  mdct_core = (struct mdct_core_regs *) malloc (MDCT_CORE_SIZE);
  mdct_core->controlreg = 0;
  mdct_core->arraysize = 0;
  mdct_core->bitrevaddr  = 0;
  mdct_core->trigaddr  = 0;
  mdct_core->startreadaddr  = 0;
  mdct_core->startwriteaddr  = 0;
  mdct_core->status  = 0;
  mdct_core->actmemaddr  = 0;

};

static void mdct_core_exit() {
  printf("io: mdct_core: MDCT-core exit\n");
};

/* I/O read/write. Called on I/O or undecoded access. Should return 0 on
   success, 1 on memory error (MEXC will be generated). Data should be
   retuned in *data, number of BUSRDY waitstates should be returned in *ws.
   Size is encoded as: 0=byte, 1=half-word, 2=word, 3=doubel-word  */

static int mdct_core_read(address, data, ws) 
unsigned int address, *data, *ws; 
{ 
    *ws = 4;

    DEBUG("io: mdct_core: MDCT core accesssed at 0x%08X\n", address); 
    if ((address >= MDCT_CORE_START) && (address < MDCT_CORE_END)) {
      /* make it relative instead of absolute */
      address -= MDCT_CORE_START;
      /* alignment */
      address &= ~3;
      switch (address)	{
      case MDCT_CORE_CONTROLREG :  
	DEBUG("io: mdct_core: Control register is accessed!\n");
	*data = mdct_core->controlreg;
	break;
     case MDCT_CORE_ARRAYSIZE :  
	DEBUG("io: mdct_core: Arraysize register is accessed!\n");
	*data = mdct_core->arraysize;
	break; 
     case MDCT_CORE_BITREVADDR :  
	DEBUG("io: mdct_core: Bitrevaddr register is accessed!\n");
	*data = mdct_core->bitrevaddr;
	break; 
     case MDCT_CORE_TRIGADDR :  
	DEBUG("io: mdct_core: Trigaddr register is accessed!\n");
	*data = mdct_core->trigaddr;
	break; 
     case MDCT_CORE_STARTREADADDR :  
	DEBUG("io: mdct_core: Start read address register is accessed!\n");
	*data = mdct_core->startreadaddr;
	break;
      case MDCT_CORE_STARTWRITEADDR :  
	DEBUG("io: mdct_core: Start write address register is accessed!\n");
	*data = mdct_core->startwriteaddr;
	break;
      case MDCT_CORE_STATUS :  
	DEBUG("io: mdct_core: Status register is accessed!\n");
	*data = mdct_core->status;
	break;
     case MDCT_CORE_ACT_MEM_ADDR :  
	DEBUG("io: mdct_core: Act mem address register is accessed!\n");
	*data = mdct_core->actmemaddr;
	break;
      default:
	DEBUG("io: This should not happen! Error!\n");
	break;
      }
      
      return(0);
    } else
      return(1);
}

static int mdct_core_write(address, data, ws, size) 
unsigned int address, *data, *ws, size; 
{ 
  /* save for local use */
  int tmpdata = 0;

  *ws = 4;

  DEBUG("io: mdct_core: io_write at 0x%08X\n", address);

  if ((address >= MDCT_CORE_START) && (address < MDCT_CORE_END)) {
    address -= MDCT_CORE_START;
    switch(size) {
    case 2:
      /* only word access is allowed */
      /* alignment */
      address &= ~3;
      switch (address)	{
      case MDCT_CORE_CONTROLREG :  
	DEBUG("io: mdct_core: Control register is accessed!\n");
	tmpdata = *data;
	mdct_core->controlreg = *data;
	/* only the last 5 bits are used */
	//tmpdata &= 0x1F;
	/* first bit, MDCTcore 1=on, 0 = off */
	if ( (tmpdata & 0x1) != 0 ) {

	  DEBUG("io: mdct_core: MDCTcore is turned on..\n");
	  
	  /* Start the calculation process */
	  {
	    DATA_TYPE *in, *out;
	    mdct_lookup* lookup;
	    int n;

	    DEBUG("io: mdct_core: Start the MDCT calculation ... \n");
	    mdct_core->status = 0; 

	    /* Check the array size */
	    if ( mdct_core->arraysize == 0 ) n = 256; else n = 2048;

	    DEBUG("io: n = %d\n",n);

	    in =  malloc (n * sizeof(DATA_TYPE));
	    out = malloc (n * sizeof(DATA_TYPE));
	    lookup = malloc (sizeof(mdct_lookup));
	    lookup->bitrev = malloc(sizeof(int) * n/4 );
	    lookup->trig = malloc(sizeof(DATA_TYPE) * n*5/4 );

	    if ( in == 0 || out == 0 || lookup->bitrev == 0 || lookup->trig ==0 ) {
              fprintf(stderr, "io: mdct_core: malloc for MDCT calculation error\n");
              return(-1);
            }	    

	    /* call mdct_init, but bitrev and trig will be rewritten anyway */
	    mdct_init(lookup,n);

	    /* load the value from DMA */
	    DEBUG("io: mdct_core: Starting DMA read of variables...\n");

            /* last argument of dma_read is no. of words */
            if ( ioif.dma_read(  mdct_core->bitrevaddr, (unsigned int *) lookup->bitrev, n/4 ) != 0 ) {
                    fprintf(stderr, "io: mdct_core: DMA read bus error\n");
                    return(1);
            }	

            /* last argument of dma_read is no. of words */
            if ( ioif.dma_read(  mdct_core->trigaddr, (unsigned int *) lookup->trig, n*5/4 ) != 0 ) {
                    fprintf(stderr, "io: mdct_core: DMA read bus error\n");
                    return(1);
            }	  
            /* last argument of dma_read is no. of words */
            if ( ioif.dma_read(  mdct_core->startreadaddr, (unsigned int *) in, n ) != 0 ) {
                    fprintf(stderr, "io: mdct_core: DMA read bus error\n");
                    return(1);
            }	    

	    DEBUG("io: Calling mdct_backward()..\n");
	    /* now call the real calculation function */
	    mdct_backward(lookup, in, out);

	    DEBUG("io: ok");
	    /* write back the result */
           if ( ioif.dma_write(mdct_core->startwriteaddr, (unsigned int *) out, n ) != 0 ) {
                    fprintf(stderr, "io: mdct_core: DMA write bus error\n");
                    return(1);
            }	    

	    /* set status register to indicate that work is finisehd */
	    mdct_core->status = 1; 
	    /* this actmemaddr is not really useful with TSIM */
	    mdct_core->actmemaddr = mdct_core->startwriteaddr + n*sizeof(DATA_TYPE);
	    /* reset control register */
	    mdct_core->controlreg = mdct_core->controlreg & ~1;
	  }
	} else {
	  DEBUG("io: mdct_core: MDCTcore is turned off..\n");
	  return(0);
	}
	break;
      case MDCT_CORE_ARRAYSIZE :  
	DEBUG("io: mdct_core: Array size register is accessed!\n");
	mdct_core->arraysize = *data;
	DEBUG("io: mdct_core: Arraysize set to %d\n", mdct_core->arraysize);
	DEBUG("io: mdct_core: Done...\n");
	break;
      case MDCT_CORE_BITREVADDR :  
	DEBUG("io: mdct_core: bitrev address register is accessed!\n");
	mdct_core->bitrevaddr = *data;
	DEBUG("io: mdct_core: Bitrev addr set to 0x%08X\n", mdct_core->bitrevaddr);
	break;
      case MDCT_CORE_TRIGADDR :  
	DEBUG("io: mdct_core: trig address register is accessed!\n");
	mdct_core->trigaddr = *data;
	DEBUG("io: mdct_core: trig addr set to 0x%08X\n", mdct_core->trigaddr);
	break;
      case MDCT_CORE_STARTREADADDR :  
	DEBUG("io: mdct_core: Start read address register is accessed!\n");
	mdct_core->startreadaddr = *data;
	DEBUG("io: mdct_core: Start read address register set to 0x%08X\n", mdct_core->startreadaddr);
	break;
      case MDCT_CORE_STARTWRITEADDR :  
	DEBUG("io: mdct_core: Start write address register is accessed!\n");
	mdct_core->startwriteaddr = *data;
	DEBUG("io: mdct_core: Start write address register set to 0x%08X\n", mdct_core->startwriteaddr);
	break;
      case MDCT_CORE_STATUS :  
	DEBUG("io: mdct_core: Status register is accessed!\n");
	mdct_core->status = *data;
	DEBUG("io: mdct_core: Status register set to %d\n", mdct_core->status);
	break;
      case MDCT_CORE_ACT_MEM_ADDR :  
	DEBUG("io: mdct_core: Act_mem_addr is accessed!\n");
	fprintf(stderr, "io: mdct_core: Error, actmemaddr register is read-only\n");
	return(1);
      default:
	fprintf(stderr, "io: mdct_core: This should not happen! Error!\n");
      }
      break;
    default:
      fprintf(stderr, "io: mdct_core: Error, access with size = %d, only word access is allowed!\n",size);
      return(1);
    }
    return(0);
  } else
    return(1);
}

