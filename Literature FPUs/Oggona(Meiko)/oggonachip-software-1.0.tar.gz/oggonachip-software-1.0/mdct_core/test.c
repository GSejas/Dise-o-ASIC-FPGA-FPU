/* A simple program to test the Audio MDCT Core module
 *
 * @author Pattara Kiatisevi ott@linux.thai.net
 * 13.03.2002
 *
 * $Id: test.c,v 1.7 2002/06/24 13:44:51 pattara Exp $
 *
 */

#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include "mdct.h"
#include "mdct_core.h"

/* array size either 256 or 2048 only */
#define ARRAYSIZE 256

/* forward declaration */
void mdct_init(mdct_lookup* lookup, int n);

volatile struct mdct_core_regs *regs = (struct mdct_core_regs *) MDCT_CORE_START;

int main() {
  DATA_TYPE *in;
  DATA_TYPE *out;
  unsigned int i;
  mdct_lookup lookup;

  printf("MDCT Core test program started ..\n");
  printf("TRIGBITS = %d\n", TRIGBITS);

  printf("Allocate memory ...\n");
  in = malloc (ARRAYSIZE * sizeof(DATA_TYPE));
  out = malloc (ARRAYSIZE * sizeof(DATA_TYPE));

  printf("Calling mdct_init(%d)..\n", ARRAYSIZE);
  mdct_init(&lookup, ARRAYSIZE);

  printf("Initializing values of input array...\n");
  for (i = 0 ; i < ARRAYSIZE ; i++) {
    *(in + i) = 1 << (FRACBITS - 1 );
    printf("%d: %d\t",i, *(in + i) );
    if ( i % 5 == 4 ) printf("\n");
  }


  printf("Write value 0x%08X to bitrev address register ...\n", (unsigned int) lookup.bitrev);
  regs->bitrevaddr = (unsigned int) lookup.bitrev;

  printf("Write value 0x%08X to trig address register ...\n", (unsigned int) lookup.trig);
  regs->trigaddr = (unsigned int) lookup.trig;

  printf("Write value 0x%08X to start read address register ...\n", (unsigned int) in);
  regs->startreadaddr = (unsigned int) in;

  printf("Write value 0x%08X to start write address register ...\n", (unsigned int) out);
  regs->startwriteaddr = (unsigned int) out;

  printf("Write value %d to arraysize ...\n", ARRAYSIZE);
  regs->arraysize =  (ARRAYSIZE == 256) ? 0 : 1 ;

  printf("Start the MDCT core (write to controlreg with value 0x%08X .. \n", 0x1);
  regs->controlreg = 0x1;


  /* wait until result is there */
  printf("Wait until calculation is finished...\n");
  printf("act_mem_addr is 0x%08X\n", regs->actmemaddr);
  while ( regs->status != 1 ) {
    printf("act_mem_addr is 0x%08X\n", regs->actmemaddr);
  }
  printf("Finished ... output values:\n");
 
  for (i = 0 ; i < ARRAYSIZE ; i++) {
    printf("%d: %d\t",i , *( (int*) out + i) ); 
    if ( i % 5 == 4 ) printf("\n");
  }

  return(0);
}
