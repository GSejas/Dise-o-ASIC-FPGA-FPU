#ifndef __ASSEMBLER__

struct mdct_core_regs {
  /* 
   * Control register
   * bit 0: MDCT-core, 0 = off, 1 = on
   * bit 1: array size, 0 = 256, 1 = 2048
   */
  volatile unsigned int controlreg; /* 0x00 */

  /*
   * Size of input and output vector arrays 
   * after write to this arraysize register, check until status=1
   */
  volatile unsigned int arraysize;  /* 0x04 */

  /*
   * Start address of memory space that contains bitrev array data
   */
  volatile unsigned int bitrevaddr;  /* 0x08 */

  /*
   * Start address of memory space that contains trig array data
   */
  volatile unsigned int trigaddr;  /* 0x0C */

  /*
   * Start address of input vector to be read 
   */
  volatile unsigned int startreadaddr;  /* 0x10 */ 

  /*
   * Start address of output vector to be written
   */
  volatile unsigned int startwriteaddr;  /* 0x14 */

  /*
   * Status register, after write to controlreg and arraysize, 
   * value 1 here means the operation is successful
   */
  volatile unsigned int status;  /* 0x18 */

  /* 
   * Current processing element
   */
  volatile unsigned int actmemaddr; /* 0x1C */
};

#define	MDCT_CORE_START    0x80000300 
#define	MDCT_CORE_END      0x80000320

#define MDCT_CORE_SIZE     0x20

#define MDCT_CORE_CONTROLREG  0x00
#define MDCT_CORE_ARRAYSIZE   0x04
#define MDCT_CORE_BITREVADDR   0x08
#define MDCT_CORE_TRIGADDR   0x0C
#define MDCT_CORE_STARTREADADDR   0x10
#define MDCT_CORE_STARTWRITEADDR   0x14
#define MDCT_CORE_STATUS   0x18
#define MDCT_CORE_ACT_MEM_ADDR 0x1C


#endif
