/* 
   IO module for TSIM for simulation of hardware core(s).
   Will call each core according the the accessed address.

   @author Pattara Kiatisevi
   $Id: io.c,v 1.11 2002/06/30 18:56:19 pattara Exp $
*/

#include "tsim.h"
#include <stdio.h>

#ifdef DEBUG_TSIM_IO
#define DEBUG(x, y...) { fprintf (stderr, x, ## y); }
#else
#define DEBUG(x, y...) 
#endif

/* Include the hardware core files here, some modules might conflict */

/* Minimum we should have audio core */
#include "../audio_core/audio_core.c"

#ifdef WITH_MDCT
#include "../mdct_core/mdct_core.c"
#endif
#ifdef WITH_MINIMDCT
#include "../minimdct_core/minimdct_core.c"
#endif
#ifdef WITH_MULT
#include "../mult_core/mult_core.c"
#endif
#ifdef WITH_ETH
#include "../eth_core/eth_core.c"
#endif


/* called on simulator exit */
static void io_exit() {
  /* Call the exit function of each hardware core */

  audio_core_exit();
#ifdef WITH_MDCT
  mdct_core_exit();
#endif
#ifdef WITH_MINIMDCT
  minimdct_core_exit();
#endif
#ifdef WITH_MULT
  mult_core_exit();
#endif
#ifdef WITH_ETH
  eth_core_exit();
#endif
  
  fprintf(stderr, "Exit IO module: time = %ld\n",(long)simif.simtime());
}

static void io_init() {
  
  fprintf(stderr, "Enter IO Module: time = %ld\n",(long)simif.simtime());
  
  /* Call the init function of each hardware core */

  audio_core_init();

#ifdef WITH_MDCT
  mdct_core_init();
#endif
#ifdef WITH_MINIMDCT
  minimdct_core_init();
#endif
#ifdef WITH_MULT
  mult_core_init();
#endif
#ifdef WITH_ETH
  eth_core_init();
#endif

};

static int io_read(address, data, ws)
unsigned int address, *data, *ws;
{

  /* default value for wait states */
  *ws = 4;
  
  DEBUG("io: io_read at 0x%08X\n", address); 

  if ( (address >= AUDIO_CORE_START) && (address < AUDIO_CORE_END) )  {
    /* Audio core Area */

    /* Call the real function */
    audio_core_read(address, data, ws);
    
  } else /* Be careful with the parenthesis here */ 

#ifdef WITH_MDCT
  if ( (address >= MDCT_CORE_START) && (address < MDCT_CORE_END) )  {
    /* MDCT core area */

    /* Call the real function */
    mdct_core_read(address, data, ws);

  } else 
#endif

#ifdef WITH_MINIMDCT
  if ( (address >= MINIMDCT_CORE_START) && (address < MINIMDCT_CORE_END) )  {
    /* Mini-MDCT core area */

    /* Call the real function */
    minimdct_core_read(address, data, ws);

  } else 
#endif

#ifdef WITH_MULT
  if ( (address >= MULT_CORE_START) && (address < MULT_CORE_END) )  {
    /* Mult-MDCT core area */

    /* Call the real function */
    mult_core_read(address, data, ws);

  } else 
#endif

#ifdef WITH_ETH
  if ( (address >= ETH_CORE_START) && (address < ETH_CORE_END) )  {
    /* Ethernet core area */

    /* Call the real function */
    eth_core_read(address, data, ws);

  } else 
#endif

  {

    /* No hardware core is at this address */
    fprintf(stderr, "io: Error, read from no-hardware address 0x%08X\n", address);
    return(1);
    
  }
  return(0);

};

static int io_write(address, data, ws, size)
unsigned int address, *data, *ws, size;
{

  /* default value for wait states */
  *ws = 4;
  
  DEBUG("io: io_write at 0x%08X\n", address);

  if ( (address >= AUDIO_CORE_START) && (address < AUDIO_CORE_END) )  {   
    /* Audio core area */
    audio_core_write(address, data, ws, size);
  } else 

#ifdef WITH_MDCT
  if ( (address >= MDCT_CORE_START) && (address < MDCT_CORE_END) )  {
    /* MDCT core area */

    /* Call the real function */
    mdct_core_write(address, data, ws, size);

  } else 
#endif

#ifdef WITH_MINIMDCT
  if ( (address >= MINIMDCT_CORE_START) && (address < MINIMDCT_CORE_END) )  {
    /* Mini-MDCT core area */

    /* Call the real function */
    minimdct_core_write(address, data, ws, size);

  } else 
#endif

#ifdef WITH_MULT
  if ( (address >= MULT_CORE_START) && (address < MULT_CORE_END) )  {
    /* MULT core area */

    /* Call the real function */
    mult_core_write(address, data, ws, size);

  } else 
#endif

#ifdef WITH_ETH
  if ( (address >= ETH_CORE_START) && (address < ETH_CORE_END) )  {
    /* Ethernet core area */

    /* Call the real function */
    eth_core_write(address, data, ws, size);

  } else 
#endif

  {
    fprintf(stderr, "io: Error, write to no-hardware address 0x%08X\n", address);
    return(1);
  }
  return(0);

};


static struct io_subsystem tsim_io = {
	io_init,	/* io_init */
	io_exit,	/* io_exit */
	NULL,		/* io_reset */
	NULL,		/* io_restart */
	io_read,	/* io_read */
	io_write,	/* io_write */
	NULL,	        /* get_io_ptr */
	NULL,	        /* command */
	NULL,		/* sigio */
	NULL,	        /* save */
	NULL	        /* restore */
};

/* Attached to TSIM */

struct io_subsystem *iosystem = &tsim_io;

